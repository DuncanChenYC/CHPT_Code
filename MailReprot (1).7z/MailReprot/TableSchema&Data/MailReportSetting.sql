USE [CHPT]
GO

/****** Object:  Table [dbo].[MailReportSetting]    Script Date: 2025/1/13 �U�� 04:50:25 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[MailReportSetting](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[MailPriority] [nvarchar](1) NOT NULL,
	[Subject] [nvarchar](100) NOT NULL,
	[MailContent] [nvarchar](3000) NULL,
	[IsExternalClass] [bit] NOT NULL,
	[IsAttachmentExcel] [bit] NOT NULL,
	[IsHeader] [bit] NOT NULL,
	[FileName] [nvarchar](50) NULL,
	[DBConnName] [varchar](20) NOT NULL,
	[ReportSQL] [nvarchar](max) NOT NULL,
	[MailToSQL] [nvarchar](max) NULL,
	[MailCcSQL] [nvarchar](max) NULL,
	[MailBccSQL] [nvarchar](max) NULL,
	[RelationalMailToSQL] [nvarchar](max) NULL,
	[RelationalMailCcSQL] [nvarchar](max) NULL,
	[RelationalMailBccSQL] [nvarchar](max) NULL,
	[FixedDate] [nvarchar](30) NULL,
	[FixedDateTime] [time](7) NULL,
	[CycleTimeDaily] [nvarchar](20) NULL,
	[StartTime] [time](7) NULL,
	[EndTime] [time](7) NULL,
	[CycleTimeMinute] [int] NULL,
	[IsInvalid] [bit] NOT NULL,
	[CreateDate] [datetime] NOT NULL,
	[CreateUser] [nvarchar](6) NOT NULL,
	[LstEdtDate] [datetime] NOT NULL,
	[LstEdtUser] [nvarchar](6) NOT NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[MailReportSetting] ADD  CONSTRAINT [DF_MailReportSetting_CreateDate]  DEFAULT (getdate()) FOR [CreateDate]
GO

ALTER TABLE [dbo].[MailReportSetting] ADD  CONSTRAINT [DF_MailReportSetting_LstEdtDate]  DEFAULT (getdate()) FOR [LstEdtDate]
GO


