﻿using System;

/// <summary>
/// CreateHtmlTable 的摘要描述
/// </summary>
public class CreateHtmlTable
{
    private System.Collections.ArrayList alColumnName;
    private System.Collections.ArrayList alDataTableColumnName;
    private System.Collections.ArrayList alTextAlign;
    private System.Collections.ArrayList alNoWrap;
    private System.Collections.ArrayList alHeaderBgColor;
    private System.Collections.ArrayList alDataFormatType;
    private System.Collections.ArrayList alFormatStr;
    private System.Collections.ArrayList alCellFontColor;
    private System.Collections.ArrayList alCellBgColor;
    private System.Data.DataTable dtSource;

    public CreateHtmlTable(System.Data.DataTable dt)
    {
        alColumnName = new System.Collections.ArrayList();
        alDataTableColumnName = new System.Collections.ArrayList();
        alTextAlign = new System.Collections.ArrayList();
        alNoWrap = new System.Collections.ArrayList();
        alHeaderBgColor = new System.Collections.ArrayList();
        alDataFormatType = new System.Collections.ArrayList();
        alFormatStr = new System.Collections.ArrayList();
        alCellFontColor = new System.Collections.ArrayList();
        alCellBgColor = new System.Collections.ArrayList();
        dtSource = dt;
    }

    public enum DataFormatType
    {
        String,
        Number,
        DateTime
    }

    /// <summary>
    /// 定義Html Table的欄位資訊
    /// </summary>
    /// <param name="columnName">欄位名稱</param>
    /// <param name="headerBgcolor">Header欄位的底色</param>
    /// <param name="dataTableColumnName">對應DataTable的欄位名稱</param>
    /// <param name="isNoWrap">是否允許欄位內換行</param>
    /// <param name="txtAlign">文字對齊方向</param>
    public void AddColumn(string columnName, string headerBgcolor, string dataTableColumnName, bool isNoWrap, TextAlign txtAlign)
    {
        this.AddColumn(columnName, headerBgcolor, "", "", dataTableColumnName, DataFormatType.String, "", isNoWrap, txtAlign);
    }

    /// <summary>
    /// 定義Html Table的欄位資訊
    /// </summary>
    /// <param name="columnName">欄位名稱</param>
    /// <param name="headerBgColor">Header欄位的底色</param>
    /// <param name="cellBgColor">內容欄位的底色</param>
    /// <param name="cellFontColor">內容字體的顏色</param>
    /// <param name="dataTableColumnName">對應DataTable的欄位名稱</param>
    /// <param name="dataFormat">資料格式</param>
    /// <param name="formatStr">定義資料格式 EX:【字串→"I am {0}"】 【數字→"{0:N}" 或 {0:N{0}}→({0}系統自動判斷) 或 "{0:0%}"】 【時間→"{0:d}" 或 "{0:yyyy/MM/dd}"】</param>
    /// <param name="isNoWrap">是否允許欄位內換行</param>
    /// <param name="txtAlign">文字對齊方向</param>
    public void AddColumn(string columnName, string headerBgColor, string cellFontColor, string cellBgColor, string dataTableColumnName, DataFormatType dataFormat, string formatStr, bool isNoWrap, TextAlign txtAlign)
    {
        alColumnName.Add(columnName);
        alDataTableColumnName.Add(dataTableColumnName);
        alTextAlign.Add(txtAlign);
        alNoWrap.Add(isNoWrap);
        alHeaderBgColor.Add(headerBgColor);
        alDataFormatType.Add(dataFormat);
        alFormatStr.Add(formatStr);
        alCellFontColor.Add(cellFontColor);
        alCellBgColor.Add(cellBgColor);
    }

    public enum TextAlign
    {
        left,
        center,
        right
    }

    public string GetHtmlContent(bool isHeader, bool isBorder)
    {
        System.Text.StringBuilder sbHtml = new System.Text.StringBuilder();

        try
        {
            int columnIndex = 0;
            if (isHeader)
            {
                 sbHtml.AppendFormat("<table {0}>", isBorder ? "border='1' style='border-collapse:collapse;' borderColor='black'" : "");
                sbHtml.Append("<tr>");               
                foreach (string columnName in alColumnName)
                {
                    sbHtml.AppendFormat("<th nowrap='nowrap' bgcolor='{1}'>{0}</th>", columnName, alHeaderBgColor[columnIndex++]);
                }
                sbHtml.Append("</tr>");
            }

            if (dtSource.Rows.Count > 0)
            {
                int rowIndex = 0;
                foreach (System.Data.DataRow dr in dtSource.Rows)
                {
                    sbHtml.AppendFormat("<tr bgcolor='{0}'>", rowIndex++ % 2 == 0 ? "White" : "LightCyan");

                    columnIndex = 0;
                    string align;
                    string nowrap;
                    string value, tempValue, tempFormatStr, tempCellBgColor, tempCellFontColor;
                    foreach (string dtColumnName in alDataTableColumnName)
                    {
                        tempCellFontColor = alCellFontColor[columnIndex].ToString() == "" ? "Black" : alCellFontColor[columnIndex].ToString();
                        tempCellBgColor = alCellBgColor[columnIndex].ToString() == "" ? "" : string.Format("bgcolor='{0}'", alCellBgColor[columnIndex].ToString());
                        align = ((TextAlign)alTextAlign[columnIndex]).ToString();

                        #region 設定資料的格式

                        tempValue = dr[dtColumnName].ToString();
                        //{0}-為系統自動定義格式
                        if (alFormatStr[columnIndex].ToString().IndexOf("(A)") > -1)
                            tempFormatStr = alFormatStr[columnIndex].ToString().Replace("(A)", tempValue.IndexOf('.') > -1 ? (tempValue.Substring(tempValue.IndexOf('.')).Length - 1).ToString() : "0");
                        else
                            tempFormatStr = alFormatStr[columnIndex].ToString();
                        if (tempFormatStr != "")
                        {
                            switch ((DataFormatType)alDataFormatType[columnIndex])
                            {
                                case DataFormatType.String:
                                    value = string.Format(tempFormatStr, tempValue);
                                    break;

                                case DataFormatType.Number:
                                    double tempDoubleValue;
                                    value = double.TryParse(tempValue, out tempDoubleValue) ? string.Format(tempFormatStr, tempDoubleValue) : tempValue;
                                    break;

                                case DataFormatType.DateTime:
                                    DateTime tempDateTimeValue;
                                    value = DateTime.TryParse(tempValue, out tempDateTimeValue) ? string.Format(tempFormatStr, tempDateTimeValue) : tempValue;
                                    break;

                                default:
                                    value = tempValue;
                                    break;
                            }
                        }
                        else
                            value = tempValue;

                        #endregion 設定資料的格式

                        nowrap = "";
                        if ((bool)alNoWrap[columnIndex])
                        {
                            nowrap = "nowrap";
                            //value = string.Format("<nobr>{0}</nobr>", value);
                        }
                        //換行
                        value = value.Replace("\r\n", "<br />").Replace("\n", "<br />").Replace("&lt;", "<").Replace("&gt;", ">");
                        sbHtml.AppendFormat("<td align='{0}' {1} {4}><font color='{3}'>{2}</font></td>", align, nowrap, value, tempCellFontColor, tempCellBgColor);
                        columnIndex++;
                    }
                    sbHtml.Append("</tr>");
                }
            }
            else
                sbHtml.AppendFormat("<td bgcolor='White' align='center' colspan='{0}'><font color='red'>無符合的資訊</font></td>", dtSource.Columns.Count);

            if(isHeader)
                sbHtml.Append("</table>");
        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message);
        }
        return sbHtml.ToString();
    }
}