﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// MF29PClass 的摘要描述
/// </summary>
public class SA29PClass
{
	public SA29PClass()
	{
		
	}

    public System.Data.DataTable SA29P_QueryNonSendOrder()
	{
        ERP.DBDao dao = new ERP.DBDao();
        string sql = dao.SqlSelectToString("SELECT SQL FROM SQLList WHERE ProgramName = 'SA29P' AND FunctionName = 'QueryNonSendOrder' ", "SQL");
        System.Data.DataTable dtDetail = dao.SqlSelect(sql);
        dtDetail.TableName = "[V]";
        return dtDetail;
	}

	
}