﻿using System;
using System.Data;

internal class EEP_Reminder
{
    public DataTable GetEEP_Reminder(int count)
    {
        DataTable dtResult = GetEEPToDo(count);
        dtResult.Columns.Remove("LISTID");
        dtResult.Columns.Remove("SENDTO_ID");
        return dtResult;
    }
    public DataTable GetEEPToDo(int count)
    {
        ERP.DBDao Dao_select = new ERP.DBDao();

        string symbol = "=";
        if (count >= 3)
            symbol = ">=";

        #region 取得資料

        DataTable dt = new DataTable();
        string sql = string.Format(@"
                    DECLARE @COUNT INT;
                    SET @COUNT={0};
                    SELECT * FROM (
                        --SENDTO_ID=工號
                        SELECT CASE WHEN RESULT.FLOWURGENT='0' THEN '否' ELSE '是' END AS 緊急, RESULT.FormName AS 表單類別, RESULT.STEP_ID AS 簽核站點, REPLACE(RESULT.FormTopic,'主旨:','<br /><font color=''blue''><strong>主旨:')  + '</strong></font>' AS 主旨, 
			                                   RESULT.DeptName AS 待簽部門, RESULT.EmployeeNo AS 待簽人工號, RESULT.EmployeeName AS 待簽人姓名, RESULT.UPDATE_DATE+' '+RESULT.UPDATE_TIME AS 待簽日期,
					                           --ROUND(RESULT.PROCS_TIME/24,2) AS 逾期天數,
											   --RESULT.PROCS_TIME AS 逾期時數, 
											   ISNULL(RESULT.SEND_COUNT,0)+1 AS 催簽次數,
											   CASE WHEN RESULT.FLOWURGENT = 1 THEN ROUND(CAST(ISNULL(F.URGENT_ALERT,6) AS FLOAT)/24,2) ELSE ROUND(CAST(ISNULL(F.NORMAL_ALERT,24) AS FLOAT)/24,2) END AS [催簽頻率(天)],	
											   RESULT.LISTID AS LISTID, RESULT.SENDTO_ID AS SENDTO_ID
											   	    
		                         FROM (
                                SELECT S.FLOWURGENT, S.FLOW_DESC AS FormName, S.FORM_PRESENT_CT AS FormTopic, D_STEP_ID AS STEP_ID
		                        , H.EmployeeName, H.EmployeeNo, D.DeptName, H.DirectMGR, SENDTO_KIND
                                ,UPDATE_DATE, UPDATE_TIME, S.STATUS	
								, S.LISTID, S.SENDTO_ID, S.LAST_SEND_DATE, S.SEND_COUNT
								,ROUND(CHPT.dbo.GetWorkTime(ISNULL(S.LAST_SEND_DATE,CONVERT(DATETIME,S.UPDATE_DATE + ' '+S.UPDATE_TIME)),GETDATE())/60,1) AS PROCS_TIME
                                FROM CHPTEEP.dbo.SYS_TODOLIST S
		                        INNER JOIN CHPT.dbo.HR0AM H ON H.EmployeeNo=S.SENDTO_ID
		                        INNER JOIN CHPT.dbo.Dept D ON H.DeptNo=D.DeptNo
                                where 1=1
                                  AND ISNULL(STATUS,'') <> 'F' AND ISNULL(PLUSROLES,'') = ''
		                          AND S.SENDTO_KIND='2'
		                          ) AS RESULT 
								  OUTER APPLY 
									(SELECT TOP 1 *
									 FROM CHPTEEP.dbo.SYS_FLOW_CONFIG FC (NOLOCK)
									 WHERE RESULT.FormName=FC.FLOW_DESC 
									   AND ((ISNULL(FC.IS_PARALLEL,'')='Y' AND ISNUMERIC(REPLACE(RESULT.STEP_ID,FC.STEP_ID+'_',''))=1)
									         OR RESULT.STEP_ID = (CASE WHEN ISNULL(FC.STEP_ID,'')='' THEN RESULT.STEP_ID ELSE FC.STEP_ID END))   
									 ORDER BY  FC.STEP_ID DESC
									) AS F
									WHERE (ISNULL(SEND_COUNT,0)+1) {1} @COUNT
									  AND ((RESULT.PROCS_TIME >= ISNULL(F.NORMAL_ALERT,24) and RESULT.FLOWURGENT = 0) OR (RESULT.PROCS_TIME >= ISNULL(F.URGENT_ALERT,6) and RESULT.FLOWURGENT = 1))
								  	  AND 'Y' = (CASE WHEN ISNULL(F.ACTIVE,'Y') = 'Y' THEN 'Y' ELSE 'N' END)
                        UNION ALL
                        --SENDTO_ID=角色
                        SELECT CASE WHEN RESULT.FLOWURGENT='0' THEN '否' ELSE '是' END AS 緊急, RESULT.FormName AS 表單類別, RESULT.STEP_ID AS 簽核站點, REPLACE(RESULT.FormTopic,'主旨:','<br /><font color=''blue''><strong>主旨:')  + '</strong></font>' AS 主旨, 
			                                   RESULT.DeptName AS 待簽部門, RESULT.EmployeeNo AS 待簽人工號, RESULT.EmployeeName AS 待簽人姓名, RESULT.UPDATE_DATE+' '+RESULT.UPDATE_TIME AS 待簽日期,
					                           --ROUND(RESULT.PROCS_TIME/24,2) AS 逾期天數,
											   --RESULT.PROCS_TIME AS 逾期時數, 
											   ISNULL(RESULT.SEND_COUNT,0)+1 AS 催簽次數,
											   CASE WHEN RESULT.FLOWURGENT = 1 THEN ROUND(CAST(ISNULL(F.URGENT_ALERT,6) AS FLOAT)/24,2) ELSE ROUND(CAST(ISNULL(F.NORMAL_ALERT,24) AS FLOAT)/24,2) END AS [催簽頻率(天)],	
											   RESULT.LISTID AS LISTID, RESULT.SENDTO_ID AS SENDTO_ID	    
		                         FROM (
                                SELECT S.FLOWURGENT, S.FLOW_DESC AS FormName, S.FORM_PRESENT_CT AS FormTopic, D_STEP_ID AS STEP_ID
		                        , H.EmployeeName, H.EmployeeNo, D.DeptName, H.DirectMGR, SENDTO_KIND
                                ,UPDATE_DATE, UPDATE_TIME, S.STATUS	
								, S.LISTID, S.SENDTO_ID, S.LAST_SEND_DATE, S.SEND_COUNT
								,ROUND(CHPT.dbo.GetWorkTime(ISNULL(S.LAST_SEND_DATE,CONVERT(DATETIME,S.UPDATE_DATE + ' '+S.UPDATE_TIME)),GETDATE())/60,1) AS PROCS_TIME
                                FROM CHPTEEP.dbo.SYS_TODOLIST S
		                        INNER JOIN CHPTEEP.dbo.USERGROUPS G ON S.SENDTO_ID=G.GROUPID
		                        INNER JOIN CHPT.dbo.HR0AM H ON H.EmployeeNo=G.USERID
		                        INNER JOIN CHPT.dbo.Dept D ON H.DeptNo=D.DeptNo
                                where 1=1
                                  AND ISNULL(STATUS,'') <> 'F' AND ISNULL(PLUSROLES,'') = ''
		                          AND S.SENDTO_KIND='1'
		                          ) AS RESULT 
								  OUTER APPLY 
									(SELECT TOP 1 *
									 FROM CHPTEEP.dbo.SYS_FLOW_CONFIG FC (NOLOCK)
									 WHERE RESULT.FormName=FC.FLOW_DESC 
									   AND ((ISNULL(FC.IS_PARALLEL,'')='Y' AND ISNUMERIC(REPLACE(RESULT.STEP_ID,FC.STEP_ID+'_',''))=1)
									         OR RESULT.STEP_ID = (CASE WHEN ISNULL(FC.STEP_ID,'')='' THEN RESULT.STEP_ID ELSE FC.STEP_ID END))   
									 ORDER BY  FC.STEP_ID DESC
									) AS F
									WHERE (ISNULL(SEND_COUNT,0)+1) {1} @COUNT
									  AND ((RESULT.PROCS_TIME >= ISNULL(F.NORMAL_ALERT,24) and RESULT.FLOWURGENT = 0) OR (RESULT.PROCS_TIME >= ISNULL(F.URGENT_ALERT,6) and RESULT.FLOWURGENT = 1))
								  	  AND 'Y' = (CASE WHEN ISNULL(F.ACTIVE,'Y') = 'Y' THEN 'Y' ELSE 'N' END)
                        ) AS R
                        ORDER BY R.表單類別, R.簽核站點
                        ", count, symbol);

        #endregion 取得資料

        dt = Dao_select.SqlSelect(sql);
        dt.TableName = "[V]";

        return dt;
    }
    public bool UpdateEEP_Reminder(int count)
    {
        ERP.DBDao Dao_trans = new ERP.DBDao();
        Dao_trans.SqlConn.Open();
        Dao_trans.BeginTransaction();

        bool isSuccess = true;
        System.Text.StringBuilder sbMsg = new System.Text.StringBuilder();

        try
        {
            System.Data.DataTable dtResult = GetEEPToDo(count);
            System.Data.DataTable dt = dtResult.DefaultView.ToTable(true, "表單類別", "簽核站點", "LISTID", "SENDTO_ID");
            string sql = @"UPDATE CHPTEEP.dbo.SYS_TODOLIST SET LAST_SEND_DATE=GETDATE(),SEND_COUNT=isnull(SEND_COUNT,0)+1
                            WHERE FLOW_DESC=@FLOW_DESC AND D_STEP_ID=@D_STEP_ID AND LISTID=@LISTID AND SENDTO_ID=@SENDTO_ID ";
            foreach (DataRow dr in dt.Rows)
            {
                Dao_trans.SqlCommand.Parameters.Clear();
                Dao_trans.SqlCommand.Parameters.AddWithValue("@FLOW_DESC", dr["表單類別"].ToString());
                Dao_trans.SqlCommand.Parameters.AddWithValue("@D_STEP_ID", dr["簽核站點"].ToString());
                Dao_trans.SqlCommand.Parameters.AddWithValue("@LISTID", dr["LISTID"].ToString());
                Dao_trans.SqlCommand.Parameters.AddWithValue("@SENDTO_ID", dr["SENDTO_ID"].ToString());
                isSuccess = isSuccess && Dao_trans.SqlUpdate(sql, ref sbMsg);
            }
        }
        catch (Exception ex)
        {
            isSuccess = false;
        }
        finally
        {
            if (isSuccess)
                Dao_trans.Commit();
            else
                Dao_trans.Rollback();
            Dao_trans.SqlConn.Close();
        }
        return isSuccess;
    }
}