﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

/// <summary>
/// CheckPRAmount 的摘要描述
/// </summary>
public class CheckPRAmount
{
	public CheckPRAmount()
	{
		//
		// TODO: 在這裡新增建構函式邏輯
		//
	}

    //===================================採購單主檔/明細檔=======================================================================
    /// <summary>
    /// 取得採購單主檔及明細檔資料
    /// </summary>
    /// <param name="dao"></param>
    /// <param name="dtMaster"></param>
    /// <param name="dtDetail"></param>
    public void GetMasterDetailDataTable_PR0C(ERP.DBDao dao, out System.Data.DataTable dtMaster, out System.Data.DataTable dtDetail)
    {
        dtMaster = GetCheckAmount_PR0CM(dao);
        dtMaster.TableName = "[V]採購單主檔"; //[V]:Table Name有標示[V],則在Mail Body要顯示此內容.

        dtDetail = GetCheckAmount_PR0CS1A(dao);
        dtDetail.TableName = "採購單明細檔";
    }

    #region 採購單主檔/明細檔
    /// <summary>
    /// Mail Report: 取得PR0CM的DataTable (採購單主檔)
    /// </summary>
    /// <param name="dao"></param>
    /// <returns></returns>
    private DataTable GetCheckAmount_PR0CM(ERP.DBDao dao)
    {
        string sqlPR0CM = this.GetSQL_CheckAmount_PR0CM();
        System.Data.DataTable dtPR0CM = dao.SqlSelect(sqlPR0CM);
        return dtPR0CM;
    }

    //取得SQL statement
    private string GetSQL_CheckAmount_PR0CM()
    {
        ERP.DBDao dao = new ERP.DBDao();

        string sql = dao.SqlSelectToString(@"
                                            SELECT SQL
                                            FROM SQLList (NOLOCK)
                                            WHERE ProgramName = 'CheckPRAmount-金額驗算差異報表(採購單主檔)' ", "SQL");
        return sql;
    }

    /// <summary>
    /// Mail Report: 取得PR0CS1A的DataTable (採購單明細檔)
    /// </summary>
    /// <param name="dao"></param>
    /// <returns></returns>
    private DataTable GetCheckAmount_PR0CS1A(ERP.DBDao dao)
    {
        string sqlPR0CS1A = this.GetSQL_CheckAmount_PR0CS1A();
        System.Data.DataTable dtPR0CS1A = dao.SqlSelect(sqlPR0CS1A);
        return dtPR0CS1A;
    }

    //取得SQL statement
    private string GetSQL_CheckAmount_PR0CS1A()
    {
        ERP.DBDao dao = new ERP.DBDao();

        string sql = dao.SqlSelectToString(@"
                                            SELECT SQL
                                            FROM SQLList (NOLOCK)
                                            WHERE ProgramName = 'CheckPRAmount-金額驗算差異報表(採購單明細檔)' ", "SQL");
        return sql;
    }
    #endregion

    //===================================採購單歷程主檔/明細檔=======================================================================
    /// <summary>
    /// 取得採購單歷程主檔及明細檔資料
    /// </summary>
    /// <param name="dao"></param>
    /// <param name="dtMaster"></param>
    /// <param name="dtDetail"></param>
    public void GetMasterDetailDataTable_PR0D(ERP.DBDao dao, out System.Data.DataTable dtMaster, out System.Data.DataTable dtDetail)
    {
        dtMaster = GetCheckAmount_PR0DM(dao);
        dtMaster.TableName = "[V]採購單歷程主檔"; //[V]:Table Name有標示[V],則在Mail Body要顯示此內容.

        dtDetail = GetCheckAmount_PR0DS1A(dao);
        dtDetail.TableName = "採購單歷程明細檔";
    }

    #region 採購單歷程主檔及明細檔
    /// <summary>
    /// Mail Report: 取得PR0DM的DataTable (採購單歷程主檔)
    /// </summary>
    /// <param name="dao"></param>
    /// <returns></returns>
    private DataTable GetCheckAmount_PR0DM(ERP.DBDao dao)
    {
        string sqlPR0DM = this.GetSQL_CheckAmount_PR0DM();
        DataTable dtPR0DM = dao.SqlSelect(sqlPR0DM);
        return dtPR0DM;
    }

    //取得SQL statement
    private string GetSQL_CheckAmount_PR0DM()
    {
        ERP.DBDao dao = new ERP.DBDao();

        string sql = dao.SqlSelectToString(@"
                                            SELECT SQL
                                            FROM SQLList (NOLOCK)
                                            WHERE ProgramName = 'CheckPRAmount-金額驗算差異報表(採購單歷程主檔)' ", "SQL");
        return sql;
    }

    /// <summary>
    /// Mail Report: 取得PR0DS1A的DataTable (採購單歷程明細檔)
    /// </summary>
    /// <param name="dao"></param>
    /// <returns></returns>
    private DataTable GetCheckAmount_PR0DS1A(ERP.DBDao dao)
    {
        string sqlPR0DS1A = this.GetSQL_CheckAmount_PR0DS1A();
        System.Data.DataTable dtPR0DS1A = dao.SqlSelect(sqlPR0DS1A);
        return dtPR0DS1A;
    }

    //取得SQL statement
    private string GetSQL_CheckAmount_PR0DS1A()
    {
        ERP.DBDao dao = new ERP.DBDao();

        string sql = dao.SqlSelectToString(@"
                                            SELECT SQL
                                            FROM SQLList (NOLOCK)
                                            WHERE ProgramName = 'CheckPRAmount-金額驗算差異報表(採購單歷程明細檔)' ", "SQL");
        return sql;
    }
    #endregion

    //===================================驗收單歷程主檔/明細檔=======================================================================
    /// <summary>
    /// 取得驗收單主檔及明細檔資料
    /// </summary>
    /// <param name="dao"></param>
    /// <param name="dtMaster"></param>
    /// <param name="dtDetail"></param>
    public void GetMasterDetailDataTable_PR0E(ERP.DBDao dao, out System.Data.DataTable dtMaster, out System.Data.DataTable dtDetail)
    {
        dtMaster = GetCheckAmount_PR0EM(dao);
        dtMaster.TableName = "[V]驗收單主檔"; //[V]:Table Name有標示[V],則在Mail Body要顯示此內容.

        dtDetail = GetCheckAmount_PR0ES1A(dao);
        dtDetail.TableName = "驗收單明細檔";
    }

    #region 驗收單主檔及明細檔
    /// <summary>
    /// Mail Report: 取得PR0EM的DataTable (驗收單主檔)
    /// </summary>
    /// <param name="dao"></param>
    /// <returns></returns>
    private DataTable GetCheckAmount_PR0EM(ERP.DBDao dao)
    {
        string sqlPR0EM = this.GetSQL_CheckAmount_PR0EM();
        DataTable dtPR0EM = dao.SqlSelect(sqlPR0EM);
        return dtPR0EM;
    }

    //取得SQL statement
    private string GetSQL_CheckAmount_PR0EM()
    {
        ERP.DBDao dao = new ERP.DBDao();

        string sql = dao.SqlSelectToString(@"
                                            SELECT SQL
                                            FROM SQLList (NOLOCK)
                                            WHERE ProgramName = 'CheckPRAmount-金額驗算差異報表(驗收單主檔)' ", "SQL");
        return sql;
    }

    /// <summary>
    /// Mail Report: 取得PR0ES1A的DataTable (驗收單明細檔)
    /// </summary>
    /// <param name="dao"></param>
    /// <returns></returns>
    private DataTable GetCheckAmount_PR0ES1A(ERP.DBDao dao)
    {
        string sqlPR0ES1A = this.GetSQL_CheckAmount_PR0ES1A();
        System.Data.DataTable dtPR0ES1A = dao.SqlSelect(sqlPR0ES1A);
        return dtPR0ES1A;
    }

    //取得SQL statement
    private string GetSQL_CheckAmount_PR0ES1A()
    {
        ERP.DBDao dao = new ERP.DBDao();

        string sql = dao.SqlSelectToString(@"
                                            SELECT SQL
                                            FROM SQLList (NOLOCK)
                                            WHERE ProgramName = 'CheckPRAmount-金額驗算差異報表(驗收單明細檔)' ", "SQL");
        return sql;
    }
    #endregion



}