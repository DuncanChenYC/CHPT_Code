﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERP
{
    class LogFile
    {
        string path;
        public LogFile(string fileName)
        {
            string directory = AppDomain.CurrentDomain.BaseDirectory;
            string logFileName = string.Format("{0}.txt", fileName);
            path = string.Format(@"{0}{1}", directory, logFileName);
        }

        public LogFile(string logFilePath, string fileName)
        {
            string directory = AppDomain.CurrentDomain.BaseDirectory;
            string logFileName = string.Format("{0}.txt", fileName);
            path = string.Format(@"{0}\{1}\{2}", directory, logFilePath, logFileName);
        }

        public string WriteLog(string logMsg)
        {
            System.Text.StringBuilder sbMsg = new StringBuilder();
            try
            {
                string txtContent = "";
                if (!System.IO.File.Exists(path))
                    System.IO.File.Create(path).Close();
                else
                {
                    System.IO.StreamReader sr = new System.IO.StreamReader(path, Encoding.UTF8);
                    txtContent = sr.ReadToEnd();
                    sr.Close();
                }

                System.IO.StreamWriter sw = new System.IO.StreamWriter(path);
                sw.WriteLine(string.Format("{0}{1}", txtContent, logMsg));
                sw.Close();
            }
            catch (Exception ex)
            {
                sbMsg.Append(ex.Message);
            }
            return sbMsg.ToString();
        }
    }
}
