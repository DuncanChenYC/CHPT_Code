﻿using System;
using System.Data;

internal class WF_GetPushData
{
    public DataTable GetPushData()
    {
        ERP.DBDao Dao_select = new ERP.DBDao();

        #region 取得資料

        DataTable dt = new DataTable();
        string sql = @"SELECT  C.FormName AS 表單類別, X.FormNo AS 表單編號, B.FormTopic AS 主旨, D.EmployeeName AS 申請人,
			                E2.DeptName AS 待簽部門, E1.EmployeeNo AS 待簽人工號, E1.EmployeeName AS 待簽人姓名,'ERP' AS ERP
	                        FROM WF0XS1A (NOLOCK) AS X
	                        INNER JOIN WF0XM AS B WITH (NOLOCK) ON B.FormNo=X.FormNo AND ISNULL(B.PushTime,0)>0 AND B.SignStatus IN ('1')
	                        INNER JOIN WF0AM AS C WITH (NOLOCK) ON C.FormCode=SUBSTRING(B.FormNo,1,LEN(C.FormCode))
	                        INNER JOIN HR0AM AS D WITH (NOLOCK) ON D.EmployeeNo=B.FromUser
	                        INNER JOIN HR0AM AS E1 (NOLOCK) ON X.ToUser = E1.EmployeeNo AND E1.AdmissionState = '1'
							INNER JOIN Dept AS E2 (NOLOCK) ON E1.DeptNo = E2.DeptNo
							INNER JOIN VW_HR_Up3DeptLevel AS D3 ON X.ToUser = D3.EmployeeNo
	                        WHERE  CanSignUp='1' AND ISNULL(InvalidDate,'')='' AND ISNULL(X.ToUser, '') != ''
							AND C.FormCode<>'WF16P' AND C.FormCode<>'WF10P' AND C.FormCode<>'WF09P'
							AND SUBSTRING(X.FormNo, 6, 2) >= '16'
							AND DATEDIFF(MINUTE, CONVERT(CHAR(16), DATEADD(minute, (CASE B.PushTimeUnit
																	WHEN 'D' THEN B.PushTime*24*60
																	WHEN 'H' THEN B.PushTime*60
																	WHEN 'M' THEN B.PushTime
																	ELSE 0
																	END), X.FromDate),120), GETDATE()) >= 0
							ORDER BY C.FormName,  X.FromDate DESC";

        #endregion 取得資料

        dt = Dao_select.SqlSelect(sql);
        dt.TableName = "[V]";
        
        return dt;
    }

    public bool UpdateWF0XS1AToDate()
    {
        ERP.DBDao Dao_trans = new ERP.DBDao();
        Dao_trans.SqlConn.Open();
        Dao_trans.BeginTransaction();

        bool isSuccess = true;
        System.Text.StringBuilder sbMsg = new System.Text.StringBuilder();

        try
        {
            System.Data.DataTable dt = GetPushData();

           string sql = @"UPDATE WF0XS1A SET ToDate = GETDATE()
                            WHERE FormNo = @FormNo AND ToUser = @ToUser AND CanSignUp = '1' ";
            foreach (DataRow dr in dt.Rows)
            {                
                Dao_trans.SqlCommand.Parameters.Clear();
                Dao_trans.SqlCommand.Parameters.AddWithValue("@FormNo", dr["表單編號"].ToString());
                Dao_trans.SqlCommand.Parameters.AddWithValue("@ToUser", dr["待簽人工號"].ToString());
                isSuccess = isSuccess && Dao_trans.SqlUpdate(sql, ref sbMsg);
            }
        }
        catch (Exception ex)
        {
            isSuccess = false;
        }
        finally
        {
            if (isSuccess)
                Dao_trans.Commit();
            else
                Dao_trans.Rollback();
            Dao_trans.SqlConn.Close();
        }
        return isSuccess;
    }
}