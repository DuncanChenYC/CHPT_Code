﻿using System;
using System.Data;
using System.Linq;

public class MItem_SafeQtyCheck
{
    public DataTable DayCheck()
    {
        ERP.DBDao Dao = new ERP.DBDao();

        #region 取得資料

        DataTable dt_Result = new DataTable();
        dt_Result.TableName = "[V]";
        dt_Result.Columns.Add("項次", typeof(Int32));             //項次
        dt_Result.Columns.Add("料號", typeof(string));            //料號
        dt_Result.Columns.Add("品名", typeof(string));            //品名
        dt_Result.Columns.Add("現況庫存數量", typeof(double));    //現況庫存數量
        dt_Result.Columns.Add("單位", typeof(string));            //單位
        dt_Result.Columns.Add("安全存量", typeof(double));  //安全存量
        dt_Result.Columns.Add("不足數", typeof(double));       //不足數 (現況庫存-安全存量)
        dt_Result.Columns.Add("標準LT", typeof(Int32));
        dt_Result.Columns.Add("平均LT", typeof(Int32));
        dt_Result.Columns.Add("最後一次請購日", typeof(string));       //最後一次請購日
        dt_Result.Columns.Add("最後一次請購數", typeof(double));       //最後一次請購數
        dt_Result.Columns.Add("最後一次出庫日", typeof(string));       //最後一次出庫日
        dt_Result.Columns.Add("最後一次出庫數", typeof(double));      //最後一次出庫數

        string sql_PR = @"
                SELECT ItemNo, CONVERT(VARCHAR(100), PR0AS1A.CreateDate, 111) AS PR0A_Date, SUM(PR0AS1A.QTY) AS QTY FROM PR0AS1A (NOLOCK)
		        INNER JOIN PR0AM (NOLOCK) ON PR0AS1A.PID = PR0AM.ID
		        WHERE ISNULL(PR0AM.InvalidDate, '') = ''
		        GROUP BY ItemNo, PR0AS1A.CreateDate
		        ORDER BY PR0AS1A.CreateDate DESC";
        DataTable dt_PR = Dao.SqlSelect(sql_PR);

        string sql_MT = @"
                SELECT ItemNo, CONVERT(VARCHAR(100), MT0AS1A.CreateDate, 111) AS MT12_Date, SUM(ISNULL(MT0AS1A.QTY, 0)) AS QTY FROM MT0AS1A (NOLOCK)
		        INNER JOIN MT0AM (NOLOCK) ON MT0AS1A.PID = MT0AM.ID
		        WHERE MT0AM.SignResult = 'A' AND ISNULL(MT0AM.InvalidDate, '') = ''
		        GROUP BY ItemNo, MT0AS1A.CreateDate
		        ORDER BY MT0AS1A.CreateDate DESC";
        DataTable dt_MT = Dao.SqlSelect(sql_MT);

        string sql = @"
                SELECT A.ItemNo, A.ItemDescrip
	                , ISNULL(D.ThisEndQTY, 0) AS ThisEndQTY
	                , A.INVUnit
	                , ISNULL(A.SaftQTY, 0) AS SaftQTY
	                , ROUND(ISNULL(D.ThisEndQTY, 0) - ISNULL(A.SaftQTY, 0), 3) AS NEnoughQTY
	                , ISNULL(P.StandardLT, 0) AS StandardLT, ISNULL(P.AvgDay, 0) AS AvgDay
                FROM RD0CM (NOLOCK) AS A
                LEFT OUTER JOIN MT115P(CONVERT(NVARCHAR, GETDATE(), 111)) AS D ON D.ItemNo=A.ItemNo AND D.ItemVer=A.ItemVer
				LEFT JOIN (
					SELECT ItemNo, ItemVer
						--, COUNT(ItemNo) AS CountQty
						, AVG(StandardLT) AS StandardLT
						--, MAX(DayDiff) AS MaxDay
						, CEILING(SUM(DayDiff) / CONVERT(DECIMAL(18, 1), COUNT(ItemNo))) AS AvgDay
						--, MIN(DayDiff) MinDay
						--, MAX(MT03MCreateDate) AS MaxMT03MCreateDate
					FROM dbo.VW_PR_Leadtime
					--WHERE ItemNo = '231100007901' AND ItemVer = 'A'
					GROUP BY ItemNo, ItemVer
				) P ON A.ItemNo = P.ItemNo AND A.ItemVer = P.ItemVer
                WHERE A.SaftQTY > 0 AND ISNULL(ThisEndQTY, 0) - ISNULL(A.SaftQTY, 0) < 0 
                        AND A.ItemAccountNo IN ('M', 'B') AND ISNULL(A.InvalidDate, '') = '' ";
        DataTable dt = Dao.SqlSelect(sql);

        int index = 1;
        foreach (DataRow dr in dt.Rows)
        {
            DataRow dr_Result = dt_Result.NewRow();
            dr_Result["項次"] = index.ToString();
            dr_Result["料號"] = dr["ItemNo"].ToString();
            dr_Result["品名"] = dr["ItemDescrip"].ToString();
            dr_Result["現況庫存數量"] = dr["ThisEndQTY"].ToString();
            dr_Result["單位"] = dr["INVUnit"].ToString();
            dr_Result["安全存量"] = dr["SaftQTY"].ToString();
            dr_Result["不足數"] = dr["NEnoughQTY"].ToString();
            dr_Result["標準LT"] = dr["StandardLT"].ToString();
            dr_Result["平均LT"] = dr["AvgDay"].ToString();
            
            #region 最近一次請購

            var linq_PR = from row in dt_PR.AsEnumerable()
                          where row.Field<string>("ItemNo") == dr["ItemNo"].ToString()
                          orderby row["PR0A_Date"] descending
                          select new
                          {
                              PR0A_Date = row.Field<string>("PR0A_Date"),
                              PR0A_Qty = row.Field<double>("QTY").ToString()
                          };

            foreach (var l in linq_PR.Take(1))
            {
                dr_Result["最後一次請購日"] = l.PR0A_Date;
                dr_Result["最後一次請購數"] = l.PR0A_Qty;
            }

            #endregion 最近一次請購

            #region 最近一次出庫

            var linq_MT = from row in dt_MT.AsEnumerable()
                          where row.Field<string>("ItemNo") == dr["ItemNo"].ToString()
                          orderby row["MT12_Date"] descending
                          select new
                          {
                              MT12_Date = row.Field<string>("MT12_Date"),
                              MT12_Qty = row.Field<double>("QTY").ToString()
                          };

            foreach (var l in linq_MT.Take(1))
            {
                dr_Result["最後一次出庫日"] = l.MT12_Date;
                dr_Result["最後一次出庫數"] = l.MT12_Qty;
            }

            #endregion 最近一次出庫

            dt_Result.Rows.Add(dr_Result);
            index++;
        }

        #endregion 取得資料

        return dt_Result;
    }

    public DataTable MonthCheck()
    {
        ERP.DBDao Dao = new ERP.DBDao();

        #region 取得資料

        DataTable dt_Result = new DataTable();
        dt_Result.TableName = "[V]";
        dt_Result.Columns.Add("項次", typeof(Int32));           //項次
        dt_Result.Columns.Add("料號", typeof(string));       //料號
        dt_Result.Columns.Add("品名", typeof(string));  //品名
        dt_Result.Columns.Add("單位", typeof(string));      //單位
        dt_Result.Columns.Add("安全存量", typeof(Int32));       //安全存量
        dt_Result.Columns.Add("AVG出庫量(月)_過去一季", typeof(Int32));    //AVG出庫量(月)_過去一季
        dt_Result.Columns.Add("AVG出庫量(月)_過去半年", typeof(string));    //AVG出庫量(月)_過去半年
        dt_Result.Columns.Add("AVG出庫量(月)_過去一年", typeof(Int32));      //AVG出庫量(月)_過去一年
        dt_Result.Columns.Add("累計出庫量", typeof(string));    //累計出庫量
        dt_Result.Columns.Add("累計AVG(月)", typeof(Int32));      //累計AVG(月)

        string sql_MT = @"SELECT MT0AS1A.ItemNo, ISNULL(MT0AS1A.QTY, 0) AS QTY, DATEDIFF(MONTH, MT0AM.CreateDate, GETDATE()) AS DateRange FROM MT0AM (NOLOCK)
                              INNER JOIN MT0AS1A (NOLOCK) ON MT0AM.ID = MT0AS1A.PID
                              WHERE FormNo LIKE 'MT12%' AND SignResult = 'A' AND ISNULL(MT0AM.InvalidDate, '') = '' ";
        DataTable dt_MT = Dao.SqlSelect(sql_MT);

        string sql = @"SELECT A.ItemNo, A.ItemDescrip, ISNULL(D.ThisEndQTY, 0) AS ThisEndQTY, A.INVUnit, CAST(A.SaftQTY AS INT) AS SaftQTY, ISNULL(ThisEndQTY, 0) - ISNULL(A.SaftQTY, 0) AS NEnoughQTY
                           FROM RD0CM (NOLOCK) AS A
                           LEFT OUTER JOIN MT115P(CONVERT(NVARCHAR(100), GETDATE(), 111)) AS D ON D.ItemNo=A.ItemNo AND D.ItemVer=A.ItemVer
                           WHERE A.SaftQTY > 0";
        DataTable dt = Dao.SqlSelect(sql);

        int index = 1;
        foreach (DataRow dr in dt.Rows)
        {
            DataRow dr_Result = dt_Result.NewRow();
            dr_Result["項次"] = index.ToString();
            dr_Result["料號"] = dr["ItemNo"].ToString();
            dr_Result["品名"] = dr["ItemDescrip"].ToString();
            dr_Result["單位"] = dr["INVUnit"].ToString();
            dr_Result["安全存量"] = dr["SaftQTY"].ToString();

            #region AVG出庫量(月)_過去一季

            var linq_MT12_AQty_Month = from row in dt_MT.AsEnumerable()
                                       where row.Field<string>("ItemNo") == dr["ItemNo"].ToString() && row.Field<Int32>("DateRange") <= 1
                                       group row by row["ItemNo"] into g
                                       select new
                                       {
                                           ItemNo = g.Key,
                                           MT12_AQty_Month = g.Sum(row => row.Field<double>("QTY"))
                                       };

            foreach (var l in linq_MT12_AQty_Month)
            {
                dr_Result["AVG出庫量(月)_過去一季"] = l.MT12_AQty_Month;
            }

            #endregion AVG出庫量(月)_過去一季

            #region AVG出庫量(月)_過去半年

            var linq_MT12_AQty_HalfYear = from row in dt_MT.AsEnumerable()
                                          where row.Field<string>("ItemNo") == dr["ItemNo"].ToString() && row.Field<Int32>("DateRange") <= 6
                                          group row by row["ItemNo"] into g
                                          select new
                                          {
                                              ItemNo = g.Key,
                                              MT12_AQty_HalfYear = Math.Round(g.Sum(row => row.Field<double>("QTY")) / 6, 0)
                                          };

            foreach (var l in linq_MT12_AQty_HalfYear)
            {
                dr_Result["AVG出庫量(月)_過去半年"] = l.MT12_AQty_HalfYear;
            }

            #endregion AVG出庫量(月)_過去半年

            #region AVG出庫量(月)_過去一年

            var linq_MT12_AQty_Year = from row in dt_MT.AsEnumerable()
                                      where row.Field<string>("ItemNo") == dr["ItemNo"].ToString() && row.Field<Int32>("DateRange") <= 12
                                      group row by row["ItemNo"] into g
                                      select new
                                      {
                                          ItemNo = g.Key,
                                          MT12_AQty_Year = Math.Round(g.Sum(row => row.Field<double>("QTY")) / 12, 0)
                                      };

            foreach (var l in linq_MT12_AQty_Year)
            {
                dr_Result["AVG出庫量(月)_過去一年"] = l.MT12_AQty_Year;
            }

            #endregion AVG出庫量(月)_過去一年

            #region 累計出庫量

            var linq_MT12_TQty = from row in dt_MT.AsEnumerable()
                                 where row.Field<string>("ItemNo") == dr["ItemNo"].ToString()
                                 group row by row["ItemNo"] into g
                                 select new
                                 {
                                     ItemNo = g.Key,
                                     MT12_TQty = g.Sum(row => row.Field<double>("QTY"))
                                 };

            foreach (var l in linq_MT12_TQty)
            {
                dr_Result["累計出庫量"] = l.MT12_TQty;
            }

            #endregion 累計出庫量

            #region 累計AVG(月)

            var linq_MT12_ATQty_Month = from row in dt_MT.AsEnumerable()
                                        where row.Field<string>("ItemNo") == dr["ItemNo"].ToString()
                                        group row by row["ItemNo"] into g
                                        select new
                                        {
                                            ItemNo = g.Key,
                                            DateRange = g.Max(row => row.Field<int>("DateRange"))
                                        };

            foreach (var l in linq_MT12_ATQty_Month)
            {
                dr_Result["累計AVG(月)"] = Math.Round(Convert.ToDouble(Convert.ToInt32(dr_Result["MT12_TQty"].ToString()) / l.DateRange), 0);
            }

            #endregion 累計AVG(月)

            dt_Result.Rows.Add(dr_Result);
            index++;
        }

        #endregion 取得資料

        return dt_Result;
    }
}