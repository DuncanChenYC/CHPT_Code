﻿using System;
using System.Data;
using System.Linq;
using System.Text;

namespace MailReprot
{
    internal class Start
    {
        private static void Main(string[] args)
        {
            #region 測試使用

            bool isTest = false;
            /*true：Tab，false：正式發送*/
            bool isSendMailToTab = false;
            string testID = "";
            if (isTest)
                testID = " AND ID IN (539)";

            #endregion 測試使用

            System.Text.StringBuilder sbLog = new StringBuilder();
            sbLog.AppendFormat(System.Environment.NewLine + "/*  啟動時間：{0}  是否測試：{1}*/", System.DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss"), isTest);

            SendMail send = new SendMail();
            System.Text.StringBuilder sbMsg = new StringBuilder();

            string templateSubject = "", mailFrom = "", mailTo = "", mailCc = "", mailBcc = "";
            try
            {
                System.DateTime dtimeNow;
                if (isTest)
                    dtimeNow = new DateTime(2019, 07, 11, 16, 30, 00);
                else
                    dtimeNow = System.DateTime.Now;
                //dtimeNow = new DateTime(2018, 05, 25, 05, 00, 00);

                string weekIndex = dtimeNow.DayOfWeek.ToString("d");

                #region 固定日期轉換

                int nowDay = dtimeNow.Day;
                string fixedDate = "";
                if (nowDay == 1)
                    fixedDate = "F";
                else
                {
                    int endDay = Convert.ToDateTime(DateTime.Now.ToString("yyyy/MM/") + "01").AddMonths(1).AddDays(-1).Day;
                    if (nowDay == endDay)
                        fixedDate = "E";
                    else
                        fixedDate = nowDay.ToString("D2");
                }

                #endregion 固定日期轉換

                #region 取得符合資料的SQL語法

                string CHPTConnStr = string.Format(System.Configuration.ConfigurationManager.ConnectionStrings["ConnectionString"].ToString(), "CHPT");
                ERP.DBDao daoCHPT = new ERP.DBDao(CHPTConnStr);
                string sqlQuery = string.Format(@"
					SELECT MailPriority, Subject, MailContent, IsExternalClass, IsAttachmentExcel, IsHeader, FileName
                        , DBConnName, ReportSQL, MailToSQL, MailCcSQL, MailBccSQL
                        , RelationalMailToSQL, RelationalMailCcSQL, RelationalMailBccSQL
                        , FixedDate, FixedDateTime
                        , CycleTimeDaily, StartTime, EndTime, CycleTimeMinute
					FROM dbo.MailReportSetting WITH(NOLOCK)
					WHERE IsInvalid = '0' AND (CycleTimeDaily LIKE @CycleTimeDaily OR FixedDate LIKE @FixedDate)
                        {0}
                    ORDER BY StartTime, ID DESC ", testID);
                daoCHPT.SqlCommand.Parameters.Clear();
                daoCHPT.SqlCommand.Parameters.AddWithValue("@CycleTimeDaily", string.Format("%{0}%", weekIndex));
                daoCHPT.SqlCommand.Parameters.AddWithValue("@FixedDate", string.Format("%{0}%", fixedDate));
                System.Data.DataTable dtMailReport = daoCHPT.SqlSelect(sqlQuery);

                #endregion 取得符合資料的SQL語法

                //查看是否有符合的週期(星期幾)
                if (dtMailReport.Rows.Count > 0)
                {
                    #region 參數定義

                    bool isSuccss, isAttachment, isExecOtherAction;
                    System.Net.Mail.MailPriority mailPriority;
                    string strMailPriority, mailContent, sqlReport, sqlMailSQL, sqlRelationalMailToSQL, sqlRelationalMailCcSQL, sqlRelationalMailBccSQL, fileName, DBConnName;
                    //System.Data.DataTable dtReport = new System.Data.DataTable();
                    System.Data.DataTable dtRelationalMailTo = new System.Data.DataTable();
                    System.Data.DataTable dtRelationalMailCc = new System.Data.DataTable();
                    System.Data.DataTable dtRelationalMailBcc = new System.Data.DataTable();
                    System.Data.DataSet dsAllReport = new System.Data.DataSet();
                    System.Data.DataSet dsReport = new System.Data.DataSet();
                    System.Data.DataSet dsTempReport = new System.Data.DataSet();
                    System.DateTime dtimeStart, dtimeEnd;

                    #endregion 參數定義

                    foreach (System.Data.DataRow dr in dtMailReport.Rows)
                    {
                        try
                        {
                            DBConnName = dr["DBConnName"].ToString();
                            string ConnStr = string.Format(System.Configuration.ConfigurationManager.ConnectionStrings["ConnectionString"].ToString(), DBConnName);
                            ERP.DBDao dao = new ERP.DBDao(ConnStr);

                            isSuccss = true;
                            isExecOtherAction = false;

                            mailFrom = "ERP小組 <mailReport@cht-pt.com.tw>";
                            templateSubject = dr["Subject"].ToString();
                            dsAllReport.Tables.Clear();

                            bool isOverDay = false;
                            bool isFixedDate = (dr["FixedDate"].ToString() != "");

                            dtimeStart = Convert.ToDateTime(dtimeNow.ToString("yyyy/MM/dd") + " " + (isFixedDate ? dr["FixedDateTime"].ToString() : dr["StartTime"].ToString()));
                            dtimeEnd = Convert.ToDateTime(dtimeNow.ToString("yyyy/MM/dd") + " " + (isFixedDate ? dr["FixedDateTime"].ToString() : dr["EndTime"].ToString()));

                            #region 若結束時間比起始時間還小，則需加一日

                            if (dtimeStart.CompareTo(dtimeEnd) >= 0)
                            {
                                isOverDay = true;
                                dtimeEnd = dtimeEnd.AddDays(1);
                            }

                            #endregion 若結束時間比起始時間還小，則需加一日

                            int addMinutes = 10;
                            dtimeEnd = dtimeEnd.AddMinutes(addMinutes);

                            if (dtimeEnd.CompareTo(dtimeNow) >= 0)
                            {
                                #region 確認時間是否符合，可誤差5分鐘

                                int cycleMinute = Convert.ToInt32(dr["CycleTimeMinute"]);
                                if (CheckExecTime(isFixedDate, dtimeStart, dtimeEnd, dtimeNow, isOverDay, cycleMinute, addMinutes))
                                {
                                    #region 確認是否符合執行時間

                                    string filePath = "";
                                    bool isContinue = false;
                                    try
                                    {
                                        if (Convert.ToBoolean(dr["IsExternalClass"]))
                                        {
                                            #region 特殊來源透過External的Class取得Mail內容的資料

                                            string externalClass = dr["ReportSQL"].ToString();
                                            if (externalClass.IndexOf("SQLListID=") == 0)
                                            {
                                                string SQLListID = externalClass.Replace("SQLListID=", "");
                                                System.Data.DataTable dtSQLList = GetSQLListDataTable(ConnStr, SQLListID);

                                                dsAllReport.Tables.Add(dtSQLList);
                                                isContinue = (dtSQLList.Rows.Count == 0);
                                            }
                                            else
                                            {
                                                #region Switch Case

                                                switch (externalClass)
                                                {
                                                    case "EEP_Reminder_1Day":
                                                        EEP_Reminder eepReminder1 = new EEP_Reminder();
                                                        System.Data.DataTable dtReminder1 = eepReminder1.GetEEP_Reminder(1);

                                                        dsAllReport.Tables.Add(dtReminder1);
                                                        isExecOtherAction = (dtReminder1.Rows.Count > 0);
                                                        isContinue = (dtReminder1.Rows.Count == 0);
                                                        break;

                                                    case "EEP_Reminder_2Day":
                                                        EEP_Reminder eepReminder2 = new EEP_Reminder();
                                                        System.Data.DataTable dtReminder2 = eepReminder2.GetEEP_Reminder(2);

                                                        dsAllReport.Tables.Add(dtReminder2);
                                                        isExecOtherAction = (dtReminder2.Rows.Count > 0);
                                                        isContinue = (dtReminder2.Rows.Count == 0);
                                                        break;

                                                    case "EEP_Reminder_3Day":
                                                        EEP_Reminder eepReminder3 = new EEP_Reminder();
                                                        System.Data.DataTable dtReminder3 = eepReminder3.GetEEP_Reminder(3);

                                                        dsAllReport.Tables.Add(dtReminder3);
                                                        isExecOtherAction = (dtReminder3.Rows.Count > 0);
                                                        isContinue = (dtReminder3.Rows.Count == 0);
                                                        break;

                                                    case "SA29PClass":
                                                        SA29PClass sa29p = new SA29PClass();
                                                        System.Data.DataTable dtSA29PDetail = sa29p.SA29P_QueryNonSendOrder();

                                                        dsAllReport.Tables.Add(dtSA29PDetail);
                                                        isContinue = (dtSA29PDetail.Rows.Count == 0);
                                                        break;

                                                    case "MF29PClass":
                                                        MF29PClass mf29p = new MF29PClass();
                                                        System.Data.DataTable dtGroup;
                                                        System.Data.DataTable dtDetail;
                                                        mf29p.GetGroupDetailDataTable(dao, "", System.DateTime.Now.AddDays(-1).ToString("yyyy/MM/dd"), 8, out dtGroup, out dtDetail);

                                                        dsAllReport.Tables.Add(dtGroup);
                                                        dsAllReport.Tables.Add(dtDetail);

                                                        isContinue = (dtGroup.Rows.Count == 0);
                                                        break;

                                                    case "MItem_SafeQty_DayCheck":
                                                        MItem_SafeQtyCheck safeQtyDayCheck = new MItem_SafeQtyCheck();
                                                        System.Data.DataTable dtDayCheck = safeQtyDayCheck.DayCheck();

                                                        dsAllReport.Tables.Add(dtDayCheck);
                                                        isContinue = (dtDayCheck.Rows.Count == 0);
                                                        break;

                                                    case "MItem_SafeQty_MonthCheck":
                                                        MItem_SafeQtyCheck safeQtyMonthCheck = new MItem_SafeQtyCheck();
                                                        System.Data.DataTable dtMonthCheck = safeQtyMonthCheck.MonthCheck();

                                                        dsAllReport.Tables.Add(dtMonthCheck);
                                                        isContinue = (dtMonthCheck.Rows.Count == 0);
                                                        break;

                                                    case "WF_GetPushData":
                                                        WF_GetPushData wfGetPushData = new WF_GetPushData();
                                                        System.Data.DataTable dtPushData = wfGetPushData.GetPushData();

                                                        dsAllReport.Tables.Add(dtPushData);
                                                        isExecOtherAction = (dtPushData.Rows.Count > 0);
                                                        isContinue = (dtPushData.Rows.Count == 0);
                                                        break;

                                                    case "CheckPRAmount_PR0C":
                                                        CheckPRAmount prAmountPR0C = new CheckPRAmount();
                                                        System.Data.DataTable dtPR0CMaster;
                                                        System.Data.DataTable dtPR0CDetail;
                                                        prAmountPR0C.GetMasterDetailDataTable_PR0C(dao, out dtPR0CMaster, out dtPR0CDetail);

                                                        dsAllReport.Tables.Add(dtPR0CMaster);
                                                        dsAllReport.Tables.Add(dtPR0CDetail);

                                                        isContinue = (dtPR0CMaster.Rows.Count == 0);
                                                        break;

                                                    case "CheckPRAmount_PR0D":
                                                        CheckPRAmount prAmountPR0D = new CheckPRAmount();
                                                        System.Data.DataTable dtPR0DMaster;
                                                        System.Data.DataTable dtPR0DDetail;
                                                        prAmountPR0D.GetMasterDetailDataTable_PR0D(dao, out dtPR0DMaster, out dtPR0DDetail);

                                                        dsAllReport.Tables.Add(dtPR0DMaster);
                                                        dsAllReport.Tables.Add(dtPR0DDetail);

                                                        isContinue = (dtPR0DMaster.Rows.Count == 0);
                                                        break;

                                                    case "CheckPRAmount_PR0E":
                                                        CheckPRAmount prAmountPR0E = new CheckPRAmount();
                                                        System.Data.DataTable dtPR0EMaster;
                                                        System.Data.DataTable dtPR0EDetail;
                                                        prAmountPR0E.GetMasterDetailDataTable_PR0E(dao, out dtPR0EMaster, out dtPR0EDetail);

                                                        dsAllReport.Tables.Add(dtPR0EMaster);
                                                        dsAllReport.Tables.Add(dtPR0EDetail);

                                                        isContinue = (dtPR0EMaster.Rows.Count == 0);
                                                        break;

                                                    case "ITReport":
                                                        ITReport IT = new ITReport();
                                                        System.Data.DataTable dtITReport = IT.GetITReportDataTable(dao);

                                                        dsAllReport.Tables.Add(dtITReport);

                                                        isExecOtherAction = (dtITReport.Rows.Count > 0);
                                                        isContinue = (dtITReport.Rows.Count == 0);
                                                        break;
                                                }

                                                #endregion Switch Case
                                            }

                                            #endregion 特殊來源透過External的Class取得Mail內容的資料
                                        }
                                        else
                                        {
                                            #region 透過ReportSQL取得Mail內容的資料

                                            sqlReport = dr["ReportSQL"].ToString();
                                            System.Data.DataTable dtReport = dao.SqlSelect(sqlReport);
                                            dtReport.TableName = "[V]";
                                            dsAllReport.Tables.Add(dtReport);

                                            isContinue = (dtReport.Rows.Count == 0);

                                            #endregion 透過ReportSQL取得Mail內容的資料
                                        }

                                        if (isContinue)
                                        {
                                            sbLog.AppendFormat(System.Environment.NewLine + "--  發送主旨：{0}  【無符合資料，無需發送Mail - Continue離開迴圈】dtimeNow：{1} --", templateSubject, dtimeNow);
                                            continue;
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        isSuccss = false;
                                        sbLog.AppendFormat(System.Environment.NewLine + "--  發送主旨：{0}  【發送失敗：{1}】 --", templateSubject, ex.Message);

                                        SendExceptionMail(send, templateSubject, mailTo, mailCc, mailBcc, ex.Message, sbLog);
                                    }

                                    if (isSuccss)
                                    {
                                        #region 取得相關連RelationalMailTo、MailCc、MailBcc資料

                                        #region RelationalMailTo

                                        int rowCount = 1;
                                        sqlRelationalMailToSQL = dr["RelationalMailToSQL"].ToString();
                                        if (sqlRelationalMailToSQL != "")
                                        {
                                            dtRelationalMailTo = dao.SqlSelect(sqlRelationalMailToSQL);
                                            if (dtRelationalMailTo.Rows.Count > 0)
                                                rowCount += dtRelationalMailTo.Rows.Count;
                                            else
                                            {
                                                dtRelationalMailTo.Clear();
                                                sbLog.AppendFormat(System.Environment.NewLine + "--  發送主旨：{0}  【發送失敗：RelationalMailTo空白】 --", templateSubject);
                                                continue;
                                            }
                                        }

                                        #endregion RelationalMailTo

                                        #region RelationalMailCc

                                        sqlRelationalMailCcSQL = dr["RelationalMailCcSQL"].ToString();
                                        if (sqlRelationalMailCcSQL != "")
                                            dtRelationalMailCc = dao.SqlSelect(sqlRelationalMailCcSQL);
                                        else
                                            dtRelationalMailCc.Clear();

                                        #endregion RelationalMailCc

                                        #region RelationalMailBcc

                                        sqlRelationalMailBccSQL = dr["RelationalMailBccSQL"].ToString();
                                        if (sqlRelationalMailBccSQL != "")
                                            dtRelationalMailBcc = dao.SqlSelect(sqlRelationalMailBccSQL);
                                        else
                                            dtRelationalMailBcc.Clear();

                                        #endregion RelationalMailBcc

                                        #endregion 取得相關連RelationalMailTo、MailCc、MailBcc資料

                                        string subject = "", name = "", dept, aHref = "", Value = "";
                                        string mailToKeyColumnName;
                                        System.Collections.ArrayList alDeleteMailToColumn = new System.Collections.ArrayList();
                                        bool isLastRow = false;
                                        for (int i = 0; i < rowCount; i++)
                                        {
                                            subject = templateSubject;
                                            mailToKeyColumnName = "";
                                            dept = "";
                                            aHref = "";
                                            Value = "";
                                            alDeleteMailToColumn.Clear();
                                            dsReport.Tables.Clear();
                                            dsTempReport.Tables.Clear();

                                            isLastRow = (i == (rowCount - 1));
                                            if (isLastRow)
                                            {
                                                #region 在迴圈的最後一次，才取得MailTo的資料

                                                sqlMailSQL = dr["MailToSQL"].ToString();
                                                if (sqlMailSQL != "")
                                                    mailTo = dao.SqlSelectToString(sqlMailSQL, "Email");
                                                else
                                                    break;

                                                #endregion 在迴圈的最後一次，才取得MailTo的資料
                                            }
                                            else
                                            {
                                                #region 組RelationalMailTo過濾條件

                                                mailToKeyColumnName = GetKeyColumn(dtRelationalMailTo, i, alDeleteMailToColumn);

                                                #endregion 組RelationalMailTo過濾條件

                                                mailTo = dtRelationalMailTo.Rows[i]["Email"].ToString();

                                                #region 取得Value的參數值

                                                if (dtRelationalMailTo.Columns.IndexOf("Value") > -1)
                                                    Value = dtRelationalMailTo.Rows[i]["Value"].ToString();

                                                #endregion 取得Value的參數值

                                                #region 取代主旨的@Name@名字

                                                if (templateSubject.IndexOf("@Name@") > -1)
                                                {
                                                    int index = mailTo.IndexOf('[');
                                                    if (index > -1)
                                                        name = mailTo.Substring(0, index - 1);
                                                    if (name != "")
                                                        subject = subject.Replace("@Name@", name);
                                                }

                                                #endregion 取代主旨的@Name@名字

                                                #region 取代主旨的@Dept@部門

                                                if (templateSubject.IndexOf("@Dept@") > -1)
                                                {
                                                    if (dtRelationalMailTo.Columns.IndexOf("Dept") > -1)
                                                        dept = dtRelationalMailTo.Rows[i]["Dept"].ToString();

                                                    if (dept != "")
                                                        subject = subject.Replace("@Dept@", dept);
                                                }

                                                #endregion 取代主旨的@Dept@部門

                                                #region 取代主旨的@Value@變數

                                                if (templateSubject.IndexOf("@Value@") > -1)
                                                {
                                                    if (Value != "")
                                                        subject = subject.Replace("@Value@", Value);
                                                }

                                                #endregion 取代主旨的@Value@變數

                                                #region 取得@AHref@的參數值

                                                if (dtRelationalMailTo.Columns.IndexOf("AHref") > -1)
                                                    aHref = dtRelationalMailTo.Rows[i]["AHref"].ToString();

                                                #endregion 取得@AHref@的參數值
                                            }

                                            mailCc = "";
                                            mailBcc = "";
                                            if (mailTo != "")
                                            {
                                                if (isLastRow)
                                                {
                                                    dsReport = dsAllReport.Copy();

                                                    #region 取得CC的Mail

                                                    sqlMailSQL = dr["MailCcSQL"].ToString();
                                                    mailCc = dao.SqlSelectToString(sqlMailSQL, "Email");

                                                    #endregion 取得CC的Mail

                                                    #region 取得BCC的Mail

                                                    sqlMailSQL = dr["MailBccSQL"].ToString();
                                                    mailBcc = dao.SqlSelectToString(sqlMailSQL, "Email");

                                                    #endregion 取得BCC的Mail
                                                }
                                                else
                                                {
                                                    #region 非迴圈的最後一次，則取得相關連RelationalMailTo對應欄位的資料

                                                    DataRow[] drAry;
                                                    dsTempReport = dsAllReport.Copy();
                                                    int tableIndex = 0;
                                                    foreach (System.Data.DataTable dtReport in dsTempReport.Tables)
                                                    {
                                                        drAry = dtReport.Select(mailToKeyColumnName);
                                                        if (drAry.Length > 0)
                                                            dsReport.Tables.Add(drAry.CopyToDataTable());
                                                        else
                                                            dsReport.Tables.Add(dtReport.Clone());
                                                        dsReport.Tables[tableIndex++].TableName = "[V]";
                                                    }

                                                    #endregion 非迴圈的最後一次，則取得相關連RelationalMailTo對應欄位的資料

                                                    string mailCcKeyColumnName = "", mailBccKeyColumnName = "";
                                                    System.Collections.ArrayList alDeleteMailCcColumn = new System.Collections.ArrayList();
                                                    System.Collections.ArrayList alDeleteMailBccColumn = new System.Collections.ArrayList();
                                                    foreach (System.Data.DataTable dtReport in dsReport.Tables)
                                                    {
                                                        if (dtReport.Rows.Count > 0)
                                                        {
                                                            #region RelationalMailCc

                                                            for (int j = 0; j < dtRelationalMailCc.Rows.Count; j++)
                                                            {
                                                                mailCcKeyColumnName = GetKeyColumn(dtRelationalMailCc, j, alDeleteMailCcColumn);
                                                                drAry = dtReport.Select(mailCcKeyColumnName);
                                                                if (drAry.Length > 0)
                                                                {
                                                                    string tempMailCc = dtRelationalMailCc.Rows[j]["Email"].ToString();
                                                                    if (mailCc.IndexOf(tempMailCc) == -1)
                                                                        mailCc += dtRelationalMailCc.Rows[j]["Email"].ToString();
                                                                }
                                                            }

                                                            #endregion RelationalMailCc

                                                            #region RelationalMailBcc

                                                            for (int k = 0; k < dtRelationalMailBcc.Rows.Count; k++)
                                                            {
                                                                mailBccKeyColumnName = GetKeyColumn(dtRelationalMailBcc, k, alDeleteMailBccColumn);
                                                                drAry = dtReport.Select(mailBccKeyColumnName);
                                                                if (drAry.Length > 0)
                                                                {
                                                                    string tempMailBcc = dtRelationalMailBcc.Rows[k]["Email"].ToString();
                                                                    if (mailBcc.IndexOf(tempMailBcc) == -1)
                                                                        mailBcc += dtRelationalMailBcc.Rows[k]["Email"].ToString();
                                                                }
                                                            }

                                                            #endregion RelationalMailBcc

                                                            #region 刪除註記【*】的欄位

                                                            RemoveDataTableColumn(dtReport, alDeleteMailToColumn);
                                                            RemoveDataTableColumn(dtReport, alDeleteMailCcColumn);
                                                            RemoveDataTableColumn(dtReport, alDeleteMailBccColumn);

                                                            #endregion 刪除註記【*】的欄位
                                                        }
                                                    }
                                                }

                                                #region 是否用附件方式或直接呈現方式

                                                if (dsReport.Tables.Count > 0)
                                                {
                                                    isAttachment = Convert.ToBoolean(dr["IsAttachmentExcel"]);
                                                    if (isAttachment)
                                                    {
                                                        #region 附件

                                                        int index = 0;
                                                        ERP.EPPlusExcel epplus = new ERP.EPPlusExcel(dsReport.Tables.Count);
                                                        fileName = dr["FileName"].ToString();
                                                        //若檔名未設定時，則使用主旨為檔名
                                                        if (fileName == "")
                                                            fileName = subject;

                                                        bool isExport = false;
                                                        foreach (System.Data.DataTable dtReport in dsReport.Tables)
                                                        {
                                                            //if (dtReport.Rows.Count > 0)
                                                            {
                                                                #region 儲存Excel檔案

                                                                if (!isExport)
                                                                    isExport = true;

                                                                epplus.SetExcelWorkSheet(index, (dsReport.Tables.Count > 1 ? dtReport.TableName.Replace("[V]", "") : fileName));
                                                                epplus.AddContentData(index, 1, dtReport, true, true, true);
                                                                epplus.SetAutoFit(index, 1, dtReport.Columns.Count);

                                                                #endregion 儲存Excel檔案
                                                            }
                                                            index++;
                                                        }

                                                        if (isExport)
                                                        {
                                                            filePath = string.Format(@"{0}\{1}.xlsx", System.Windows.Forms.Application.StartupPath, fileName);
                                                            isSuccss = isSuccss && epplus.ExportToSaveFile(filePath, out sbMsg);
                                                            if (!isSuccss)
                                                                filePath = "";
                                                        }
                                                        else
                                                            filePath = "";

                                                        #endregion 附件
                                                    }
                                                }

                                                #endregion 是否用附件方式或直接呈現方式
                                            }
                                            else
                                            {
                                                isSuccss = false;
                                                isAttachment = false;
                                                sbMsg.AppendFormat("【{0}】Mail To 不可空白!", subject);
                                            }

                                            #region 發送Mail

                                            bool isSend = false;
                                            if (mailTo != "")
                                            {
                                                if (isSuccss)
                                                {
                                                    if (isTest)
                                                    {
                                                        if (isSendMailToTab)
                                                        {
                                                            //測試使用
                                                            mailTo = string.Format("{0} [tab.kuo@cht-pt.com.tw];", mailTo.Replace("@cht-pt.com.tw", "").Replace(";", ""));
                                                            if (mailCc.Length > 0)
                                                                mailCc = string.Format("{0} [tab.kuo@cht-pt.com.tw];", mailCc.Replace("@cht-pt.com.tw", "").Replace(";", ""));
                                                            if (mailBcc.Length > 0)
                                                                mailBcc = string.Format("{0} [tab.kuo@cht-pt.com.tw];", mailBcc.Replace("@cht-pt.com.tw", "").Replace(";", ""));
                                                        }
                                                    }

                                                    #region 取得Mail內容，若無設定則使用預設值

                                                    mailContent = dr["MailContent"].ToString();
                                                    if (mailContent == "")
                                                        //【@MailContent@】為關鍵字
                                                        mailContent = "你好,<br><br>這一封郵件是由ERP系統自動發送，請參考Mail資訊！@MailContent@ <br><br>Best regards,<br>Mail Report System";

                                                    if (mailContent.IndexOf("@MailContent@") > -1)
                                                    {
                                                        bool isHeader = Convert.ToBoolean(dr["IsHeader"]);
                                                        System.Text.StringBuilder sbHtmlContent = new StringBuilder();
                                                        foreach (System.Data.DataTable dtReport in dsReport.Tables)
                                                        {
                                                            //Table名稱有[V]才直接顯示在Mail中
                                                            if (dtReport.TableName.Length >= 3)
                                                            {
                                                                if (dtReport.TableName.Substring(0, 3) == "[V]")
                                                                    sbHtmlContent.Append(GetHTMLContent(dtReport, isHeader));
                                                            }
                                                        }

                                                        mailContent = mailContent.Replace("@MailContent@", string.Format("<br><br>{0}", sbHtmlContent.ToString()));
                                                    }

                                                    #endregion 取得Mail內容，若無設定則使用預設值

                                                    #region 取代Mail內容的@AHref@參數

                                                    if (mailContent.IndexOf("@AHref@") > -1)
                                                    {
                                                        if (aHref != "")
                                                            mailContent = mailContent.Replace("@AHref@", aHref);
                                                    }

                                                    #endregion 取代Mail內容的@AHref@參數

                                                    #region 取代Mail內容的@Name@名字

                                                    if (mailContent.IndexOf("@Name@") > -1)
                                                    {
                                                        if (name != "")
                                                            mailContent = mailContent.Replace("@Name@", name);
                                                    }

                                                    #endregion 取代Mail內容的@Name@名字

                                                    #region 取代Mail內容的@Dept@部門

                                                    if (mailContent.IndexOf("@Dept@") > -1)
                                                    {
                                                        if (dept != "")
                                                            mailContent = mailContent.Replace("@Dept@", dept);
                                                    }

                                                    #endregion 取代Mail內容的@Dept@部門

                                                    #region 取代Mail內容的@Value@參數

                                                    if (mailContent.IndexOf("@Value@") > -1)
                                                    {
                                                        if (Value != "")
                                                            mailContent = mailContent.Replace("@Value@", Value);
                                                    }

                                                    #endregion 取代Mail內容的@Value@參數

                                                    #region 取得Mail的優先權

                                                    strMailPriority = dr["MailPriority"].ToString().ToUpper();
                                                    switch (strMailPriority)
                                                    {
                                                        case "H":
                                                            mailPriority = System.Net.Mail.MailPriority.High;
                                                            break;

                                                        case "L":
                                                            mailPriority = System.Net.Mail.MailPriority.Low;
                                                            break;

                                                        default:
                                                            mailPriority = System.Net.Mail.MailPriority.Normal;
                                                            break;
                                                    }

                                                    #endregion 取得Mail的優先權
                                                }
                                                else
                                                {
                                                    #region 失敗訊息

                                                    mailFrom = "MailReport錯誤 <mailReport@cht-pt.com.tw>";
                                                    mailTo = "ERP小組 <erp@cht-pt.com.tw>";
                                                    mailCc = "";
                                                    mailBcc = "";
                                                    mailPriority = System.Net.Mail.MailPriority.High;
                                                    mailContent = string.Format("你好,<br><br>【{0}】錯訊訊息如下：\\n{1}<br><br>Best regards,<br>Mail Report System", subject, sbMsg);

                                                    #endregion 失敗訊息
                                                }

                                                try
                                                {
                                                    mailTo = mailTo.Replace("[", "<").Replace("]", ">");
                                                    mailCc = mailCc.Replace("[", "<").Replace("]", ">");
                                                    mailBcc = mailBcc.Replace("[", "<").Replace("]", ">");
                                                    isSend = send.Send(subject, mailContent, mailFrom, mailTo, mailCc, mailBcc, new string[] { filePath }, "", mailPriority);
                                                }
                                                catch (Exception ex)
                                                {
                                                    string Msg = "";
                                                    if (ex.Message == "郵件標頭中找到無效的字元: '<'。")
                                                        Msg = "請檢查收件者Email不可空白！";
                                                    SendExceptionMail(send, templateSubject, mailTo, mailCc, mailBcc, string.Format("{0}<br/>{1}", ex.Message, Msg), sbLog);
                                                }
                                            }
                                            else
                                                sbLog.AppendFormat(System.Environment.NewLine + "--  發送主旨：{0}  【發送失敗：MailTo空白】 --", subject);
                                            sbLog.AppendFormat(System.Environment.NewLine + "--  發送主旨：{0}  【發送結果：{1}】 --", subject, isSend);

                                            #endregion 發送Mail
                                        }
                                    }

                                    #endregion 確認是否符合執行時間
                                }
                                else
                                    sbLog.AppendFormat(System.Environment.NewLine + "--  發送主旨：{0}  【發送結果：時間不符合設定】dtimeNow：{1} dtimeStart：{2}--", templateSubject, dtimeNow, dtimeStart.AddMinutes(addMinutes));

                                #endregion 確認時間是否符合，可誤差5分鐘
                            }
                            else
                            {
                                isSuccss = false;
                                sbLog.AppendFormat(System.Environment.NewLine + "--  發送主旨：{0}  【發送結果：超過結束時間】 dtimeEnd：{1} dtimeStart：{2}--", templateSubject, dtimeEnd, dtimeStart);
                            }

                            #region 發送Mail完後，執行其他動作

                            if (isSuccss)
                            {
                                if (isExecOtherAction)
                                {
                                    if (!isTest)
                                    {
                                        bool isUpdateSuccess = false;
                                        string externalClass = dr["ReportSQL"].ToString();
                                        switch (externalClass)
                                        {
                                            case "EEP_Reminder_1Day":
                                                EEP_Reminder eepReminder1 = new EEP_Reminder();
                                                isUpdateSuccess = eepReminder1.UpdateEEP_Reminder(1);
                                                sbLog.AppendFormat(System.Environment.NewLine + "--  發送主旨：{0}  【更新EEP Reminder 1Day - Sys.ToDo 結果：{1}】--", templateSubject, isUpdateSuccess);
                                                break;

                                            case "EEP_Reminder_2Day":
                                                EEP_Reminder eepReminder2 = new EEP_Reminder();
                                                isUpdateSuccess = eepReminder2.UpdateEEP_Reminder(2);
                                                sbLog.AppendFormat(System.Environment.NewLine + "--  發送主旨：{0}  【更新EEP Reminder 2Day - Sys.ToDo 結果：{1}】--", templateSubject, isUpdateSuccess);
                                                break;

                                            case "EEP_Reminder_3Day":
                                                EEP_Reminder eepReminder3 = new EEP_Reminder();
                                                isUpdateSuccess = eepReminder3.UpdateEEP_Reminder(3);
                                                sbLog.AppendFormat(System.Environment.NewLine + "--  發送主旨：{0}  【更新EEP Reminder 3Day - Sys.ToDo 結果：{1}】--", templateSubject, isUpdateSuccess);
                                                break;

                                            case "WF_GetPushData":
                                                WF_GetPushData wfGetPushData = new WF_GetPushData();
                                                isUpdateSuccess = wfGetPushData.UpdateWF0XS1AToDate();
                                                sbLog.AppendFormat(System.Environment.NewLine + "--  發送主旨：{0}  【更新WF0XS1A - ToDate 結果：{1}】--", templateSubject, isUpdateSuccess);
                                                break;

                                            case "ITReport":
                                                ITReport IT = new ITReport();
                                                isUpdateSuccess = IT.UpdateIT0GMIsCloseFlag();
                                                sbLog.AppendFormat(System.Environment.NewLine + "--  發送主旨：{0}  【更新IT0GM - IsClose 結果：{1}】--", templateSubject, isUpdateSuccess);
                                                break;
                                        }
                                    }
                                }
                            }

                            #endregion 發送Mail完後，執行其他動作
                        }
                        catch (Exception ex)
                        {
                            SendExceptionMail(send, templateSubject, mailTo, mailCc, mailBcc, ex.Message, sbLog);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                SendExceptionMail(send, templateSubject, mailTo, mailCc, mailBcc, ex.Message, sbLog);
            }

            string FileName = string.Format("Log - {0}", DateTime.Now.ToString("yyyyMMdd"));
            ERP.LogFile log = new ERP.LogFile("LogFile", FileName);
            log.WriteLog(sbLog.ToString());
        }

        private static System.Data.DataTable GetSQLListDataTable(string ConnStr, string SQLListID)
        {
            ERP.DBDao dao = new ERP.DBDao(ConnStr);
            string sqlQuerySQLList = @"
                SELECT SQL + ' ' + ISNULL(OrderBySQL, '') AS SQL
                FROM dbo.SQLList WITH(NOLOCK)
                WHERE ID = @SQLListID";
            dao.SqlCommand.Parameters.AddWithValue("@SQLListID", SQLListID);
            string sqlQuery = dao.SqlSelectToString(sqlQuerySQLList, "SQL");
            System.Data.DataTable dtSQLList = dao.SqlSelect(sqlQuery);

            System.Data.DataTable dtSQLListClone = new DataTable();
            if (dtSQLList.Rows.Count > 0)
            {
                dtSQLListClone = dtSQLList.Copy();
                foreach (System.Data.DataColumn dc in dtSQLList.Columns)
                {
                    if (dc.ColumnName.IndexOf("^") > -1)
                        dtSQLListClone.Columns.Remove(dc.ColumnName);
                }
                dtSQLListClone.TableName = "[V]";
            }

            return dtSQLListClone;
        }

        private static void SendExceptionMail(SendMail send, string templateSubject, string mailTo, string mailCc, string mailBcc, string exceptionMessage, StringBuilder sbLog)
        {
            string mailFrom = "MailReport【例外處理】錯誤 <mailReport@cht-pt.com.tw>";
            mailTo = string.Format("{0} <erp@cht-pt.com.tw>;", mailTo == "" ? "ERP小組" : mailTo.Replace("@cht-pt.com.tw", "").Replace(";", ""));
            if (mailCc.Length > 0)
                mailCc = string.Format("{0} <erp@cht-pt.com.tw>;", mailCc.Replace("@cht-pt.com.tw", "").Replace(";", ""));
            if (mailBcc.Length > 0)
                mailBcc = string.Format("{0} <erp@cht-pt.com.tw>;", mailBcc.Replace("@cht-pt.com.tw", "").Replace(";", ""));

            sbLog.AppendFormat(System.Environment.NewLine + string.Format("--  發送失敗：【{0}】例外處理(Exception)：{1}", templateSubject, exceptionMessage));
            send.Send("Mail Report System 發送失敗~", string.Format("【{0}】{1}", templateSubject, exceptionMessage), mailFrom, mailTo, "", "", "", System.Net.Mail.MailPriority.High);
        }

        private static void RemoveDataTableColumn(DataTable dtReport, System.Collections.ArrayList alDeleteColumn)
        {
            foreach (string columnName in alDeleteColumn)
            {
                int removeIndex = dtReport.Columns.IndexOf(columnName);
                if (removeIndex > -1)
                    dtReport.Columns.RemoveAt(removeIndex);
            }
        }

        private static string GetKeyColumn(DataTable dtRelational, int rowIndex, System.Collections.ArrayList alDeleteColumn)
        {
            string columnName, keyColumn = "";
            foreach (System.Data.DataColumn dc in dtRelational.Columns)
            {
                columnName = dc.ColumnName.Replace("@", "").Replace("*", "");
                if (dc.ColumnName.IndexOf("@") > -1)
                    keyColumn += string.Format("{0} = '{1}' AND ", columnName, dtRelational.Rows[rowIndex][dc.ColumnName].ToString());
                if (dc.ColumnName.IndexOf("*") > -1)
                {
                    if (alDeleteColumn.IndexOf(columnName) == -1)
                        alDeleteColumn.Add(columnName);
                }
            }
            if (keyColumn.Length > 0)
                keyColumn = keyColumn.Remove(keyColumn.Length - 5, 5);
            return keyColumn;
        }

        private static bool CheckExecTime(bool isFixedDate, System.DateTime dtimeStart, System.DateTime dtimeEnd, System.DateTime dtimeNow, bool isOverDay, int cycleMinute, int addMinutes)
        {
            /*時間差*/
            int minutesDifference = 0;

            bool isCheckOK = false;
            if (isFixedDate)
            {
                TimeSpan tsNow = new TimeSpan(dtimeNow.Ticks);
                TimeSpan tsStart = new TimeSpan(dtimeStart.Ticks);
                TimeSpan ts = tsNow.Subtract(tsStart).Duration();
                if (ts.Hours == 0 && (ts.Minutes >= 0 && ts.Minutes <= addMinutes))
                    isCheckOK = true;
                //isCheckOK = (dtimeNow.ToString("HH:mm") == dtimeStart.ToString("HH:mm"));
            }
            else
            {
                int StartMinutes = dtimeStart.Hour * 60 + dtimeStart.Minute;
                int EndMinutes = dtimeEnd.Hour * 60 + dtimeEnd.Minute;
                int NowMinutes = dtimeNow.Hour * 60 + dtimeNow.Minute;

                if (isOverDay)
                {
                    if (NowMinutes >= StartMinutes && NowMinutes < 1440)
                    {
                        minutesDifference = (NowMinutes - StartMinutes);
                        isCheckOK = (minutesDifference % cycleMinute >= 0) && (minutesDifference % cycleMinute <= addMinutes);
                    }
                    else if (EndMinutes >= NowMinutes)
                    {
                        NowMinutes = NowMinutes + (1440 - StartMinutes);
                        minutesDifference = (NowMinutes % cycleMinute);
                        isCheckOK = (minutesDifference >= 0) && (minutesDifference <= addMinutes);
                    }
                }
                else
                {
                    if (NowMinutes >= StartMinutes && EndMinutes >= NowMinutes)
                    {
                        minutesDifference = (NowMinutes - StartMinutes);
                        isCheckOK = (minutesDifference % cycleMinute >= 0) && (minutesDifference % cycleMinute <= addMinutes);
                    }
                }
            }
            return isCheckOK;
        }

        private static string GetHTMLContent(System.Data.DataTable dtContent, bool isHeader)
        {
            CreateHtmlTable htmlTable = new CreateHtmlTable(dtContent);

            bool isNoWrap;
            int maxLength;
            string columnName;
            foreach (System.Data.DataColumn dc in dtContent.Columns)
            {
                columnName = dc.ColumnName;

                #region 取得欄位的最大長度

                maxLength = 0;
                dtContent.Rows.OfType<System.Data.DataRow>().ToList().ForEach(
                    row =>
                    {
                        int rowLength = Convert.ToString(row.ItemArray[dtContent.Columns.IndexOf(dtContent.Columns[columnName])]).Length;
                        maxLength = rowLength > maxLength ? rowLength : maxLength;
                    }
                );

                #endregion 取得欄位的最大長度

                /*長度小於50則不換行置中對齊，否則換行靠左對齊*/
                isNoWrap = (maxLength < 50);
                htmlTable.AddColumn(columnName, System.Drawing.Color.Yellow.Name, columnName, isNoWrap, isNoWrap ? CreateHtmlTable.TextAlign.center : CreateHtmlTable.TextAlign.left);
            }

            string mailContent = htmlTable.GetHtmlContent(isHeader, true);
            return mailContent;
        }
    }
}