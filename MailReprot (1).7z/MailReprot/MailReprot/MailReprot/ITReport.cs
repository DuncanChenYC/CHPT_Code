﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MailReprot
{
    class ITReport
    {
        public System.Data.DataTable GetITReportDataTable(ERP.DBDao dao)
        {
            string sqlQuery = @"
                SELECT ROW_NUMBER() OVER(ORDER BY b.DeptNo, b.EmployeeNo, a.LstEdtDate) AS '項次'   
                    , (CONVERT(VARCHAR(10), DATEADD(DAY, -6, GETDATE()), 111) + '~' + CONVERT(VARCHAR(10), GETDATE(), 111)) AS '查詢區間'
	                , a.Date AS '記錄日期'
	                , d.DeptName AS '部門'
	                , b.EmployeeName AS '記錄人員'
	                , a.Type AS '工作類別'
	                , a.JobContent AS '工作內容'
	                , a.Status AS '工作狀態'	
                    , 'IT' AS '資訊部'
                FROM dbo.IT0GM a WITH(NOLOCK)
                INNER JOIN dbo.HR0AM b WITH(NOLOCK) ON a.Recorder = b.EmployeeNo
                INNER JOIN dbo.HR0AM c WITH(NOLOCK) ON a.LstEdtUser = c.EmployeeNo
                INNER JOIN dbo.Dept d WITH(NOLOCK) ON b.DeptNo = d.DeptNo
                WHERE a.IsInvalid = 0
	                AND a.Date >= CONVERT(DATE, DATEADD(DAY, -6, GETDATE())) 
	                AND a.Date <= CONVERT(DATE, GETDATE())
                ORDER BY b.DeptNo, b.EmployeeNo, a.LstEdtDate";
            System.Data.DataTable dt = dao.SqlSelect(sqlQuery);
            dt.TableName = "[V]資訊部週報";
            return dt;
        }

        public bool UpdateIT0GMIsCloseFlag()
        {
            bool isSuccess = false;
            System.Text.StringBuilder sbMsg = new StringBuilder();

            ERP.DBDao dao = new ERP.DBDao();
            dao.SqlConn.Open();
            try
            {
                string sqlUpdate = @"
                    UPDATE dbo.IT0GM SET IsColse = '1'
                    WHERE IsInvalid = 0
	                    AND Date >= CONVERT(DATE, DATEADD(DAY, -6, GETDATE())) 
	                    AND Date <= CONVERT(DATE, GETDATE())";
                isSuccess = dao.SqlUpdate(sqlUpdate, ref sbMsg);
            }
            catch (Exception ex)
            {
                isSuccess = false;
                sbMsg.Append(ex.Message);
            }
            finally
            {
                dao.SqlConn.Close();
            }
            return isSuccess;
        }
    }
}
