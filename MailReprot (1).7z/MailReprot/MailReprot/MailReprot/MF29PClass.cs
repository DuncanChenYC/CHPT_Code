﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// MF29PClass 的摘要描述
/// </summary>
public class MF29PClass
{
	public MF29PClass()
	{
		
	}

	public void GetGroupDetailDataTable(ERP.DBDao dao, string groupName, string selectDate, int hour, out System.Data.DataTable dtGroup, out System.Data.DataTable dtDetail)
	{		
		System.Data.DataTable dtCheckOutMoveIn = this.GetCheckOutMoveInInfo(dao, groupName, selectDate, hour);
		string checkOutMoveInColumnList =  this.GetDataTableColumnName(dtCheckOutMoveIn);
		System.Data.DataTable dtCheckOutMoveInGroup = this.GetCheckOutMoveInGroup(dao, groupName, checkOutMoveInColumnList, selectDate, hour);

		System.Data.DataTable dtCheckInCheckOut = this.GetCheckInCheckOutInfo(dao, groupName, selectDate, hour);
		string checkInCheckOutColumnList = this.GetDataTableColumnName(dtCheckInCheckOut);
		System.Data.DataTable dtCheckInCheckOutGroup = this.GetCheckInCheckOutGroup(dao, groupName, checkInCheckOutColumnList, selectDate, hour);

		dtGroup = new System.Data.DataTable();
		dtGroup.TableName = "[V]統計表";

		this.AddTableColumnsName(dtGroup, dtCheckOutMoveInGroup);
		this.AddTableColumnsName(dtGroup, dtCheckInCheckOutGroup);
		this.AddTableContent(dtGroup, dtCheckOutMoveInGroup);
		this.AddTableContent(dtGroup, dtCheckInCheckOutGroup);

		dtDetail = new System.Data.DataTable();
		dtDetail.TableName = "明細";        

		this.AddTableColumnsName(dtDetail, dtCheckOutMoveIn);
		this.AddTableColumnsName(dtDetail, dtCheckInCheckOut);
		this.AddTableContent(dtDetail, dtCheckOutMoveIn);
		this.AddTableContent(dtDetail, dtCheckInCheckOut);

		this.SetDetailColumn(dtDetail);
	}

	/// <summary>
	/// 製程過帳稽核(MF29P)-以DataTable的GroupName欄位，設定欄位清單
	/// </summary>
	/// <param name="dt"></param>
	/// <returns></returns>
	public string GetDataTableColumnName(System.Data.DataTable dt)
	{
		System.Text.StringBuilder sbColumnName = new System.Text.StringBuilder();

		System.Data.DataTable dtDistinct = dt.DefaultView.ToTable(true, new string[] { "GroupName" });
		foreach (System.Data.DataRow dr in dtDistinct.Rows)
			sbColumnName.AppendFormat("[{0}],", dr["GroupName"].ToString());

		if (sbColumnName.Length > 0)
			sbColumnName = sbColumnName.Remove(sbColumnName.Length - 1, 1);
		return sbColumnName.ToString();
	}

	/// <summary>
	/// 製程過帳稽核(MF29P)-取得CheckOutMoveIn的DataTable
	/// </summary>
	/// <param name="dao"></param>
	/// <param name="groupName"></param>
	/// <param name="selectDate"></param>
	/// <param name="hour"></param>
	/// <returns></returns>
	public System.Data.DataTable GetCheckOutMoveInInfo(ERP.DBDao dao, string groupName, string selectDate, int hour)
	{
		string sqlCheckOutMoveIn = this.GetCheckOutMoveInSQL(dao, groupName, false, selectDate, hour);
		System.Data.DataTable dtCheckOutMoveIn = dao.SqlSelect(sqlCheckOutMoveIn);
		return dtCheckOutMoveIn;
	}

	/// <summary>
	/// 製程過帳稽核(MF29P)-取得CheckOutMoveIn群組的DataTable
	/// </summary>
	/// <param name="dao"></param>
	/// <param name="groupName"></param>
	/// <param name="columnNameList"></param>
	/// <param name="selectDate"></param>
	/// <param name="hour"></param>
	/// <returns></returns>
	public System.Data.DataTable GetCheckOutMoveInGroup(ERP.DBDao dao, string groupName, string columnNameList, string selectDate, int hour)
	{
		string sqlMain = this.GetCheckOutMoveInSQL(dao, groupName, true, selectDate, hour);
		//取得設定於資料庫內的SQL語法
		string sql = dao.SqlSelectToString("SELECT SQL FROM dbo.SQLList WHERE ProgramName = 'MF29P' AND FunctionName = 'CheckOutMoveInGroup'", "SQL");
		sql = string.Format(sql, sqlMain, columnNameList);
		System.Data.DataTable dtGroup = dao.SqlSelect(sql);
		return dtGroup;
	}

	/// <summary>
	/// 製程過帳稽核(MF29P)-取得CheckInCheckOut的DataTable
	/// </summary>
	/// <param name="dao"></param>
	/// <param name="groupName"></param>
	/// <param name="selectDate"></param>
	/// <param name="hour"></param>
	/// <returns></returns>
	public System.Data.DataTable GetCheckInCheckOutInfo(ERP.DBDao dao, string groupName, string selectDate, int hour)
	{
		string sqlCheckInCheckOutInfo = this.GetCheckInCheckOutSQL(dao, groupName, false, selectDate, hour);
		System.Data.DataTable dtCheckInCheckOut = dao.SqlSelect(sqlCheckInCheckOutInfo);
		return dtCheckInCheckOut;
	}

	/// <summary>
	/// 製程過帳稽核(MF29P)-取得CheckInCheckOut群組的DataTable
	/// </summary>
	/// <param name="dao"></param>
	/// <param name="groupName"></param>
	/// <param name="columnNameList"></param>
	/// <param name="selectDate"></param>
	/// <param name="hour"></param>
	/// <returns></returns>
	public System.Data.DataTable GetCheckInCheckOutGroup(ERP.DBDao dao, string groupName, string columnNameList, string selectDate, int hour)
	{
		string sqlMain = this.GetCheckInCheckOutSQL(dao, groupName, true, selectDate, hour);
		//取得設定於資料庫內的SQL語法
		string sql = dao.SqlSelectToString("SELECT SQL FROM dbo.SQLList WHERE ProgramName = 'MF29P' AND FunctionName = 'CheckInCheckOutGroup'", "SQL");
		sql = string.Format(sql, sqlMain, columnNameList);
		System.Data.DataTable dtGroup = dao.SqlSelect(sql);
		return dtGroup;
	}

	/// <summary>
	/// 將From的欄位名稱，加入To的欄位(重覆則不加入)
	/// </summary>
	/// <param name="dtTo"></param>
	/// <param name="dtFrom"></param>
	public void AddTableColumnsName(System.Data.DataTable dtTo, System.Data.DataTable dtFrom)
	{
		foreach (System.Data.DataColumn dc in dtFrom.Columns)
		{
			if (!dtTo.Columns.Contains(dc.ColumnName))
				dtTo.Columns.Add(dc.ColumnName);
		}
	}

	/// <summary>
	/// 將From的資料，加入To的資料表內
	/// </summary>
	/// <param name="dtTo"></param>
	/// <param name="dtFrom"></param>
	public void AddTableContent(System.Data.DataTable dtTo, System.Data.DataTable dtFrom)
	{
		foreach (System.Data.DataRow dr in dtFrom.Rows)
		{
			System.Data.DataRow drNew = dtTo.NewRow();
			foreach (System.Data.DataColumn dc in dtFrom.Columns)
				drNew[dc.ColumnName] = dr[dc.ColumnName];
			dtTo.Rows.Add(drNew);
		}
	}

	/// <summary>
	/// 製程過帳稽核(MF29P)-匯出Excel
	/// </summary>
	/// <param name="isSaveToFile"></param>
	/// <param name="obj"></param>
	/// <param name="dtGroup"></param>
	/// <param name="dtDetail"></param>
	/// <param name="groupName"></param>
	/// <param name="sbMsg"></param>
	public void ExportExcel(object obj, System.Data.DataTable dtGroup, System.Data.DataTable dtDetail, string groupName, ref System.Text.StringBuilder sbMsg)
	{
		#region 匯出Excel

		ERP.EPPlusExcel epplus = new ERP.EPPlusExcel(2);

		#region Sheet1 統計表

		int pageIndex = 0;
		epplus.SetExcelWorkSheet(pageIndex, "統計表");
		epplus.AddContentData(pageIndex, 1, dtGroup, true, true, true);
		epplus.SetWorkSheetTabColor(pageIndex, System.Drawing.Color.Yellow);
		epplus.SetAutoFit(pageIndex, 1, dtGroup.Columns.Count);

		#endregion Sheet1 統計表

		#region Sheet2 明細

		dtDetail.Columns.Remove("Type");
		dtDetail.Columns.Remove("Condition");
		dtDetail.Columns.Remove("GroupName");
		dtDetail.Columns.Remove("ProcCode");
		dtDetail.Columns.Remove("NextProcCode");

		foreach (System.Data.DataColumn dc in dtDetail.Columns)
		{
			#region 重新定義欄位名稱

			switch (dc.ColumnName)
			{
				case "ConditionDetail":
					dc.ColumnName = "明細";
					break;

				case "LotNo":
					dc.ColumnName = "Lot編號";
					break;

				case "ProcCodeSeq":
					dc.ColumnName = "製程序";
					break;

				case "ProcName":
					dc.ColumnName = "製程名稱";
					break;

				case "NextProcCodeSeq":
					dc.ColumnName = "下製程序";
					break;

				case "NextProcName":
					dc.ColumnName = "下製程名稱";
					break;

				case "CheckInDateTime":
					dc.ColumnName = "CheckIn時間";
					break;

				case "CheckOutDateTime":
					dc.ColumnName = "CheckOut時間";
					break;

				case "MoveInDateTime":
					dc.ColumnName = "MoveIn時間";
					break;

				case "DiffMin":
					dc.ColumnName = "差異分鐘";
					break;
			}

			#endregion 重新定義欄位名稱
		}

		pageIndex = 1;
		epplus.SetExcelWorkSheet(pageIndex, "明細");
		epplus.AddContentData(pageIndex, 1, dtDetail, true, true, true);
		epplus.SetAutoFit(pageIndex, 1, dtDetail.Columns.Count);

		#endregion Sheet2 明細
				
		epplus.ExportToSaveFile((string)obj, out sbMsg);

		#endregion 匯出Excel
	}

	private string GetCheckOutMoveInSQL(ERP.DBDao dao, string groupName, bool isGroup, string selectDate, int hour)
	{
		dao.SqlCommand.Parameters.Clear();

		string whereCondition = "";
		if (groupName != "")
		{
			whereCondition = "WHERE v3.GroupName = @GroupName";
			dao.SqlCommand.Parameters.AddWithValue("@GroupName", groupName);
		}

		//取得設定於資料庫內的SQL語法
		string sql = dao.SqlSelectToString("SELECT SQL FROM dbo.SQLList WHERE ProgramName = 'MF29P' AND FunctionName = 'CheckOutMoveInSQL'", "SQL");
		sql = string.Format(sql, whereCondition);

		DateTime startDate = this.GetDateTime(selectDate, hour);
		DateTime endDate = startDate.AddDays(1);
		dao.SqlCommand.Parameters.AddWithValue("@StartDate", startDate);
		dao.SqlCommand.Parameters.AddWithValue("@EndDate", endDate);
		return sql;
	}

	private string GetCheckInCheckOutSQL(ERP.DBDao dao, string groupName, bool isGroup, string selectDate, int hour)
	{
		dao.SqlCommand.Parameters.Clear();

		string whereCondition = "";
		if (groupName != "")
		{
			whereCondition = "WHERE v2.GroupName = @GroupName ";
			dao.SqlCommand.Parameters.AddWithValue("@GroupName", groupName);
		}

		//取得設定於資料庫內的SQL語法
		string sql = dao.SqlSelectToString("SELECT SQL FROM dbo.SQLList WHERE ProgramName = 'MF29P' AND FunctionName = 'CheckInCheckOutSQL'", "SQL");
		sql = string.Format(sql, whereCondition);

		DateTime startDate = this.GetDateTime(selectDate, hour);
		DateTime endDate = startDate.AddDays(1);
		dao.SqlCommand.Parameters.AddWithValue("@StartDate", startDate);
		dao.SqlCommand.Parameters.AddWithValue("@EndDate", endDate);
		return sql;
	}

	private DateTime GetDateTime(string selectDate, int Hour)
	{
		DateTime dtimeStart;

		if (selectDate == DateTime.Now.ToString("yyyy/MM/dd"))
		{
			int nowHour = Convert.ToInt16(DateTime.Now.ToString("HH"));
			if (nowHour >= 0 && nowHour < Hour)
				dtimeStart = Convert.ToDateTime(DateTime.Now.AddDays(-1).ToString(string.Format("yyyy/MM/dd {0}:00", Hour.ToString("D2"))));
			else
				dtimeStart = Convert.ToDateTime(DateTime.Now.ToString(string.Format("yyyy/MM/dd {0}:00", Hour.ToString("D2"))));
		}
		else
			dtimeStart = Convert.ToDateTime(string.Format("{0} {1}:00", selectDate, Hour.ToString("D2")));
		return dtimeStart;
	}

	public void SetDetailColumn(System.Data.DataTable dtDetail)
	{
		dtDetail.Columns.Remove("Type");
		dtDetail.Columns.Remove("Condition");
		dtDetail.Columns.Remove("GroupName");
		dtDetail.Columns.Remove("ProcCode");
		dtDetail.Columns.Remove("NextProcCode");

		foreach (System.Data.DataColumn dc in dtDetail.Columns)
		{
			#region 重新定義欄位名稱

			switch (dc.ColumnName)
			{
				case "ConditionDetail":
					dc.ColumnName = "明細";
					break;

				case "LotNo":
					dc.ColumnName = "Lot編號";
					break;

				case "ProcCodeSeq":
					dc.ColumnName = "製程序";
					break;

				case "ProcName":
					dc.ColumnName = "製程名稱";
					break;

				case "NextProcCodeSeq":
					dc.ColumnName = "下製程序";
					break;

				case "NextProcName":
					dc.ColumnName = "下製程名稱";
					break;

				case "CheckInDateTime":
					dc.ColumnName = "CheckIn時間";
					break;

				case "CheckOutDateTime":
					dc.ColumnName = "CheckOut時間";
					break;

				case "MoveInDateTime":
					dc.ColumnName = "MoveIn時間";
					break;

				case "DiffMin":
					dc.ColumnName = "差異分鐘";
					break;

				case "ProjectNo":
					dc.ColumnName = "案號";
					break;

				case "ItemDescrip":
					dc.ColumnName = "品名";
					break;
			}

			#endregion 重新定義欄位名稱
		}
	}
}