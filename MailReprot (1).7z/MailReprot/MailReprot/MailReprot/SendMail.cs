﻿using System;

public class SendMail
{
    private string MailHost, MailAccount, MailPWD;
    private int MailPort;

    public SendMail()
    {
        //MailHost = "mail2.cht-pt.com.tw";
        MailHost = "mail.cht-pt.com.tw";
        MailPort = 25;

        //MailAccount = "erp";
        //MailPWD = "chpterp20070810";
        MailAccount = "";
        MailPWD = "";
    }

    public SendMail(string mailHost, string mailAccount, string mailPWD)
    {
        MailHost = mailHost;
        MailPort = 25;

        MailAccount = mailAccount;
        MailPWD = mailPWD;
    }

    public bool Send(string subject, string body, string fromAddress, string toAddress, string ccAddress, string bccAddress, string[] filePathAry, string picPath, System.Net.Mail.MailPriority priority)
    {
        bool success = false;
        try
        {
            //MailMessage(寄信者, 收信者)
            success = this.DoSendMail(subject, body, fromAddress, toAddress, ccAddress, bccAddress, filePathAry, picPath, priority);
        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message);
        }
        return success;
    }

    public bool Send(string subject, string body, string fromAddress, string toAddress, string ccAddress, string bccAddress, string picPath, System.Net.Mail.MailPriority priority)
    {
        bool success = false;
        try
        {
            //MailMessage(寄信者, 收信者)
            success = this.DoSendMail(subject, body, fromAddress, toAddress, ccAddress, bccAddress, null, picPath, priority);
        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message);
        }
        return success;
    }

    public bool Send(string subject, string body, string fromAddress, string toAddress, string ccAddress, string bccAddress, string[] filePathAry, string picPath)
    {
        bool success = false;
        try
        {
            //MailMessage(寄信者, 收信者)
            success = this.DoSendMail(subject, body, fromAddress, toAddress, ccAddress, bccAddress, filePathAry, picPath, System.Net.Mail.MailPriority.Normal);
        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message);
        }
        return success;
    }
    public bool Send(string subject, string body, string fromAddress, string toAddress, string ccAddress, string bccAddress, string picPath)
    {
        bool success = false;
        try
        {
            //MailMessage(寄信者, 收信者)
            success = this.DoSendMail(subject, body, fromAddress, toAddress, ccAddress, bccAddress, null, picPath, System.Net.Mail.MailPriority.Normal);
        }
        catch (Exception ex)
        {
            throw new Exception(ex.Message);
        }
        return success;
    }

    private bool DoSendMail(string subject, string body, string fromAddress, string toAddress, string ccAddress, string bccAddress, string[] filePathAry, string picPath, System.Net.Mail.MailPriority priority)
    {
        bool success = false;
        System.Net.Mail.MailMessage message = new System.Net.Mail.MailMessage();
        message.From = new System.Net.Mail.MailAddress(fromAddress);

        string[] toAddrAry = toAddress.Split(';');
        foreach (string addr in toAddrAry)
        {
            if (addr.Trim() != "")
                message.To.Add(new System.Net.Mail.MailAddress(addr));
        }
        string[] ccAddrAry = ccAddress.Split(';');
        foreach (string addr in ccAddrAry)
        {
            if (addr.Trim() != "")
                message.CC.Add(new System.Net.Mail.MailAddress(addr));
        }
        string[] bccAddrAry = bccAddress.Split(';');
        foreach (string addr in bccAddrAry)
        {
            if (addr.Trim() != "")
                message.Bcc.Add(new System.Net.Mail.MailAddress(addr));
        }

        message.IsBodyHtml = true;
        //E-mail編碼
        message.BodyEncoding = System.Text.Encoding.UTF8;

        //寄Mail的優先權
        message.Priority = priority;

        //E-mail主旨
        message.Subject = subject;
        //E-mail內容
        message.Body = body;        

        #region 附件
        if (filePathAry != null && filePathAry.Length > 0)
        {
            foreach(string path in filePathAry)
            {
                if (path != "")
                {
                    System.Net.Mail.Attachment attachment = new System.Net.Mail.Attachment(path);
                    message.Attachments.Add(attachment);
                }
            }
        }
        #endregion

        #region 寄Mail內嵌圖片

        if (picPath != "")
        {
            System.Net.Mail.Attachment attachment = new System.Net.Mail.Attachment(picPath);
            attachment.Name = System.IO.Path.GetFileName(picPath);
            attachment.NameEncoding = System.Text.Encoding.GetEncoding("utf-8");
            attachment.TransferEncoding = System.Net.Mime.TransferEncoding.Base64;

            //設定該附件為一個內嵌附件(Inline Attachment)
            attachment.ContentDisposition.Inline = true;
            attachment.ContentDisposition.DispositionType = System.Net.Mime.DispositionTypeNames.Inline;

            message.Attachments.Add(attachment);
        }

        #endregion 寄Mail內嵌圖片

        //設定E-mail Server和port Host：10.11.1.20 Port：25
        System.Net.Mail.SmtpClient smtpClient = new System.Net.Mail.SmtpClient(MailHost, MailPort);
        System.Net.NetworkCredential credentialInfo = new System.Net.NetworkCredential(MailAccount, MailPWD);
        smtpClient.Credentials = credentialInfo;
        smtpClient.UseDefaultCredentials = false;

        //smtpClient.Send(message);
        Exception ex = new Exception();
        System.Text.StringBuilder sbMsg = new System.Text.StringBuilder();
        bool isSuccess = this.WhileSendMail(smtpClient, message, ref sbMsg, ref ex);

        message.Dispose();
        success = true;
        return success;
    }

    private bool WhileSendMail(System.Net.Mail.SmtpClient SMTPmail, System.Net.Mail.MailMessage MailMsg, ref System.Text.StringBuilder sbMsg, ref Exception ex)
    {
        bool isSuccess = false;

        int index = 1, max = 10;
        while (index <= max)
        {
            try
            {
                if (index != 1)
                    System.Threading.Thread.Sleep(300);

                SMTPmail.Send(MailMsg);
                isSuccess = true;
                index = max;
            }
            catch (Exception exception)
            {
                isSuccess = false;
                if (index == max)
                {
                    sbMsg.AppendFormat("發送失敗，已達發送Mail上限次數【{0}】", index);
                    ex = exception;
                }
            }
            index++;
        }
        return isSuccess;
    }

    public static string getBirthdayHtmlContent(System.Data.DataTable dtBirthdayInfo, System.Data.DataTable dtMailFormat, System.Data.DataTable dtLinkInfo, string type, string deptCode)
    {
        System.Text.StringBuilder sbHtml = new System.Text.StringBuilder();

        if (dtMailFormat.Rows.Count == 1)
        {
            string dbPicturePath = dtMailFormat.Rows[0]["PicturePath"].ToString();
            string dbPictureName = dtMailFormat.Rows[0]["PictureName"].ToString();

            sbHtml.Append(dtMailFormat.Rows[0]["MailContent"].ToString());
            sbHtml.Append("<br><br>");

            System.Collections.ArrayList alHighlight = new System.Collections.ArrayList();
            alHighlight.Add("姓名");

            if (type == "Day")
            {
            }
            else if (type == "Week" || type == "Month")
            {
                sbHtml.Append("<table border='1'>");

                #region 欄位

                sbHtml.Append("<tr>");
                string fontColor;
                foreach (System.Data.DataColumn dc in dtBirthdayInfo.Columns)
                {
                    if (dc.ColumnName.ToUpper() != "部門代碼" && dc.ColumnName.ToUpper() != "直屬主管" && dc.ColumnName.ToUpper() != "主管姓名" && dc.ColumnName.ToUpper() != "EMAIL")
                    {
                        fontColor = "";
                        foreach (string highlight in alHighlight)
                        {
                            if (dc.ColumnName == highlight)
                            {
                                fontColor = "color: red;";
                                break;
                            }
                        }
                        sbHtml.AppendFormat("<td style='text-align: center; background-color: rgb(255, 204, 0); {0}'>{1}</td>", fontColor, dc.ColumnName);
                    }
                }
                sbHtml.Append("</tr>");

                #endregion 欄位

                #region 內容

                int rowIndex = 0;
                string backColor;
                foreach (System.Data.DataRow dr in dtBirthdayInfo.Rows)
                {
                    if (type == "Week" && deptCode != dr["部門代碼"].ToString())
                        continue;

                    if (rowIndex % 2 == 0)
                        backColor = "255, 255, 204";
                    else
                        backColor = "255, 255, 153";

                    sbHtml.Append("<tr>");
                    foreach (System.Data.DataColumn dc in dtBirthdayInfo.Columns)
                    {
                        if (dc.ColumnName.ToUpper() != "部門代碼" && dc.ColumnName.ToUpper() != "直屬主管" && dc.ColumnName.ToUpper() != "主管姓名" && dc.ColumnName.ToUpper() != "EMAIL")
                        {
                            fontColor = "";
                            foreach (string highlight in alHighlight)
                            {
                                if (dc.ColumnName == highlight)
                                {
                                    fontColor = "color: red;";
                                    break;
                                }
                            }
                            string align = "center";
                            if (dc.ColumnName == "部門")
                                align = "left";
                            sbHtml.AppendFormat("<td style='text-align: {3}; background-color: rgb({0}); {1}'>{2}</td>", backColor, fontColor, dr[dc.ColumnName], align);
                        }
                    }
                    sbHtml.Append("</tr>");
                    rowIndex++;
                }

                #endregion 內容

                sbHtml.Append("</table>");
                sbHtml.Append("<br>");
            }

            //附圖片
            sbHtml.AppendFormat("<img border='5' height='600' width='800' src='{0}'/>", dbPictureName);
            sbHtml.Append("<br><br>");

            #region 連結

            foreach (System.Data.DataRow dr in dtLinkInfo.Rows)
            {
                string description = dr["Description"].ToString();
                if (description != "")
                {
                    sbHtml.Append(description);
                    sbHtml.Append("<br>");
                }
                sbHtml.AppendFormat("<a href='{0}' target='_blank'>{1}</a>", dr["Link"].ToString(), dr["Text"].ToString());
                sbHtml.Append("<br><br>");
            }

            #endregion 連結

            sbHtml.Append("太極能源 敬上");
        }
        return sbHtml.ToString();
    }

    public string getHtmlContent(string contentSubject, System.Data.DataTable dt, System.Collections.ArrayList alHighlight)
    {
        System.Text.StringBuilder sbHtml = new System.Text.StringBuilder();

        sbHtml.AppendFormat("<font color=blue size='5'><i>{0}</i></font>", contentSubject);
        if (dt.Rows.Count > 0)
        {
            sbHtml.Append("<table border='1'>");

            #region 欄位

            sbHtml.Append("<tr>");
            string fontColor;
            foreach (System.Data.DataColumn dc in dt.Columns)
            {
                fontColor = "";
                foreach (string highlight in alHighlight)
                {
                    if (dc.ColumnName == highlight)
                    {
                        fontColor = "color: blue;";
                        break;
                    }
                }
                sbHtml.AppendFormat("<td style='text-align: center; background-color: rgb(255, 204, 0); {0}'>{1}</td>", fontColor, dc.ColumnName);
            }
            sbHtml.Append("</tr>");

            #endregion 欄位

            #region 內容

            int rowIndex = 0;
            string backColor;
            foreach (System.Data.DataRow dr in dt.Rows)
            {
                if (rowIndex % 2 == 0)
                    backColor = "255, 255, 204";
                else
                    backColor = "255, 255, 153";

                sbHtml.Append("<tr>");
                foreach (System.Data.DataColumn dc in dt.Columns)
                {
                    fontColor = "";
                    foreach (string highlight in alHighlight)
                    {
                        if (dc.ColumnName == highlight)
                        {
                            fontColor = "color: blue;";
                            break;
                        }
                    }
                    sbHtml.AppendFormat("<td style='text-align: center; background-color: rgb({0}); {1}'>{2}</td>", backColor, fontColor, dr[dc.ColumnName]);
                }
                sbHtml.Append("</tr>");
                rowIndex++;
            }

            #endregion 內容

            sbHtml.Append("</table>");
        }
        else
            sbHtml.Append("<br>無符合資訊~");

        return sbHtml.ToString();
    }
}