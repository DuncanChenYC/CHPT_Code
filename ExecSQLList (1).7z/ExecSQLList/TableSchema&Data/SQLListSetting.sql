USE [CHPT]
GO

/****** Object:  Table [dbo].[SQLListSetting]    Script Date: 2025/1/13 �U�� 03:42:49 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[SQLListSetting](
	[ID] [int] IDENTITY(1,1) NOT FOR REPLICATION NOT NULL,
	[Name] [nvarchar](100) NOT NULL,
	[IsExternalClass] [bit] NOT NULL,
	[DBConnName] [varchar](20) NOT NULL,
	[SQLListID] [nvarchar](100) NOT NULL,
	[FixedDate] [nvarchar](30) NULL,
	[FixedDateTime] [time](7) NULL,
	[CycleTimeDaily] [nvarchar](20) NULL,
	[StartTime] [time](7) NULL,
	[EndTime] [time](7) NULL,
	[CycleTimeMinute] [int] NULL,
	[SuccessNotice] [bit] NOT NULL,
	[MailTo] [nvarchar](max) NULL,
	[IsInvalid] [bit] NOT NULL,
	[CreateDate] [datetime] NOT NULL,
	[CreateUser] [nvarchar](6) NOT NULL,
	[LstEdtDate] [datetime] NOT NULL,
	[LstEdtUser] [nvarchar](6) NOT NULL,
 CONSTRAINT [PK_SQLListSetting] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 100) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[SQLListSetting] ADD  DEFAULT ((0)) FOR [IsExternalClass]
GO

ALTER TABLE [dbo].[SQLListSetting] ADD  DEFAULT ('CHPT') FOR [DBConnName]
GO

ALTER TABLE [dbo].[SQLListSetting] ADD  DEFAULT ('�ж�JSQLList��ID') FOR [SQLListID]
GO

ALTER TABLE [dbo].[SQLListSetting] ADD  DEFAULT (N'1,2,3,4,5') FOR [CycleTimeDaily]
GO

ALTER TABLE [dbo].[SQLListSetting] ADD  DEFAULT ('00:00:00') FOR [StartTime]
GO

ALTER TABLE [dbo].[SQLListSetting] ADD  DEFAULT ('00:00:00') FOR [EndTime]
GO

ALTER TABLE [dbo].[SQLListSetting] ADD  DEFAULT ((0)) FOR [CycleTimeMinute]
GO

ALTER TABLE [dbo].[SQLListSetting] ADD  DEFAULT ((0)) FOR [SuccessNotice]
GO

ALTER TABLE [dbo].[SQLListSetting] ADD  DEFAULT ((0)) FOR [IsInvalid]
GO

ALTER TABLE [dbo].[SQLListSetting] ADD  DEFAULT (getdate()) FOR [CreateDate]
GO

ALTER TABLE [dbo].[SQLListSetting] ADD  DEFAULT (N'Admin') FOR [CreateUser]
GO

ALTER TABLE [dbo].[SQLListSetting] ADD  DEFAULT (getdate()) FOR [LstEdtDate]
GO

ALTER TABLE [dbo].[SQLListSetting] ADD  DEFAULT (N'Admin') FOR [LstEdtUser]
GO


