USE [CHPT]
GO

/****** Object:  Table [dbo].[SQLList]    Script Date: 2025/1/13 �U�� 03:42:19 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[SQLList](
	[ID] [int] IDENTITY(1,1) NOT FOR REPLICATION NOT NULL,
	[ProgramName] [nvarchar](50) NOT NULL,
	[FunctionName] [nvarchar](50) NOT NULL,
	[SQL] [nvarchar](max) NOT NULL,
	[OrderBySQL] [nvarchar](500) NULL,
	[IsExternalClass] [bit] NOT NULL,
	[AllowPaging] [bit] NOT NULL,
	[PageSize] [int] NOT NULL,
	[AllowSorting] [bit] NOT NULL,
	[DefaultSortingColName] [nvarchar](50) NULL,
	[DefaultSortingASC] [bit] NOT NULL,
	[FreezeCount] [int] NOT NULL,
	[ExistentHeight] [int] NOT NULL,
	[QueryColumnQty] [int] NOT NULL,
	[MaxRows] [int] NOT NULL,
	[RefID] [int] NULL,
	[AdjustmentWidth] [int] NOT NULL,
	[AD0CS1A_ID] [int] NULL,
	[CreateDate] [datetime] NOT NULL,
	[CreateUser] [nvarchar](30) NULL,
	[LstEdtDate] [datetime] NULL,
	[LstEdtUser] [nvarchar](20) NULL,
 CONSTRAINT [PK_SQLList] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[SQLList] ADD  CONSTRAINT [DF_SQLList_IsExternalClass]  DEFAULT ((0)) FOR [IsExternalClass]
GO

ALTER TABLE [dbo].[SQLList] ADD  CONSTRAINT [DF_SQLList_AllowPaging]  DEFAULT ((0)) FOR [AllowPaging]
GO

ALTER TABLE [dbo].[SQLList] ADD  CONSTRAINT [DF_SQLList_PageSize]  DEFAULT ((0)) FOR [PageSize]
GO

ALTER TABLE [dbo].[SQLList] ADD  CONSTRAINT [DF_SQLList_AllowSorting]  DEFAULT ((0)) FOR [AllowSorting]
GO

ALTER TABLE [dbo].[SQLList] ADD  CONSTRAINT [DF_SQLList_DefaultSortingASC]  DEFAULT ((0)) FOR [DefaultSortingASC]
GO

ALTER TABLE [dbo].[SQLList] ADD  CONSTRAINT [DF_SQLList_FreezeCount]  DEFAULT ((0)) FOR [FreezeCount]
GO

ALTER TABLE [dbo].[SQLList] ADD  CONSTRAINT [DF_SQLList_ExistentHeight]  DEFAULT ((0)) FOR [ExistentHeight]
GO

ALTER TABLE [dbo].[SQLList] ADD  CONSTRAINT [DF_SQLList_QueryColumnQty]  DEFAULT ((3)) FOR [QueryColumnQty]
GO

ALTER TABLE [dbo].[SQLList] ADD  CONSTRAINT [DF_SQLList_MaxRows]  DEFAULT ((1000)) FOR [MaxRows]
GO

ALTER TABLE [dbo].[SQLList] ADD  CONSTRAINT [DF_SQLList_AdjustmentWidth]  DEFAULT ((0)) FOR [AdjustmentWidth]
GO

ALTER TABLE [dbo].[SQLList] ADD  CONSTRAINT [DF_SQLList_CreateDate]  DEFAULT (getdate()) FOR [CreateDate]
GO


