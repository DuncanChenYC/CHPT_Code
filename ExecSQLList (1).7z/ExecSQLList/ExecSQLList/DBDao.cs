﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ERP
{
    public class DBDao
    {
        //Log4net
        //protected static readonly log4net.ILog mLog = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        ERP.LogFile log = new ERP.LogFile("Log");
        string SqlConnStr;
        public System.Data.SqlClient.SqlConnection SqlConn = new System.Data.SqlClient.SqlConnection();
        public System.Data.SqlClient.SqlCommand SqlCommand = new System.Data.SqlClient.SqlCommand();
        public System.Data.SqlClient.SqlTransaction SqlTrans;

        public DBDao(string ConnStr)
        {
            //string strConn = System.Configuration.ConfigurationManager.ConnectionStrings[ConnStr].ConnectionString;
            //SqlConn.ConnectionString = strConn;
            //Select使用
            //SqlConnStr = strConn;

            SqlConn.ConnectionString = ConnStr;
            SqlConnStr = ConnStr;
        }

        public DBDao()
        {
            string ConnStr = System.Configuration.ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();
            SqlConn.ConnectionString = ConnStr;
            //Select使用
            SqlConnStr = ConnStr;
        }

        public void BeginTransaction()
        {
            SqlTrans = SqlConn.BeginTransaction();
            SqlCommand.Transaction = SqlTrans;
        }

        public void Commit()
        {
            SqlTrans.Commit();
        }
        public void Rollback()
        {
            SqlTrans.Rollback();
        }

        public System.Data.DataTable SqlSelect(string sqlQuery)
        {
            System.Data.DataTable dtDBData = new System.Data.DataTable();
            using (System.Data.SqlClient.SqlConnection SqlSelectConn = new System.Data.SqlClient.SqlConnection(SqlConnStr))
            {
                SqlSelectConn.Open();
                try
                {
                    SqlCommand.CommandText = sqlQuery;
                    SqlCommand.Connection = SqlSelectConn;
                    using (System.Data.SqlClient.SqlDataAdapter adapter = new System.Data.SqlClient.SqlDataAdapter())
                    {
                        adapter.SelectCommand = SqlCommand;
                        adapter.Fill(dtDBData);
                    }
                }
                catch (Exception ex) 
                {
                    log.WriteLog(ex.Message);
                }
                finally
                {
                    SqlSelectConn.Close();
                }
            }
            return dtDBData;            
        }        

        public string SqlSelectToString(string sqlQuery, string columnName)
        {
            string str = "";
            using (System.Data.SqlClient.SqlConnection SqlSelectConn = new System.Data.SqlClient.SqlConnection(SqlConnStr))
            {
                SqlSelectConn.Open();
                try
                {
                    System.Data.DataTable dtDBData = new System.Data.DataTable();
                    SqlCommand.CommandText = sqlQuery;
                    SqlCommand.Connection = SqlSelectConn;
                    using (System.Data.SqlClient.SqlDataReader reader = SqlCommand.ExecuteReader())
                    {
                        dtDBData.Load(reader);
                    }
                    if (dtDBData.Rows.Count == 1)
                        str = dtDBData.Rows[0][columnName].ToString();
                }
                catch (Exception ex) 
                {
                    log.WriteLog(ex.Message);
                }
                finally
                {
                    SqlSelectConn.Close();
                }
            }
            return str;
        }

        public System.Data.DataTable SqlSelectByManual(string sqlQuery)
        {
            System.Data.DataTable dtDBData = new System.Data.DataTable();
            try
            {
                SqlCommand.CommandText = sqlQuery;
                SqlCommand.Connection = this.SqlConn;
                using (System.Data.SqlClient.SqlDataAdapter adapter = new System.Data.SqlClient.SqlDataAdapter())
                {
                    adapter.SelectCommand = SqlCommand;
                    adapter.Fill(dtDBData);
                }
            }
            catch (Exception ex)
            {
                log.WriteLog(ex.Message);
            }
            return dtDBData;
        }

        public System.Collections.ArrayList SqlSelect(string sqlQuery, string outputColName)
        {
            System.Collections.ArrayList alDBData = new System.Collections.ArrayList();
            using (System.Data.SqlClient.SqlConnection SqlSelectConn = new System.Data.SqlClient.SqlConnection(SqlConnStr))
            {
                SqlSelectConn.Open();
                try
                {
                    SqlCommand.CommandText = sqlQuery;
                    SqlCommand.Connection = SqlSelectConn;
                    using (System.Data.SqlClient.SqlDataReader reader = SqlCommand.ExecuteReader())
                    {
                        System.Data.DataTable dtDBData = new System.Data.DataTable();
                        dtDBData.Load(reader);

                        foreach (System.Data.DataRow dr in dtDBData.Rows)
                        {
                            alDBData.Add(dr[outputColName]);
                        }
                    }

                }
                catch (Exception ex) 
                {
                    log.WriteLog(ex.Message);
                }
                finally
                {
                    SqlSelectConn.Close();
                }
            }
            return alDBData;
        }

        public bool SqlInsert(string sqlInsert, out object ID)
        {
            ID = -1;
            bool isSuccess = false;
            try
            {
                SqlCommand.CommandText = sqlInsert + ";SELECT SCOPE_IDENTITY();";
                SqlCommand.Connection = SqlConn;
                ID = SqlCommand.ExecuteScalar();
                isSuccess = true;
            }
            catch (Exception ex)
            {
                log.WriteLog(ex.Message);
            }
            return isSuccess;
        }

        public bool SqlInsert(string sqlInsert, out object ID, ref System.Text.StringBuilder sbMsg)
        {
            ID = -1;
            bool isSuccess = false;
            try
            {
                SqlCommand.CommandText = sqlInsert + ";SELECT SCOPE_IDENTITY();";
                SqlCommand.Connection = SqlConn;
                ID = SqlCommand.ExecuteScalar();
                isSuccess = true;
            }
            catch (Exception ex)
            {
                sbMsg.Append(ex.Message + "\\n");
                log.WriteLog(ex.Message);
            }
            return isSuccess;
        }

        public bool SqlInsert(string sqlInsert)
        {
            bool isSuccess = false;
            try
            {
                SqlCommand.CommandText = sqlInsert;
                SqlCommand.Connection = SqlConn;
                SqlCommand.ExecuteNonQuery();
                isSuccess = true;
            }
            catch (Exception ex)
            {
                log.WriteLog(ex.Message);
            }
            return isSuccess;
        }

        public bool SqlInsert(string sqlInsert, ref System.Text.StringBuilder sbMsg)
        {
            bool isSuccess = false;
            try
            {
                SqlCommand.CommandText = sqlInsert;
                SqlCommand.Connection = SqlConn;
                SqlCommand.ExecuteNonQuery();
                isSuccess = true;
            }
            catch (Exception ex)
            {
                sbMsg.Append(ex.Message + "\\n");
                log.WriteLog(ex.Message);
            }
            return isSuccess;
        }

        public bool SqlUpdate(string sqlUpdate)
        {
            bool isSuccess = false;
            try
            {
                SqlCommand.CommandText = sqlUpdate;
                SqlCommand.Connection = SqlConn;
                SqlCommand.ExecuteNonQuery();
                isSuccess = true;
            }
            catch (Exception ex)
            {
                log.WriteLog(ex.Message);
            }
            return isSuccess;
        }

        public bool SqlUpdate(string sqlUpdate, ref System.Text.StringBuilder sbMsg)
        {
            bool isSuccess = false;
            try
            {
                SqlCommand.CommandText = sqlUpdate;
                SqlCommand.Connection = SqlConn;
                SqlCommand.ExecuteNonQuery();
                isSuccess = true;
            }
            catch (Exception ex)
            {
                sbMsg.Append(ex.Message + "\\n");
            }
            return isSuccess;
        }

        public bool SqlDelete(string sqlDelete, ref System.Text.StringBuilder sbMsg)
        {
            bool isSuccess = false;
            try
            {
                SqlCommand.CommandText = sqlDelete;
                SqlCommand.Connection = SqlConn;
                SqlCommand.ExecuteNonQuery();
                isSuccess = true;
            }
            catch (Exception ex)
            {
                sbMsg.Append(ex.Message + "\\n");
                log.WriteLog(ex.Message);
            }
            return isSuccess;
        }

        public bool SqlDelete(string sqlDelete)
        {
            bool isSuccess = false;
            try
            {
                SqlCommand.CommandText = sqlDelete;
                SqlCommand.Connection = SqlConn;
                SqlCommand.ExecuteNonQuery();
                isSuccess = true;
            }
            catch (Exception ex)
            {
                log.WriteLog(ex.Message);
            }
            return isSuccess;
        }

    }
}