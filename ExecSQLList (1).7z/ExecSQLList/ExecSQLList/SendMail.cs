﻿using System;

namespace ERP
{
    public class SendMail
    {
        private string MailHost, MailAccount, MailPWD;
        private int MailPort;

        public SendMail()
        {
            MailHost = "mail.cht-pt.com.tw";
            MailPort = 25;

            MailAccount = "";
            MailPWD = "";
        }

        public SendMail(string mailHost, string mailAccount, string mailPWD)
        {
            MailHost = mailHost;
            MailPort = 25;

            MailAccount = mailAccount;
            MailPWD = mailPWD;
        }

        public bool Send(string subject, string body, string fromAddress, string toAddress, string ccAddress, string bccAddress, string[] filePathAry, string picPath, System.Net.Mail.MailPriority priority)
        {
            bool success = false;
            try
            {
                //MailMessage(寄信者, 收信者)
                success = this.DoSendMail(subject, body, fromAddress, toAddress, ccAddress, bccAddress, filePathAry, picPath, priority);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return success;
        }

        public bool Send(string subject, string body, string fromAddress, string toAddress, string ccAddress, string bccAddress, string picPath, System.Net.Mail.MailPriority priority)
        {
            bool success = false;
            try
            {
                //MailMessage(寄信者, 收信者)
                success = this.DoSendMail(subject, body, fromAddress, toAddress, ccAddress, bccAddress, null, picPath, priority);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return success;
        }

        public bool Send(string subject, string body, string fromAddress, string toAddress, string ccAddress, string bccAddress, string[] filePathAry, string picPath)
        {
            bool success = false;
            try
            {
                //MailMessage(寄信者, 收信者)
                success = this.DoSendMail(subject, body, fromAddress, toAddress, ccAddress, bccAddress, filePathAry, picPath, System.Net.Mail.MailPriority.Normal);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return success;
        }
        public bool Send(string subject, string body, string fromAddress, string toAddress, string ccAddress, string bccAddress, string picPath)
        {
            bool success = false;
            try
            {
                //MailMessage(寄信者, 收信者)
                success = this.DoSendMail(subject, body, fromAddress, toAddress, ccAddress, bccAddress, null, picPath, System.Net.Mail.MailPriority.Normal);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return success;
        }

        private bool DoSendMail(string subject, string body, string fromAddress, string toAddress, string ccAddress, string bccAddress, string[] filePathAry, string picPath, System.Net.Mail.MailPriority priority)
        {
            bool success = false;
            //if (isAuth)
            //{
            System.Net.Mail.MailMessage message = new System.Net.Mail.MailMessage();
            message.From = new System.Net.Mail.MailAddress(fromAddress);

            string[] toAddrAry = toAddress.Split(';');
            foreach (string addr in toAddrAry)
            {
                if (addr.Trim() != "")
                    message.To.Add(new System.Net.Mail.MailAddress(addr));
            }
            string[] ccAddrAry = ccAddress.Split(';');
            foreach (string addr in ccAddrAry)
            {
                if (addr.Trim() != "")
                    message.CC.Add(new System.Net.Mail.MailAddress(addr));
            }
            string[] bccAddrAry = bccAddress.Split(';');
            foreach (string addr in bccAddrAry)
            {
                if (addr.Trim() != "")
                    message.Bcc.Add(new System.Net.Mail.MailAddress(addr));
            }

            message.IsBodyHtml = true;
            //E-mail編碼
            message.BodyEncoding = System.Text.Encoding.UTF8;

            //寄Mail的優先權
            message.Priority = priority;

            //E-mail主旨
            message.Subject = subject;
            //E-mail內容
            message.Body = body;

            #region 附件
            if (filePathAry != null && filePathAry.Length > 0)
            {
                foreach (string path in filePathAry)
                {
                    System.Net.Mail.Attachment attachment = new System.Net.Mail.Attachment(path);
                    message.Attachments.Add(attachment);
                }
            }
            #endregion

            #region 寄Mail內嵌圖片

            if (picPath != "")
            {
                System.Net.Mail.Attachment attachment = new System.Net.Mail.Attachment(picPath);
                attachment.Name = System.IO.Path.GetFileName(picPath);
                attachment.NameEncoding = System.Text.Encoding.GetEncoding("utf-8");
                attachment.TransferEncoding = System.Net.Mime.TransferEncoding.Base64;

                //設定該附件為一個內嵌附件(Inline Attachment)
                attachment.ContentDisposition.Inline = true;
                attachment.ContentDisposition.DispositionType = System.Net.Mime.DispositionTypeNames.Inline;

                message.Attachments.Add(attachment);
            }

            #endregion 寄Mail內嵌圖片

            //設定E-mail Server和port Host：10.11.1.20 Port：25
            System.Net.Mail.SmtpClient smtpClient = new System.Net.Mail.SmtpClient(MailHost, MailPort);
            System.Net.NetworkCredential credentialInfo = new System.Net.NetworkCredential(MailAccount, MailPWD);
            smtpClient.Credentials = credentialInfo;
            smtpClient.UseDefaultCredentials = false;

            //smtpClient.Send(message);
            Exception ex = new Exception();
            System.Text.StringBuilder sbMsg = new System.Text.StringBuilder();
            bool isSuccess = this.WhileSendMail(smtpClient, message, ref sbMsg, ref ex);

            message.Dispose();
            success = true;

            return success;
        }

        private void SendErrorLog(string subject, string body, string toAddress, string ccAddress, string bccAddress, string picPath, string[] filePathAry, Exception ex)
        {
            //System.Text.StringBuilder sbFilePath = new System.Text.StringBuilder();
            //foreach (string filePath in filePathAry)
            //    sbFilePath.AppendFormat("[{0}]；", filePath);

            //log.Error(string.Format("\n【ERPLibraryTab發送】Email傳送失敗！\n【Mail主旨】{1}\n【Mail內容】{2}\n【Mail To】{3}\n【Mail Cc】{4}\n【Mail Bcc】{5}\n【檔案路徑】{6}\n【圖片路徑】{7}", subject, body, toAddress, ccAddress, bccAddress, sbFilePath.ToString(), picPath), ex);
        }

        private bool WhileSendMail(System.Net.Mail.SmtpClient SMTPmail, System.Net.Mail.MailMessage MailMsg, ref System.Text.StringBuilder sbMsg, ref Exception ex)
        {
            bool isSuccess = false;

            int index = 1, max = 10;
            while (index <= max)
            {
                try
                {
                    if (index != 1)
                        System.Threading.Thread.Sleep(500);

                    SMTPmail.Send(MailMsg);
                    isSuccess = true;
                    index = max;
                }
                catch (Exception exception)
                {
                    isSuccess = false;
                    if (index == max)
                    {
                        sbMsg.AppendFormat("發送失敗，已達發送Mail上限次數【{0}】", index);
                        ex = exception;
                    }
                }
                index++;
            }
            return isSuccess;
        }

        /// <summary>
        /// 發送行事曆事件
        /// </summary>
        /// <param name="subject"></param>
        /// <param name="body"></param>
        /// <param name="fromAddress"></param>
        /// <param name="toAddress"></param>
        /// <param name="ccAddress"></param>
        /// <param name="bccAddress"></param>
        /// <param name="filePathAry"></param>
        /// <param name="picPath"></param>
        /// <param name="priority"></param>
        /// <param name="format"></param>
        /// <returns></returns>
        public bool SendCalendar(string subject, string body, string fromAddress, string toAddress, string ccAddress, string bccAddress, string[] filePathAry, string picPath, System.Net.Mail.MailPriority priority, CalendarFormat format)
        {
            bool success = false;
            System.Net.Mail.MailMessage message = new System.Net.Mail.MailMessage();
            message.From = new System.Net.Mail.MailAddress(fromAddress);

            string[] toAddrAry = toAddress.Split(';');
            foreach (string addr in toAddrAry)
            {
                if (addr.Trim() != "")
                    message.To.Add(new System.Net.Mail.MailAddress(addr));
            }
            string[] ccAddrAry = ccAddress.Split(';');
            foreach (string addr in ccAddrAry)
            {
                if (addr.Trim() != "")
                    message.CC.Add(new System.Net.Mail.MailAddress(addr));
            }
            string[] bccAddrAry = bccAddress.Split(';');
            foreach (string addr in bccAddrAry)
            {
                if (addr.Trim() != "")
                    message.Bcc.Add(new System.Net.Mail.MailAddress(addr));
            }

            message.IsBodyHtml = true;
            //E-mail編碼
            message.BodyEncoding = System.Text.Encoding.UTF8;

            //寄Mail的優先權
            message.Priority = priority;

            //E-mail主旨
            message.Subject = subject;
            //E-mail內容
            message.Body = body;

            #region 附件

            if (filePathAry != null && filePathAry.Length > 0)
            {
                foreach (string path in filePathAry)
                {
                    System.Net.Mail.Attachment attachment = new System.Net.Mail.Attachment(path);
                    message.Attachments.Add(attachment);
                }
            }

            #endregion 附件

            #region 寄Mail內嵌圖片

            if (picPath != "")
            {
                System.Net.Mail.Attachment attachment = new System.Net.Mail.Attachment(picPath);
                attachment.Name = System.IO.Path.GetFileName(picPath);
                attachment.NameEncoding = System.Text.Encoding.GetEncoding("utf-8");
                attachment.TransferEncoding = System.Net.Mime.TransferEncoding.Base64;

                //設定該附件為一個內嵌附件(Inline Attachment)
                attachment.ContentDisposition.Inline = true;
                attachment.ContentDisposition.DispositionType = System.Net.Mime.DispositionTypeNames.Inline;

                message.Attachments.Add(attachment);
            }

            #endregion 寄Mail內嵌圖片

            //設定E-mail Server和port Host：10.11.1.20 Port：25
            System.Net.Mail.SmtpClient smtpClient = new System.Net.Mail.SmtpClient(MailHost, MailPort);
            System.Net.NetworkCredential credentialInfo = new System.Net.NetworkCredential(MailAccount, MailPWD);

            #region 會議邀請設定

            /*RFC 5545規範*/

            #region 會議邀請的格式

            System.Text.StringBuilder sbMailFormat = new System.Text.StringBuilder();
            sbMailFormat.AppendLine("BEGIN:VCALENDAR");
            sbMailFormat.AppendLine("PRODID:-//Microsoft Corporation//Outlook 12.0 MIMEDIR//EN");
            sbMailFormat.AppendLine("VERSION:2.0");
            sbMailFormat.AppendLine("METHOD:REQUEST");
            sbMailFormat.AppendLine("X-MS-OLK-FORCEINSPECTOROPEN:TRUE");

            #region 時區

            sbMailFormat.AppendLine("BEGIN:VTIMEZONE");
            sbMailFormat.AppendLine("TZID:(UTC+08:00) 台北");
            sbMailFormat.AppendLine("BEGIN:STANDARD");
            sbMailFormat.AppendLine("DTSTART:16010101T000000");
            sbMailFormat.AppendLine("TZOFFSETTO:+0800");
            sbMailFormat.AppendLine("TZOFFSETFROM:+0800");
            sbMailFormat.AppendLine("END:STANDARD");
            sbMailFormat.AppendLine("END:VTIMEZONE");

            #endregion 時區

            #region 行事曆內容設定

            sbMailFormat.AppendLine("BEGIN:VEVENT");
            sbMailFormat.AppendLine("CLASS:PUBLIC");
            // 定義時區
            sbMailFormat.AppendLine(string.Format("DTSTAMP;TZID=\"(UTC+08:00) 台北\":{0:yyyyMMddTHHmmss}", DateTime.Now));
            // Book 的 起始時間。
            sbMailFormat.AppendLine(string.Format("DTSTART;TZID=\"(UTC+08:00) 台北\":{0:yyyyMMddTHHmmss}", format.StartDateTime));
            // Book 的 結束時間。
            sbMailFormat.AppendLine(string.Format("DTEND;TZID=\"(UTC+08:00) 台北\":{0:yyyyMMddTHHmmss}", format.EndDateTime));
            //地點
            sbMailFormat.AppendLine(string.Format("LOCATION: {0}", format.Location));
            //UID
            sbMailFormat.AppendLine(string.Format("UID:{0}", Guid.NewGuid()));
            //主旨
            sbMailFormat.AppendLine(string.Format("SUMMARY;LANGUAGE=zh-tw:{0}", message.Subject));
            //召集人Mail
            sbMailFormat.AppendLine(string.Format("ORGANIZER:mailto:{0}", format.Organizer));
            //內容
            sbMailFormat.AppendLine(string.Format("X-ALT-DESC;FMTTYPE=text/html:{0}", message.Body));
            //重要性
            if (format.Importance)
                sbMailFormat.AppendLine(string.Format("X-MICROSOFT-CDO-IMPORTANCE:{0}", 2));
            //顯示為
            sbMailFormat.AppendLine(string.Format("X-MICROSOFT-CDO-BUSYSTATUS:{0}", ((Busystatus)format.Status).ToString()));
            sbMailFormat.AppendLine(string.Format("X-MS-OLK-AUTOFILLLOCATION:{0}", "FALSE"));
            sbMailFormat.AppendLine(string.Format("X-MS-OLK-AUTOSTARTCHECK:{0}", "FALSE"));
            //sbMailFormat.AppendLine(string.Format("ATTENDEE;CN=\"{0}\";RSVP=TRUE:mailto:{1}", message.To[0].DisplayName, message.To[0].Address));

            //週期性
            //sbMailFormat.AppendLine(string.Format("RRULE:FREQ=WEEKLY;COUNT=10;BYDAY=TU", ""));

            #region 提醒

            if (format.AlarmMinute > -1)
            {
                sbMailFormat.AppendLine("BEGIN:VALARM");
                sbMailFormat.AppendLine(string.Format("TRIGGER:-PT{0}M", format.AlarmMinute));
                sbMailFormat.AppendLine("ACTION:DISPLAY");
                sbMailFormat.AppendLine("END:VALARM");
            }

            #endregion 提醒

            sbMailFormat.AppendLine("END:VEVENT");

            #endregion 行事曆內容設定

            sbMailFormat.AppendLine("END:VCALENDAR");

            #endregion 會議邀請的格式

            System.Net.Mime.ContentType ct = new System.Net.Mime.ContentType("text/calendar");
            ct.Parameters.Add("METHOD", "REQUEST");
            System.Net.Mail.AlternateView avCal = System.Net.Mail.AlternateView.CreateAlternateViewFromString(sbMailFormat.ToString(), ct);
            message.AlternateViews.Add(avCal);

            #endregion 會議邀請設定

            smtpClient.Credentials = credentialInfo;
            smtpClient.UseDefaultCredentials = false;
            smtpClient.Send(message);
            message.Dispose();
            success = true;
            return success;
        }

        public struct CalendarFormat
        {
            /// <summary>
            /// 召集人
            /// </summary>
            public string Organizer;

            /// <summary>
            /// 開始日期時間 yyyy/MM/dd HH:mm:ss
            /// </summary>
            public DateTime StartDateTime;

            /// <summary>
            /// 結束時間 yyyy/MM/dd HH:mm:ss
            /// </summary>
            public DateTime EndDateTime;

            /// <summary>
            /// 地點
            /// </summary>
            public string Location;

            /// <summary>
            /// 高重要性
            /// </summary>
            public bool Importance;

            /// <summary>
            /// 顯示狀態
            /// </summary>
            public Busystatus Status;

            /// <summary>
            /// 提醒(分鐘)
            /// </summary>
            public int AlarmMinute;
        }

        public enum Busystatus
        {
            /// <summary>
            /// 空閒
            /// </summary>
            FREE,

            /// <summary>
            /// 暫訂
            /// </summary>
            TENTATIVE,

            /// <summary>
            /// 忙碌
            /// </summary>
            BUSY,

            /// <summary>
            /// 不在辦公室
            /// </summary>
            OOF
        }

        public string getBirthdayHtmlContent(System.Data.DataTable dtBirthdayInfo, System.Data.DataTable dtMailFormat, System.Data.DataTable dtLinkInfo, string type, string deptCode)
        {
            System.Text.StringBuilder sbHtml = new System.Text.StringBuilder();
            //if (isAuth)
            //{
            if (dtMailFormat.Rows.Count == 1)
            {
                string dbPicturePath = dtMailFormat.Rows[0]["PicturePath"].ToString();
                string dbPictureName = dtMailFormat.Rows[0]["PictureName"].ToString();

                sbHtml.Append(dtMailFormat.Rows[0]["MailContent"].ToString());
                sbHtml.Append("<br><br>");

                System.Collections.ArrayList alHighlight = new System.Collections.ArrayList();
                alHighlight.Add("姓名");

                if (type == "Day")
                {
                }
                else if (type == "Week" || type == "Month")
                {
                    sbHtml.Append("<table border='1'>");

                    #region 欄位

                    sbHtml.Append("<tr>");
                    string fontColor;
                    foreach (System.Data.DataColumn dc in dtBirthdayInfo.Columns)
                    {
                        if (dc.ColumnName.ToUpper() != "部門代碼" && dc.ColumnName.ToUpper() != "直屬主管" && dc.ColumnName.ToUpper() != "主管姓名" && dc.ColumnName.ToUpper() != "EMAIL")
                        {
                            fontColor = "";
                            foreach (string highlight in alHighlight)
                            {
                                if (dc.ColumnName == highlight)
                                {
                                    fontColor = "color: red;";
                                    break;
                                }
                            }
                            sbHtml.AppendFormat("<td style='text-align: center; background-color: rgb(255, 204, 0); {0}'>{1}</td>", fontColor, dc.ColumnName);
                        }
                    }
                    sbHtml.Append("</tr>");

                    #endregion 欄位

                    #region 內容

                    int rowIndex = 0;
                    string backColor;
                    foreach (System.Data.DataRow dr in dtBirthdayInfo.Rows)
                    {
                        if (type == "Week" && deptCode != dr["部門代碼"].ToString())
                            continue;

                        if (rowIndex % 2 == 0)
                            backColor = "255, 255, 204";
                        else
                            backColor = "255, 255, 153";

                        sbHtml.Append("<tr>");
                        foreach (System.Data.DataColumn dc in dtBirthdayInfo.Columns)
                        {
                            if (dc.ColumnName.ToUpper() != "部門代碼" && dc.ColumnName.ToUpper() != "直屬主管" && dc.ColumnName.ToUpper() != "主管姓名" && dc.ColumnName.ToUpper() != "EMAIL")
                            {
                                fontColor = "";
                                foreach (string highlight in alHighlight)
                                {
                                    if (dc.ColumnName == highlight)
                                    {
                                        fontColor = "color: red;";
                                        break;
                                    }
                                }
                                string align = "center";
                                if (dc.ColumnName == "部門")
                                    align = "left";
                                sbHtml.AppendFormat("<td style='text-align: {3}; background-color: rgb({0}); {1}'>{2}</td>", backColor, fontColor, dr[dc.ColumnName], align);
                            }
                        }
                        sbHtml.Append("</tr>");
                        rowIndex++;
                    }

                    #endregion 內容

                    sbHtml.Append("</table>");
                    sbHtml.Append("<br>");
                }

                //附圖片
                sbHtml.AppendFormat("<img border='5' height='600' width='800' src='{0}'/>", dbPictureName);
                sbHtml.Append("<br><br>");

                #region 連結

                foreach (System.Data.DataRow dr in dtLinkInfo.Rows)
                {
                    string description = dr["Description"].ToString();
                    if (description != "")
                    {
                        sbHtml.Append(description);
                        sbHtml.Append("<br>");
                    }
                    sbHtml.AppendFormat("<a href='{0}' target='_blank'>{1}</a>", dr["Link"].ToString(), dr["Text"].ToString());
                    sbHtml.Append("<br><br>");
                }

                #endregion 連結

                sbHtml.Append("太極能源 敬上");
            }
            //}
            return sbHtml.ToString();
        }

        public string getHtmlContent(string contentSubject, System.Data.DataTable dt, System.Collections.ArrayList alHighlight)
        {
            System.Text.StringBuilder sbHtml = new System.Text.StringBuilder();
            //if (isAuth)
            //{
            sbHtml.AppendFormat("<font color=blue size='5'><i>{0}</i></font>", contentSubject);
            if (dt.Rows.Count > 0)
            {
                sbHtml.Append("<table border='1'>");

                #region 欄位

                sbHtml.Append("<tr>");
                string fontColor;
                foreach (System.Data.DataColumn dc in dt.Columns)
                {
                    fontColor = "";
                    foreach (string highlight in alHighlight)
                    {
                        if (dc.ColumnName == highlight)
                        {
                            fontColor = "color: blue;";
                            break;
                        }
                    }
                    sbHtml.AppendFormat("<td style='text-align: center; background-color: rgb(255, 204, 0); {0}'>{1}</td>", fontColor, dc.ColumnName);
                }
                sbHtml.Append("</tr>");

                #endregion 欄位

                #region 內容

                int rowIndex = 0;
                string backColor;
                foreach (System.Data.DataRow dr in dt.Rows)
                {
                    if (rowIndex % 2 == 0)
                        backColor = "255, 255, 204";
                    else
                        backColor = "255, 255, 153";

                    sbHtml.Append("<tr>");
                    foreach (System.Data.DataColumn dc in dt.Columns)
                    {
                        fontColor = "";
                        foreach (string highlight in alHighlight)
                        {
                            if (dc.ColumnName == highlight)
                            {
                                fontColor = "color: blue;";
                                break;
                            }
                        }
                        sbHtml.AppendFormat("<td style='text-align: center; background-color: rgb({0}); {1}'>{2}</td>", backColor, fontColor, dr[dc.ColumnName]);
                    }
                    sbHtml.Append("</tr>");
                    rowIndex++;
                }

                #endregion 內容

                sbHtml.Append("</table>");
            }
            else
                sbHtml.Append("<br>無符合資訊~");
            //}
            return sbHtml.ToString();
        }
    }
}