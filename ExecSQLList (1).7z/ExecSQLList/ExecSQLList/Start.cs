﻿using System;
using System.Diagnostics;
using System.Text;

namespace ExecSQLList
{
    internal class Start
    {
        private static void Main(string[] args)
        {
            bool isTest = false; //for Test
            bool isTestCommit = false;
            string testID = "";
            if (isTest)
                testID = "AND ID IN (33)";

            System.Text.StringBuilder sbLog = new StringBuilder();
            sbLog.AppendFormat(System.Environment.NewLine + "/*  啟動時間：{0}  是否測試：{1}*/", System.DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss"), isTest);

            ERP.SendMail send = new ERP.SendMail();
            System.Text.StringBuilder sbMsg = new StringBuilder();

            string SQLName = "";
            string mailFrom = "ERP小組 <mailReport@cht-pt.com.tw>";
            string mailTo = "";
            try
            {
                System.DateTime dtimeNow;
                if (isTest)
                    dtimeNow = new DateTime(2019, 07, 11, 15, 00, 00);
                else
                    dtimeNow = System.DateTime.Now;
                    //dtimeNow = new DateTime(2021, 11, 09, 08, 47, 00); //for Test

                string weekIndex = dtimeNow.DayOfWeek.ToString("d");

                #region 固定日期轉換

                int nowDay = dtimeNow.Day;
                string fixedDate = "";
                if (nowDay == 1)
                    fixedDate = "F";
                else
                {
                    int endDay = Convert.ToDateTime(DateTime.Now.ToString("yyyy/MM/") + "01").AddMonths(1).AddDays(-1).Day;
                    if (nowDay == endDay)
                        fixedDate = "E";
                    else
                        fixedDate = nowDay.ToString("D2");
                }

                #endregion 固定日期轉換

                string CHPTConnStr = string.Format(System.Configuration.ConfigurationManager.ConnectionStrings["ConnectionString"].ToString(), "CHPT");
                ERP.DBDao dao = new ERP.DBDao(CHPTConnStr);

                #region 取得符合資料的SQL語法

                string sqlQuery = string.Format(@"
					SELECT Name, IsExternalClass, DBConnName, SQLListID, FixedDate, FixedDateTime, CycleTimeDaily, StartTime, EndTime, CycleTimeMinute, MailTo, SuccessNotice
                    FROM dbo.SQLListSetting WITH(NOLOCK)
                    WHERE IsInvalid = '0' AND (CycleTimeDaily LIKE @CycleTimeDaily OR FixedDate LIKE @FixedDate)
                        {0}", testID);
                dao.SqlCommand.Parameters.Clear();
                dao.SqlCommand.Parameters.AddWithValue("@CycleTimeDaily", string.Format("%{0}%", weekIndex));
                dao.SqlCommand.Parameters.AddWithValue("@FixedDate", string.Format("%{0}%", fixedDate));
                System.Data.DataTable dtSQLListSetting = dao.SqlSelect(sqlQuery);

                #endregion 取得符合資料的SQL語法

                //查看是否有符合的週期(星期幾)
                if (dtSQLListSetting.Rows.Count > 0)
                {
                    #region 參數定義

                    bool isSuccss;
                    string SQLListIDAryList = "";
                    System.DateTime dtimeStart, dtimeEnd;

                    #endregion 參數定義

                    foreach (System.Data.DataRow dr in dtSQLListSetting.Rows)
                    {
                        isSuccss = true;
                        sbMsg.Clear();

                        /*取得連線DB名稱*/
                        string DBConnName = dr["DBConnName"].ToString();
                        SQLName = dr["Name"].ToString();
                        mailFrom = "ERP小組 <mailReport@cht-pt.com.tw>";                        

                        bool isOverDay = false;
                        bool isFixedDate = (dr["FixedDate"].ToString() != "");

                        dtimeStart = Convert.ToDateTime(dtimeNow.ToString("yyyy/MM/dd") + " " + (isFixedDate ? dr["FixedDateTime"].ToString() : dr["StartTime"].ToString()));
                        dtimeEnd = Convert.ToDateTime(dtimeNow.ToString("yyyy/MM/dd") + " " + (isFixedDate ? dr["FixedDateTime"].ToString() : dr["EndTime"].ToString()));

                        #region 若結束時間比起始時間還小，則需加一日

                        if (dtimeStart.CompareTo(dtimeEnd) >= 0)
                        {
                            isOverDay = true;
                            dtimeEnd = dtimeEnd.AddDays(1);
                        }

                        #endregion 若結束時間比起始時間還小，則需加一日

                        int addMinutes = 15;
                        dtimeEnd = dtimeEnd.AddMinutes(addMinutes);

                        if (dtimeEnd.CompareTo(dtimeNow) >= 0)
                        {
                            #region 確認時間是否符合，可誤差5分鐘

                            int cycleMinute = Convert.ToInt32(dr["CycleTimeMinute"]);
                            if (CheckExecTime(isFixedDate, dtimeStart, dtimeEnd, dtimeNow, isOverDay, cycleMinute, addMinutes))
                            {
                                #region 確認是否符合執行時間

                                string ConnStr = string.Format(System.Configuration.ConfigurationManager.ConnectionStrings["ConnectionString"].ToString(), DBConnName);
                                ERP.DBDao daoExec = new ERP.DBDao(ConnStr);
                                daoExec.SqlConn.Open();
                                daoExec.BeginTransaction();
                                daoExec.SqlCommand.CommandTimeout = 180;
                                try
                                {
                                    if (Convert.ToBoolean(dr["IsExternalClass"]))
                                    {
                                        #region 特殊來源透過External的Class取得Mail內容的資料

                                        string externalClass = dr["SQLListID"].ToString();
                                        switch (externalClass)
                                        {
                                            case "ERP2Docpedia":
                                                ERP2Docpedia docpedia = new ERP2Docpedia();
                                                /*同步更新華苓文管系統組織樹*/
                                                /*1. 先寫入Temp資料庫*/
                                                isSuccss = docpedia.Insert2DocpediaTemp(daoExec, ref sbMsg);
                                                /*2. 再比對Temp資料庫後，寫入正式資料庫*/
                                                isSuccss = isSuccss && docpedia.Insert2Docpedia(daoExec, ref sbMsg);
                                                /*3. 更新文管*/
                                                isSuccss = isSuccss && docpedia.Update2Docpedia(daoExec, ref sbMsg);
                                                break;

                                            case "UpdateFinishedDateByStep":
                                                AutoUpdateDsProjectFinishedDate dsProject = new AutoUpdateDsProjectFinishedDate();
                                                isSuccss = dsProject.UpdateFinishedDateByStep(daoExec, ref sbMsg);
                                                break;
                                        }

                                        #endregion 特殊來源透過External的Class取得Mail內容的資料
                                    }
                                    else
                                    {
                                        #region 透過SQLList ID取得SQLList的SQL語法

                                        SQLListIDAryList = dr["SQLListID"].ToString();
                                        string sqlQuerySQLList = string.Format(@"SELECT ID, SQL FROM dbo.SQLList WITH(NOLOCK) WHERE ID IN ({0})", SQLListIDAryList);
                                        System.Data.DataTable dtSQLList = dao.SqlSelect(sqlQuerySQLList);
                                        if (dtSQLList.Rows.Count > 0)
                                        {
                                            string id = "";
                                            string[] listIDAry = SQLListIDAryList.Split(',');
                                            for (int i = 0; i < listIDAry.Length; i++)
                                            {
                                                id = listIDAry[i];
                                                System.Data.DataRow[] drSQLAry = dtSQLList.Select(string.Format("ID = '{0}'", id));
                                                if (drSQLAry.Length == 1)
                                                {
                                                    isSuccss = isSuccss && daoExec.SqlInsert(drSQLAry[0]["SQL"].ToString(), ref sbMsg);
                                                    if (!isSuccss)
                                                        break;
                                                }
                                                else
                                                {
                                                    isSuccss = false;
                                                    string msg = string.Format("執行名稱：{0}  【執行失敗：SQLList設定的ID({1})不唯一】", SQLName, id);
                                                    sbMsg.Append(msg);
                                                    sbLog.AppendFormat(System.Environment.NewLine + "--  {0} --", msg);
                                                    break;
                                                }
                                            }
                                        }
                                        else
                                        {
                                            isSuccss = false;
                                            string msg = string.Format("執行名稱：{0}  【執行失敗：查無SQLList的ID({1})資料】", SQLName, SQLListIDAryList);
                                            sbMsg.Append(msg);
                                            sbLog.AppendFormat(System.Environment.NewLine + "--  {0} --", msg);
                                        }

                                        #endregion 透過SQLList ID取得SQLList的SQL語法
                                    }
                                }
                                catch (Exception ex)
                                {
                                    isSuccss = false;
                                    string msg = string.Format("執行名稱：{0}  【執行失敗：{1}】", SQLName, ex.Message);
                                    sbMsg.Append(msg);
                                    sbLog.AppendFormat(System.Environment.NewLine + "--  {0} --", msg);
                                }
                                finally
                                {
                                    if (daoExec.SqlTrans.Connection != null)
                                    {
                                        if (isSuccss)
                                        {
                                            if (isTest)
                                            {
                                                if (isTestCommit)
                                                    daoExec.Commit();
                                                else
                                                    daoExec.Rollback();
                                            }
                                            else
                                                daoExec.Commit();
                                        }
                                        else
                                            daoExec.Rollback();
                                    }
                                    daoExec.SqlConn.Close();                                    
                                }

                                #region 發送Mail

                                bool isSend = false;

                                mailTo = dao.SqlSelectToString(dr["MailTo"].ToString(), "Email");
                                if (mailTo == "")
                                    mailTo = "ERP小組 <erp@cht-pt.com.tw>;";

                                string mailContent = "";
                                System.Net.Mail.MailPriority mailPriority;

                                if (isSuccss)
                                {
                                    #region 測試使用

                                    if (isTest)
                                        mailTo = string.Format("{0} [erp@cht-pt.com.tw];", mailTo.Replace("@cht-pt.com.tw", "").Replace(";", ""));

                                    #endregion 測試使用

                                    //Mail的內容
                                    mailContent = string.Format("你好,<br><br>執行SQLListSetting - 【{0} 】成功！<br><br>Best regards,<br>Mail Report System", SQLName);

                                    //Mail的優先權
                                    mailPriority = System.Net.Mail.MailPriority.Normal;
                                }
                                else
                                {
                                    #region 失敗訊息

                                    mailFrom = "ExecSQLList錯誤 <execSQLList@cht-pt.com.tw>";
                                    if (isTest)
                                        mailTo = string.Format("{0} <erp@cht-pt.com.tw>;", mailTo.Replace("@cht-pt.com.tw", "").Replace(";", ""));
                                    else
                                        mailTo = "ERP小組 <erp@cht-pt.com.tw>";

                                    mailPriority = System.Net.Mail.MailPriority.High;
                                    mailContent = string.Format("你好,<br><br>【{0}】錯訊訊息如下：<br>{1}<br><br>Best regards,<br>Mail Report System", SQLName, sbMsg);

                                    #endregion 失敗訊息
                                }

                                bool isSuccessNotice = Convert.ToBoolean(dr["SuccessNotice"]);
                                /*1.回傳成功且設定成功需通知
                                    2.結果失敗
                                */
                                if ((isSuccessNotice && isSuccss) || !isSuccss)
                                {
                                    mailTo = mailTo.Replace("[", "<").Replace("]", ">");
                                    string mailCc = "", mailBcc = "";
                                    string subject = string.Format("{0} - 【{1}】", SQLName, isSuccss ? "成功" : "失敗");
                                    isSend = send.Send(subject, mailContent, mailFrom, mailTo, mailCc, mailBcc, "", mailPriority);
                                }

                                sbLog.AppendFormat(System.Environment.NewLine + "--  執行名稱：{0}  【是否發送成功通知Mail：{1} 發送結果：{2}】 --", SQLName, isSuccessNotice, isSend);

                                #endregion 發送Mail

                                #endregion 確認是否符合執行時間
                            }
                            else
                                sbLog.AppendFormat(System.Environment.NewLine + "--  執行名稱：{0}  【發送結果：時間不符合設定】dtimeNow：{1} dtimeStart：{2}--", SQLName, dtimeNow, dtimeStart.AddMinutes(addMinutes));

                            #endregion 確認時間是否符合，可誤差5分鐘
                        }
                        else
                            sbLog.AppendFormat(System.Environment.NewLine + "--  執行名稱：{0}  【發送結果：超過結束時間】 dtimeEnd：{1} dtimeStart：{2}--", SQLName, dtimeEnd, dtimeStart);
                    }
                }
            }
            catch (Exception ex)
            {
                StackTrace st = new StackTrace();
                sbMsg.Append(ex.Message + ";Stack Trace:" + st.ToString());

                mailFrom = "ExecSQLList【例外處理】錯誤 <execSQLList@cht-pt.com.tw>";
                mailTo = string.Format("{0} <erp@cht-pt.com.tw>;", mailTo == "" ? "ERP小組" : mailTo.Replace("@cht-pt.com.tw", "").Replace(";", ""));
                //if (isTest)
                //    mailTo.Replace("erp@", "tab.kuo@");

                sbLog.AppendFormat(System.Environment.NewLine + string.Format("-- 執行失敗【{0}】{1}", SQLName, ex.StackTrace));
                send.Send("ExecSQLList 執行失敗~", string.Format("【{0}】{1}", SQLName, ex.Message), mailFrom, mailTo, "", "", "", System.Net.Mail.MailPriority.High);
            }

            ERP.LogFile log = new ERP.LogFile("Log");
            log.WriteLog(sbLog.ToString());
        }

        private static bool CheckExecTime(bool isFixedDate, System.DateTime dtimeStart, System.DateTime dtimeEnd, System.DateTime dtimeNow, bool isOverDay, int cycleMinute, int addMinutes)
        {
            /*時間差*/
            int minutesDifference = 0;

            bool isCheckOK = false;
            if (isFixedDate)
            {
                TimeSpan tsNow = new TimeSpan(dtimeNow.Ticks);
                TimeSpan tsStart = new TimeSpan(dtimeStart.Ticks);
                TimeSpan ts = tsNow.Subtract(tsStart).Duration();
                if (ts.TotalMinutes >= 0 && ts.TotalMinutes <= addMinutes)
                    isCheckOK = true;

                //isCheckOK = dtimeNow.ToString("HH:mm") == dtimeStart.ToString("HH:mm");
            }
            else
            {
                int StartMinutes = dtimeStart.Hour * 60 + dtimeStart.Minute;
                int EndMinutes = dtimeEnd.Hour * 60 + dtimeEnd.Minute;
                int NowMinutes = dtimeNow.Hour * 60 + dtimeNow.Minute;

                if (isOverDay)
                {                    
                    if (NowMinutes >= StartMinutes && NowMinutes < 1440)
                    {
                        minutesDifference = (NowMinutes - StartMinutes);
                        isCheckOK = (minutesDifference % cycleMinute >= 0) && (minutesDifference % cycleMinute <= addMinutes);
                    }
                    else if (EndMinutes >= NowMinutes)
                    {
                        NowMinutes = NowMinutes + (1440 - StartMinutes);
                        minutesDifference = (NowMinutes % cycleMinute);
                        isCheckOK = (minutesDifference >= 0) && (minutesDifference <= addMinutes);                        
                    }
                }
                else
                {
                    if (NowMinutes >= StartMinutes && EndMinutes >= NowMinutes)
                    {
                        minutesDifference = (NowMinutes - StartMinutes);
                        isCheckOK = (minutesDifference % cycleMinute >= 0) && (minutesDifference % cycleMinute <= addMinutes);
                    }
                }
            }
            return isCheckOK;
        }
    }
}