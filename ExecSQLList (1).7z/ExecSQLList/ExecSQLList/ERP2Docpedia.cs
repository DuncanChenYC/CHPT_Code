﻿using System.Text;

namespace ExecSQLList
{
    internal class ERP2Docpedia
    {
        private string ERPConnStr = string.Format(System.Configuration.ConfigurationManager.ConnectionStrings["ConnectionString"].ToString(), "CHPT");

        //正式區、測試區
        private string DocpediaConnStr = System.Configuration.ConfigurationManager.ConnectionStrings["DocpediaConnStr"].ToString();

        //string strERPDBName = "CHPT_Tab_0724";
        private string strDocpediaDBName = "AgentFlow";

        private int intDeptNomlCnt = 140;//若組織數少於50不更新，目前生效組織數 211 筆
        private int intEmpNomlCnt = 550;//若人事數少於500不更新，目前生效員工數 806 筆

        //public ERP2Docpedia()
        //{
        //    bool isSuccess = false;
        //    System.Text.StringBuilder sbMsg = new StringBuilder();

        //    ERP.DBDao daoExec = new ERP.DBDao(ERPConnStr);
        //    daoExec.SqlConn.Open();
        //    daoExec.BeginTransaction();
        //    try
        //    {
        //        isSuccess = Insert2DocpediaTemp(daoExec, ref sbMsg);
        //    }
        //    catch (Exception ex)
        //    {
        //        isSuccess = false;
        //        sbMsg.Append(ex.Message);
        //    }
        //    finally
        //    {
        //        if (isSuccess)
        //            daoExec.Commit();
        //        else
        //            daoExec.Rollback();
        //    }

        //    daoExec.BeginTransaction();
        //    try
        //    {
        //        isSuccess = Insert2Docpedia(daoExec, ref sbMsg);
        //    }
        //    catch (Exception ex)
        //    {
        //        isSuccess = false;
        //        sbMsg.Append(ex.Message);
        //    }
        //    finally
        //    {
        //        if (isSuccess)
        //            daoExec.Commit();
        //        else
        //            daoExec.Rollback();
        //    }

        //    daoExec.SqlConn.Close();
        //}

        #region Temp Table 處理

        public bool Insert2DocpediaTemp(ERP.DBDao dao, ref System.Text.StringBuilder sbMsg)
        {
            bool isSuccess = false;
            bool bUpdateSQL = false;
            StringBuilder sbErr = new StringBuilder();
            string strErrTip = "華苓文管系統組織匯入失敗，錯誤原因：";
            string sqlQuery = "";
            string strSQL = "";

            #region 資料庫連線

            ERP.DBDao daoERPSelect = new ERP.DBDao(ERPConnStr);
            //daoERPSelect.SqlConn.Open();
            ERP.DBDao daoDocpediaSelect = new ERP.DBDao(DocpediaConnStr);
            //daoDocpediaSelect.SqlConn.Open();

            #endregion 資料庫連線

            #region 一、. 確認組織/人事檢視表是否有資料，若有才繼續執行

            #region 1.1 確認 Flowring_View_HR_Department 筆數 >正常組織數

            int DeptTblCnt = 0;
            sqlQuery = @" select count(*) Cnt from [dbo].[VW_Flowring_View_HR_Department] WITH(NOLOCK) ";
            string strDeptTblCnt = daoDocpediaSelect.SqlSelectToString(sqlQuery, "Cnt");
            int.TryParse(strDeptTblCnt, out DeptTblCnt);
            if (DeptTblCnt <= intDeptNomlCnt)//組織數過少
            {
                sbMsg.Append(strErrTip + "view [VW_Flowring_View_HR_Department] no data ! ");
                //daoDocpediaSelect.SqlConn.Close();
                return isSuccess;
            }

            #endregion 1.1 確認 Flowring_View_HR_Department 筆數 >正常組織數

            #region 1.2 確認 Flowring_View_HR_Employee 筆數 > >正常人事數

            int EmpTblCnt = 0;
            sqlQuery = @" select count(*) Cnt from [dbo].[VW_Flowring_View_HR_Employee] WITH(NOLOCK) ";
            string strEmpTblCnt = daoDocpediaSelect.SqlSelectToString(sqlQuery, "Cnt");
            int.TryParse(strEmpTblCnt, out EmpTblCnt);
            if (EmpTblCnt <= intEmpNomlCnt)//員工人數過低
            {
                sbMsg.Append(strErrTip + "view [VW_Flowring_View_HR_Employee] no data ! ");
                //daoDocpediaSelect.SqlConn.Close();
                return isSuccess;
            }

            #endregion 1.2 確認 Flowring_View_HR_Employee 筆數 > >正常人事數

            #endregion 一、. 確認組織/人事檢視表是否有資料，若有才繼續執行

            #region 二、執行 temp table

            #region 2.1 CHPT 將組織、人事資料從檢視表複製到資料表

            strSQL = "";
            strSQL = @"
                    truncate table [{0}].[dbo].[Flowring_View_HR_Department];
                    truncate table [{0}].[dbo].[Flowring_View_HR_Employee];

                    INSERT INTO [{0}].[dbo].[Flowring_View_HR_Department]
                    SELECT * FROM [{0}].[dbo].[VW_Flowring_View_HR_Department] WITH(NOLOCK) ;

                    INSERT INTO [{0}].[dbo].[Flowring_View_HR_Employee]
                    SELECT * FROM [{0}].[dbo].[VW_Flowring_View_HR_Employee] WITH(NOLOCK);
            ";
            strSQL = string.Format(strSQL, strDocpediaDBName);//取代資料庫名稱
            //bUpdateSQL = dao.SqlInsert(strSQL, ref sbErr);
            daoDocpediaSelect.SqlConn.Open();
            bUpdateSQL = daoDocpediaSelect.SqlInsert(strSQL, ref sbErr);
            daoDocpediaSelect.SqlConn.Close();
            if (bUpdateSQL == false)
            {
                sbMsg.Append(strErrTip + sbErr.ToString() + strSQL);
                //daoERPSelect.SqlConn.Close();
                return isSuccess;
            }

            #endregion 2.1 CHPT 將組織、人事資料從檢視表複製到資料表

            #region 2.2 塞資料到 temp table

            strSQL = "";

            #region del code

            //          strSQL = @"

            //	IF OBJECT_ID('[{0}].[dbo].BK_COMPANY') IS NOT NULL
            //drop table [{0}].[dbo].BK_COMPANY

            //IF OBJECT_ID('[{0}].[dbo].BK_DEP_GENINF') IS NOT NULL
            //drop table [{0}].[dbo].BK_DEP_GENINF

            //IF OBJECT_ID('[{0}].[dbo].BK_MEM_GENINF') IS NOT NULL
            //drop table [{0}].[dbo].BK_MEM_GENINF

            //IF OBJECT_ID('[{0}].[dbo].BK_ROL_GENINF') IS NOT NULL
            //drop table [{0}].[dbo].BK_ROL_GENINF

            //IF OBJECT_ID('[{0}].[dbo].BK_ROL_MEM') IS NOT NULL
            //drop table [{0}].[dbo].BK_ROL_MEM

            //IF OBJECT_ID('[{0}].[dbo].TMP_COMPANY') IS NOT NULL
            //drop table [{0}].[dbo].TMP_COMPANY

            //IF OBJECT_ID('[{0}].[dbo].TMP_DEP_GENINF') IS NOT NULL
            //drop table [{0}].[dbo].TMP_DEP_GENINF

            //IF OBJECT_ID('[{0}].[dbo].TMP_MEM_GENINF') IS NOT NULL
            //drop table [{0}].[dbo].TMP_MEM_GENINF

            //IF OBJECT_ID('[{0}].[dbo].TMP_ROL_GENINF') IS NOT NULL
            //drop table [{0}].[dbo].TMP_ROL_GENINF

            //IF OBJECT_ID('[{0}].[dbo].TMP_ROL_MEM') IS NOT NULL
            //drop table [{0}].[dbo].TMP_ROL_MEM

            //IF OBJECT_ID('[{0}].[dbo].CHK_COMPANY') IS NOT NULL
            //drop table [{0}].[dbo].CHK_COMPANY

            //IF OBJECT_ID('[{0}].[dbo].CHK_DEP_GENINF') IS NOT NULL
            //drop table [{0}].[dbo].CHK_DEP_GENINF

            //IF OBJECT_ID('[{0}].[dbo].CHK_MEM_GENINF') IS NOT NULL
            //drop table [{0}].[dbo].CHK_MEM_GENINF

            //IF OBJECT_ID('[{0}].[dbo].CHK_ROL_GENINF') IS NOT NULL
            //drop table [{0}].[dbo].CHK_ROL_GENINF

            //IF OBJECT_ID('[{0}].[dbo].CHK_ROL_MEM') IS NOT NULL
            //drop table [{0}].[dbo].CHK_ROL_MEM

            //SELECT * INTO [{0}].[dbo].BK_COMPANY FROM [{0}].[dbo].COMPANY
            //SELECT * INTO [{0}].[dbo].BK_DEP_GENINF FROM [{0}].[dbo].DEP_GENINF
            //SELECT * INTO [{0}].[dbo].BK_MEM_GENINF FROM [{0}].[dbo].MEM_GENINF
            //SELECT * INTO [{0}].[dbo].BK_ROL_GENINF FROM [{0}].[dbo].ROL_GENINF
            //SELECT * INTO [{0}].[dbo].BK_ROL_MEM FROM [{0}].[dbo].ROL_MEM

            //SELECT * INTO [{0}].[dbo].TMP_COMPANY FROM [{0}].[dbo].COMPANY WHERE '1' > '1'
            //SELECT * INTO [{0}].[dbo].TMP_DEP_GENINF FROM [{0}].[dbo].DEP_GENINF WHERE '1' > '1'
            //SELECT * INTO [{0}].[dbo].TMP_MEM_GENINF FROM [{0}].[dbo].MEM_GENINF WHERE '1' > '1'
            //SELECT * INTO [{0}].[dbo].TMP_ROL_GENINF FROM [{0}].[dbo].ROL_GENINF WHERE '1' > '1'
            //SELECT * INTO [{0}].[dbo].TMP_ROL_MEM FROM [{0}].[dbo].ROL_MEM WHERE '1' > '1'

            //SELECT * INTO [{0}].[dbo].CHK_COMPANY FROM [{0}].[dbo].COMPANY
            //SELECT * INTO [{0}].[dbo].CHK_DEP_GENINF FROM [{0}].[dbo].DEP_GENINF
            //SELECT * INTO [{0}].[dbo].CHK_MEM_GENINF FROM [{0}].[dbo].MEM_GENINF
            //SELECT * INTO [{0}].[dbo].CHK_ROL_GENINF FROM [{0}].[dbo].ROL_GENINF
            //SELECT * INTO [{0}].[dbo].CHK_ROL_MEM FROM [{0}].[dbo].ROL_MEM

            //IF OBJECT_ID('[{0}].[dbo].Temp_1_COMPANY') IS NOT NULL
            //DROP TABLE [{0}].[dbo].Temp_1_COMPANY

            //IF OBJECT_ID('[{0}].[dbo].Temp_1_Dep_GenInf') IS NOT NULL
            //DROP TABLE [{0}].[dbo].Temp_1_Dep_GenInf

            //IF OBJECT_ID('[{0}].[dbo].Temp_1_Rol_GenInf') IS NOT NULL
            //DROP TABLE [{0}].[dbo].Temp_1_Rol_GenInf

            //IF OBJECT_ID('[{0}].[dbo].Temp_1_Mem_GenInf') IS NOT NULL
            //DROP TABLE [{0}].[dbo].Temp_1_Mem_GenInf

            //IF OBJECT_ID('[{0}].[dbo].Temp_1_Rol_Mem') IS NOT NULL
            //DROP TABLE [{0}].[dbo].Temp_1_Rol_Mem

            //SELECT * INTO [{0}].[dbo].Temp_1_COMPANY FROM [{0}].[dbo].COMPANY
            //SELECT * INTO [{0}].[dbo].Temp_1_Dep_GenInf FROM [{0}].[dbo].Dep_GenInf
            //SELECT * INTO [{0}].[dbo].Temp_1_Rol_GenInf FROM [{0}].[dbo].Rol_GenInf
            //SELECT * INTO [{0}].[dbo].Temp_1_Mem_GenInf FROM [{0}].[dbo].Mem_GenInf
            //SELECT * INTO [{0}].[dbo].Temp_1_Rol_Mem FROM [{0}].[dbo].Rol_Mem
            //--處理來源資料異常問題
            //UPDATE [{0}].[dbo].Flowring_View_HR_Department SET UpperDepartmentID = 'company' where UpperDepartmentID = ''

            //--新增集團公司
            //INSERT INTO [{0}].[dbo].TMP_COMPANY (NAME,COMID,PARENTID,MANAGERID,SIBLINGORDER,UNITID,SYNOPSIS,ID)
            //values ('中華精測科技股份有限公司','company','company','','1',null,'','WL01')

            //--塞入 歷史部門
            //INSERT INTO [{0}].[dbo].TMP_DEP_GENINF (DepID,  Name, ManagerID, Respon,Synopsis,ParentID, ID,SiblingOrder)
            //values ('DEPC_company_History','歷史部門','','','','company','company_History','999999')

            //--塞入 離職人員職務
            //INSERT INTO [{0}].[dbo].TMP_ROL_GENINF(RolID, Name, DepID, ID, Synopsis, SiblingOrder,SignLevel)
            //values ('ROLC_company_History','離職人員','DEPC_company_History','','','999999','0')

            //--新增子公司

            //--新增 第一層 部門
            //INSERT INTO [{0}].[dbo].TMP_DEP_GENINF (DepID,  Name, ManagerID, Respon,Synopsis,ParentID, ID,SiblingOrder)
            //(SELECT
            //'DEPC_'+CompanyID+'_'+DepartmentID as DepID,
            //DepartmentName as Name,
            //'ROLC_'+CompanyID+'_'+DepartmentID+'_M' as ManagerID,
            //'||SIGN_LEVEL='+ CONVERT(varchar, SignLevel) + ';' as Respon,'||CountryCode='+CountryCode+';||COST_ID='+CostCenterID+';||CORPORATION_ID='+CompanyID+';||CORPORATION='+CompanyName+';' as Synopsis,
            //'company' as ParentID,DepartmentID as ID ,
            //3+ROW_NUMBER() OVER (ORDER BY CompanyID) AS SiblingOrder
            //FROM [{0}].[dbo].Flowring_View_HR_Department
            //WHERE UpperDepartmentID = 'company')

            //--塞入 第一層主管職務
            //INSERT INTO [{0}].[dbo].TMP_ROL_GENINF(RolID, Name, DepID, ID, Synopsis, SiblingOrder,SignLevel)
            //(SELECT
            //'ROLC_'+CompanyID+'_'+DepartmentID+'_M' as RolID,
            //DepartmentName +'_主管' as Name,
            //'DEPC_'+CompanyID+'_'+DepartmentID as DepID,
            //'' as ID,'' as Synopsis,'1' as SiblingOrder,SignLevel as SignLevel
            //FROM [{0}].[dbo].Flowring_View_HR_Department
            //WHERE UpperDepartmentID = 'company')

            //--塞入 第一層同仁職務
            //INSERT INTO [{0}].[dbo].TMP_ROL_GENINF(RolID, Name, DepID, ID, Synopsis, SiblingOrder,SignLevel)
            //(SELECT
            //'ROLC_'+CompanyID+'_'+DepartmentID+'_S' as RolID,
            //DepartmentName +'_同仁' as Name,
            //'DEPC_'+CompanyID+'_'+DepartmentID as DepID,
            //'' as ID,'' as Synopsis,'2' as SiblingOrder,'0' as SignLevel
            //FROM [{0}].[dbo].Flowring_View_HR_Department
            //WHERE UpperDepartmentID = 'company')

            //--新增部門
            //INSERT INTO [{0}].[dbo].TMP_DEP_GENINF (DepID,  Name, ManagerID, Respon,Synopsis,ParentID, ID,SiblingOrder)
            //(
            //SELECT
            //'DEPC_'+CompanyID+'_'+DepartmentID COLLATE Chinese_Taiwan_Stroke_CI_AS as DepID,
            //DepartmentName as Name,
            //'ROLC_'+CompanyID+'_'+DepartmentID+'_M' COLLATE Chinese_Taiwan_Stroke_CI_AS as ManagerID,
            //'||SIGN_LEVEL='+ CONVERT(varchar, SignLevel) + ';' COLLATE Chinese_Taiwan_Stroke_CI_AS as Respon,
            //'||CountryCode='+CountryCode+';||COST_ID='+CostCenterID+';||CORPORATION_ID='+CompanyID+';||CORPORATION='+CompanyName+';'  COLLATE Chinese_Taiwan_Stroke_CI_AS as Synopsis,
            //'DEPC_'+CompanyID+'_'+UpperDepartmentID  COLLATE Chinese_Taiwan_Stroke_CI_AS as ParentID,
            //DepartmentID as ID,
            //3 + ROW_NUMBER() OVER (ORDER BY CountryCode+DepartmentID COLLATE Chinese_Taiwan_Stroke_CI_AS) AS SiblingOrder
            //FROM [{0}].[dbo].Flowring_View_HR_Department
            //WHERE UpperDepartmentID <> 'company'
            //)

            //--塞入 主管職務
            //INSERT INTO [{0}].[dbo].TMP_ROL_GENINF(RolID, Name, DepID, ID, Synopsis, SiblingOrder,SignLevel)
            //(SELECT
            //'ROLC_'+CompanyID+'_'+DepartmentID+'_M' COLLATE Chinese_Taiwan_Stroke_CI_AS as RolID,
            //DepartmentName +'_主管'  as Name,
            //'DEPC_'+CompanyID+'_'+DepartmentID COLLATE Chinese_Taiwan_Stroke_CI_AS as DepID,
            //'' as ID,
            //'' as Synopsis,
            //'1' as SiblingOrder,
            //SignLevel  as SignLevel
            //FROM [{0}].[dbo].Flowring_View_HR_Department
            //WHERE UpperDepartmentID <> 'company')

            //--塞入 員工職務
            //INSERT INTO [{0}].[dbo].TMP_ROL_GENINF(RolID, Name, DepID, ID, Synopsis, SiblingOrder,SignLevel)
            //(SELECT
            //'ROLC_'+CompanyID+'_'+DepartmentID+'_S' COLLATE Chinese_Taiwan_Stroke_CI_AS as RolID,
            //DepartmentName +'_同仁' as Name,
            //'DEPC_'+CompanyID+'_'+DepartmentID COLLATE Chinese_Taiwan_Stroke_CI_AS as DepID,
            //'' as ID,'' as Synopsis,
            //'2' as SiblingOrder,
            //'0' as SignLevel
            //FROM [{0}].[dbo].Flowring_View_HR_Department WHERE UpperDepartmentID <> 'company')

            //--塞入主管
            //INSERT INTO [{0}].[dbo].TMP_MEM_GENINF
            //(MemID,LoginID,ID,SiblingOrder,UserName,EnglishName,MainRoleID,Gender,EMail,Mobilephone,Birthday,
            //JobTitle,JobRank,JobLevel,JobOnBoardDate,OnBoardDate,ResignDate,DeniedLogin,Resign,Invisible,AttMap,
            //Password, Synopsis, WorkPlace, AreaCode, HomePhone, OfficePhone, Address)
            //(SELECT
            //'MEMC_'+EmployeeID as MemID,
            //loginID as LoginID,
            //loginID as ID,
            //'0' as SiblingOrder,
            //EmployeeName  as UserName,
            //EmployeeEnglishName as EnglishName,
            //'ROLC_' + CompanyID+'_'+DepartmentID + '_M' COLLATE Chinese_Taiwan_Stroke_CI_AS as MainRoleID,
            //Sex as Gender,
            //Email as EMail,
            //Mobile as Mobilephone,
            //CONVERT(CHAR(10), Birthday, 111) as Birthday,
            //JobTitleName as JobTitle,JobRank as JobRank,
            //JobGrade as JobLevel,
            //CONVERT(CHAR(10), EnterDate, 111) as JobOnBoardDate,
            //'' as OnBoardDate,
            //CONVERT(CHAR(10), LeaveDate, 111) as ResignDate,
            //'false' as DeniedLogin,
            //'false' as Resign,
            //'false' as Invisible,
            //'rO0ABXNyABFqYXZhLnV0aWwuSGFzaE1hcAUH2sHDFmDRAwACRgAKbG9hZEZhY3RvckkACXRocmVzaG9sZHhwP0AAAAAAAAx3CAAAABAAAAAAeA==' as AttMap,
            //'gdyb21LQTcIANtvYMT7QVQ==' as Password,
            //'||JobType='+JobType+';||JobCode='+JobCode+';||JobTitleCode='+JobTitleCode+';' COLLATE Chinese_Taiwan_Stroke_CI_AS  as Synopsis,
            //WorkPlace, AreaCode, HomePhone, OfficePhone, Address
            //FROM [{0}].[dbo].Flowring_View_HR_Employee
            //where CompanyID+DepartmentID+EmployeeID in (
            //SELECT CompanyID+DepartmentID+DeptManagerID COLLATE Chinese_Taiwan_Stroke_CI_AS
            //FROM [{0}].[dbo].Flowring_View_HR_Department
            //))

            //--塞入員工
            //INSERT INTO [{0}].[dbo].TMP_MEM_GENINF
            //(MemID,LoginID,ID,SiblingOrder,UserName,EnglishName,MainRoleID,Gender,EMail,Mobilephone,Birthday,JobTitle,JobRank,JobLevel,JobOnBoardDate,OnBoardDate,ResignDate,DeniedLogin,Resign,Invisible,AttMap,Password, Synopsis, WorkPlace, AreaCode, HomePhone, OfficePhone, Address)
            //(SELECT
            //'MEMC_'+EmployeeID  COLLATE Chinese_Taiwan_Stroke_CI_AS as MemID,
            //loginID as LoginID,
            //loginID as ID,'0' as SiblingOrder,
            //EmployeeName  as UserName,
            //EmployeeEnglishName as EnglishName,
            //'ROLC_' + CompanyID+'_'+DepartmentID + '_S' COLLATE Chinese_Taiwan_Stroke_CI_AS as MainRoleID,
            //Sex as Gender,Email as EMail,Mobile as Mobilephone,
            //CONVERT(CHAR(10), Birthday, 111) as Birthday,
            //JobTitleName as JobTitle,
            //JobRank as JobRank,
            //JobGrade as JobLevel,
            //CONVERT(CHAR(10), EnterDate, 111) as JobOnBoardDate, '' as OnBoardDate,
            //CONVERT(CHAR(10), LeaveDate, 111) as ResignDate,
            //'false' as DeniedLogin,'false' as Resign,'false' as Invisible,
            //'rO0ABXNyABFqYXZhLnV0aWwuSGFzaE1hcAUH2sHDFmDRAwACRgAKbG9hZEZhY3RvckkACXRocmVzaG9sZHhwP0AAAAAAAAx3CAAAABAAAAAAeA==' as AttMap,
            //'gdyb21LQTcIANtvYMT7QVQ==' as Password, '||JobType='+JobType+';||JobCode='+JobCode+';||JobTitleCode='+JobTitleCode+';' COLLATE Chinese_Taiwan_Stroke_CI_AS as Synopsis,
            //WorkPlace, AreaCode, HomePhone, OfficePhone, Address
            //FROM [{0}].[dbo].Flowring_View_HR_Employee
            //where 'MEMC_'+EmployeeID COLLATE Chinese_Taiwan_Stroke_CI_AS not in (
            //SELECT MemID FROM [{0}].[dbo].TMP_MEM_GENINF
            //))

            //--更新性別
            //update [{0}].[dbo].TMP_MEM_GENINF set Gender = 'true' where Gender = 'M'
            //update [{0}].[dbo].TMP_MEM_GENINF set Gender = 'false' where Gender <> 'true'

            //--更新登入帳號
            //--UPDATE [{0}].[dbo].TMP_MEM_GENINF SET loginID =  substring(EMail,0,CHARINDEX('@', EMail)) where EMail <> ''

            //--新增職務與人員對應資料
            //INSERT INTO [{0}].[dbo].TMP_ROL_MEM (RolID, MemID)
            //(SELECT MainRoleID,MemID
            //From [{0}].[dbo].TMP_MEM_GENINF where MemID like 'MEMC_%')

            //INSERT INTO [{0}].[dbo].TMP_ROL_MEM (RolID, MemID)
            //(SELECT 'ROLC_'+CompanyID+'_'+DepartmentID+'_M','MEMC_'+DeptManagerID
            //From [{0}].[dbo].Flowring_View_HR_Department where DeptManagerID <> '' )

            //--//自訂屬性預設值
            //UPDATE  [{0}].[dbo].TMP_Mem_GenInf
            //SET AttMap = 'rO0ABXNyABFqYXZhLnV0aWwuSGFzaE1hcAUH2sHDFmDRAwACRgAKbG9hZEZhY3RvckkACXRocmVzaG9sZHhwP0AAAAAAAAx3CAAAABAAAAAAeA=='
            //WHERE AttMap is NULL

            //--取回AF 自訂屬性預設值 資料
            //update [{0}].[dbo].TMP_Mem_GenInf
            //set AttMap = a.AttMap
            //From [{0}].[dbo].Mem_GenInf a,
            //[{0}].[dbo].TMP_Mem_GenInf b
            //where a.MemID=b.MemID and a.AttMap is not NULL

            //--取回AF 電子簽章 資料
            //update [{0}].[dbo].TMP_Mem_GenInf
            //set Signature = a.Signature
            //From [{0}].[dbo].Mem_GenInf a,
            //[{0}].[dbo].TMP_Mem_GenInf b
            //where a.MemID=b.MemID and a.Signature is not NULL

            //--取回AF 密碼 資料
            //update [{0}].[dbo].TMP_Mem_GenInf
            //set Password = a.Password
            //From [{0}].[dbo].Mem_GenInf a,[{0}].[dbo].TMP_Mem_GenInf b
            //where a.MemID=b.MemID

            //--歷史部門處理 -CHK_DEP_GENINF
            //UPDATE [{0}].[dbo].CHK_DEP_GENINF
            //SET ParentID = 'DEPC_company_History'
            //WHERE ParentID LIKE 'DEPC_%' AND DepID NOT IN (SELECT DepID FROM [{0}].[dbo].TMP_DEP_GENINF)

            //--離職人員處理 -CHK_MEM_GENINF
            //UPDATE [{0}].[dbo].CHK_MEM_GENINF
            //set
            //MainRoleID = 'ROLC_company_History',
            //DeniedLogin = 'true',
            //Resign = 'true',
            //Invisible = 'true'
            //WHERE MemID like 'MEMC%' AND MemID NOT IN (SELECT MemID FROM [{0}].[dbo].TMP_MEM_GENINF)

            //--DELETE CHK_ROL_MEM where MemID in (SELECT MemID FROM CHK_MEM_GENINF WHERE MainRoleID = 'ROLC_company_History')
            //INSERT INTO [{0}].[dbo].TMP_ROL_MEM (RolID, MemID)
            //(SELECT MainRoleID,MemID
            //From [{0}].[dbo].CHK_MEM_GENINF
            //where MainRoleID = 'ROLC_company_History')

            //--沒有來源資料 補回TMP
            //INSERT INTO [{0}].[dbo].TMP_DEP_GENINF
            //SELECT *
            //FROM [{0}].[dbo].CHK_DEP_GENINF WHERE DepID NOT IN (SELECT DepID FROM [{0}].[dbo].TMP_DEP_GENINF)

            //INSERT INTO [{0}].[dbo].TMP_ROL_GENINF
            //SELECT *
            //FROM [{0}].[dbo].CHK_ROL_GENINF WHERE ROLID NOT IN (SELECT ROLID FROM [{0}].[dbo].TMP_ROL_GENINF)

            //INSERT INTO [{0}].[dbo].TMP_MEM_GENINF
            //SELECT * FROM [{0}].[dbo].CHK_MEM_GENINF
            //WHERE MemID NOT IN (SELECT MemID FROM [{0}].[dbo].TMP_MEM_GENINF)
            //--INSERT INTO TMP_ROL_MEM SELECT * FROM CHK_ROL_MEM WHERE RolID+MemID NOT IN (SELECT RolID+MemID FROM TMP_ROL_MEM)

            //--沒有上層部門的部門 移到離職部門
            //UPDATE [{0}].[dbo].TMP_DEP_GENINF
            //SET ParentID = substring(DEPID,0,CHARINDEX('_', DEPID,6))+'_History'
            //WHERE (ParentID LIKE 'DEPC_%') AND (ParentID NOT IN (SELECT DepID FROM [{0}].[dbo].TMP_DEP_GENINF AS TMP_DEP_GENINF_1))

            //--移除異常資料
            //DELETE [{0}].[dbo].TMP_ROL_MEM WHERE MEMID NOT IN (SELECT MemID FROM [{0}].[dbo].TMP_MEM_GENINF)
            //DELETE [{0}].[dbo].TMP_ROL_MEM WHERE ROLID NOT IN (SELECT RolID FROM [{0}].[dbo].TMP_ROL_GENINF)

            //--移除重複對應值 -TMP_ROL_MEM
            //select distinct * into [{0}].[dbo].TMP_BK_ROL_MEM from [{0}].[dbo].TMP_ROL_MEM
            //drop table [{0}].[dbo].TMP_ROL_MEM
            //select * into [{0}].[dbo].TMP_ROL_MEM from [{0}].[dbo].TMP_BK_ROL_MEM
            //drop table [{0}].[dbo].TMP_BK_ROL_MEM

            //--沒有未抓到主管直接設為上層主管
            //UPDATE [{0}].[dbo].Tmp_Dep_GenInf SET ManagerID = '' WHERE ManagerID not in (SELECT DISTINCT rolID FROM [{0}].[dbo].Tmp_Rol_Mem)
            //          ";

            #endregion del code

            //strSQL = "exec [{0}].[dbo].sp_CreateOrgTemp";
            //strSQL = string.Format(strSQL, strDocpediaDBName);//取代資料庫名稱
            //bUpdateSQL = dao.SqlInsert(strSQL, ref sbErr);
            //if (bUpdateSQL == false)
            //{
            //    sbMsg.Append(strErrTip + sbErr.ToString() + strSQL);
            //    //daoERPSelect.SqlConn.Close();
            //    return isSuccess;
            //}

            #endregion 2.2 塞資料到 temp table

            #endregion 二、執行 temp table

            //daoERPSelect.SqlConn.Close();
            //daoDocpediaSelect.SqlConn.Close();

            isSuccess = true;
            return isSuccess;
        }

        #endregion Temp Table 處理

        #region 轉入正式 Table

        public bool Insert2Docpedia(ERP.DBDao dao, ref System.Text.StringBuilder sbMsg)
        {
            bool isSuccess = false;
            StringBuilder sbErr = new StringBuilder();
            string strErrTip = "華苓文管系統組織匯入失敗，錯誤原因：";
            string sqlQuery = "";
            int TempTblCnt = 0;
            string strTblCnt = "";
            string strSQL = "";
            bool bUpdateSQL = false;

            #region 資料庫連線

            ERP.DBDao daoERPSelect = new ERP.DBDao(ERPConnStr);
            //daoERPSelect.SqlConn.Open();

            ERP.DBDao daoDocpediaSelect = new ERP.DBDao(DocpediaConnStr);
            //daoDocpediaSelect.SqlConn.Open();

            #endregion 資料庫連線

            #region 一、確認 temp table 是不是有資料，若有才繼續執行

            #region 1.1 確認 Tmp_COMPANY 筆數

            sqlQuery = @" select count(*) Cnt from [dbo].[TMP_COMPANY] WITH(NOLOCK) ";
            strTblCnt = daoDocpediaSelect.SqlSelectToString(sqlQuery, "Cnt");//, ref sbMsg
            int.TryParse(strTblCnt, out TempTblCnt);
            if (TempTblCnt <= 0)
            {
                sbMsg.Append(strErrTip + "temp table [TMP_COMPANY] no data ! ");
                //daoDocpediaSelect.SqlConn.Close();
                return isSuccess;
            }

            #endregion 1.1 確認 Tmp_COMPANY 筆數

            #region 1.2 確認 TMP_DEP_GENINF 筆數

            sqlQuery = @" select count(*) Cnt from [dbo].[TMP_DEP_GENINF] WITH(NOLOCK) ";
            strTblCnt = daoDocpediaSelect.SqlSelectToString(sqlQuery, "Cnt");
            int.TryParse(strTblCnt, out TempTblCnt);
            if (TempTblCnt <= 0)
            {
                sbMsg.Append(strErrTip + "temp table [TMP_DEP_GENINF] no data ! ");
                //daoDocpediaSelect.SqlConn.Close();
                return isSuccess;
            }

            #endregion 1.2 確認 TMP_DEP_GENINF 筆數

            #region 1.3 確認 TMP_ROL_GENINF 筆數

            sqlQuery = @" select count(*) Cnt from [dbo].[TMP_ROL_GENINF] WITH(NOLOCK) ";
            strTblCnt = daoDocpediaSelect.SqlSelectToString(sqlQuery, "Cnt");
            int.TryParse(strTblCnt, out TempTblCnt);
            if (TempTblCnt <= 0)
            {
                sbMsg.Append(strErrTip + "temp table [TMP_ROL_GENINF] no data ! ");
                //daoDocpediaSelect.SqlConn.Close();
                return isSuccess;
            }

            #endregion 1.3 確認 TMP_ROL_GENINF 筆數

            #region 1.4 確認 TMP_MEM_GENINF 筆數

            sqlQuery = @" select count(*) Cnt from [dbo].[TMP_MEM_GENINF] WITH(NOLOCK) ";
            strTblCnt = daoDocpediaSelect.SqlSelectToString(sqlQuery, "Cnt");
            int.TryParse(strTblCnt, out TempTblCnt);
            if (TempTblCnt <= 0)
            {
                sbMsg.Append(strErrTip + "temp table [TMP_MEM_GENINF] no data ! ");
                //daoDocpediaSelect.SqlConn.Close();
                return isSuccess;
            }

            #endregion 1.4 確認 TMP_MEM_GENINF 筆數

            #region 1.5 確認 TMP_ROL_MEM 筆數

            sqlQuery = @" select count(*) Cnt from [dbo].[TMP_ROL_MEM] WITH(NOLOCK) ";
            strTblCnt = daoDocpediaSelect.SqlSelectToString(sqlQuery, "Cnt");
            int.TryParse(strTblCnt, out TempTblCnt);
            if (TempTblCnt <= 0)
            {
                sbMsg.Append(strErrTip + "temp table [TMP_ROL_MEM] no data ! ");
                //daoDocpediaSelect.SqlConn.Close();
                return isSuccess;
            }

            #endregion 1.5 確認 TMP_ROL_MEM 筆數

            #endregion 一、確認 temp table 是不是有資料，若有才繼續執行

            #region 二、執行轉正式區

            #region 2.1 CHPT 將組織、人事資料從檢視表複製到資料表

            strSQL = "";
            strSQL = " exec [{0}].[dbo].sp_CreateOrg ";
            strSQL = string.Format(strSQL, strDocpediaDBName);//取代資料庫名稱
            //bUpdateSQL = dao.SqlInsert(strSQL, ref sbErr);
            daoDocpediaSelect.SqlConn.Open();
            bUpdateSQL = daoDocpediaSelect.SqlInsert(strSQL, ref sbErr);
            daoDocpediaSelect.SqlConn.Close();
            if (bUpdateSQL == false)
            {
                sbMsg.Append(strErrTip + sbErr.ToString() + strSQL);
                //daoERPSelect.SqlConn.Close();
                return isSuccess;
            }

            #endregion 2.1 CHPT 將組織、人事資料從檢視表複製到資料表

            #endregion 二、執行轉正式區

            //daoERPSelect.SqlConn.Close();
            //daoDocpediaSelect.SqlConn.Close();

            isSuccess = true;
            return isSuccess;
        }

        #endregion 轉入正式 Table

        public bool Update2Docpedia(ERP.DBDao dao, ref System.Text.StringBuilder sbMsg)
        {
            bool isSuccess = false;
            StringBuilder sbErr = new StringBuilder();
            string strErrTip = "華苓文管系統組織匯入失敗 Part 2，錯誤原因：";
            string strSQL = "";
            bool bUpdateSQL = false;

            #region 資料庫連線

            ERP.DBDao daoDocpediaSelect = new ERP.DBDao(DocpediaConnStr);

            strSQL = "";
            strSQL = " exec [{0}].[dbo].[sp_CreateOrgTemp];exec [{0}].[dbo].[sp_CreateOrg]; ";

            strSQL = string.Format(strSQL, strDocpediaDBName);//取代資料庫名稱
            //bUpdateSQL = dao.SqlInsert(strSQL, ref sbErr);
            daoDocpediaSelect.SqlConn.Open();
            bUpdateSQL = daoDocpediaSelect.SqlInsert(strSQL, ref sbErr);
            daoDocpediaSelect.SqlConn.Close();
            if (bUpdateSQL == false)
            {
                sbMsg.Append(strErrTip + sbErr.ToString() + strSQL);
                //daoERPSelect.SqlConn.Close();
                return isSuccess;
            }

            #endregion

            isSuccess = true;
            return isSuccess;
        }

        #region delete code

        //public bool Insert2Docpedia1(ERP.DBDao dao, ref System.Text.StringBuilder sbMsg)
        //{
        //    string ERPConnStr = "User Id=CHPTMIS;database=CHPT_Tab_0724;server=192.168.1.140;Connect Timeout=5;Password=00000";

        //    bool isSuccess = false;

        //    ERP.DBDao daoERPSelect = new ERP.DBDao(ERPConnStr);
        //    daoERPSelect.SqlConn.Open();

        //    string sqlQuery = @"
        //select top 10 * from [dbo].[Dept] where DeptNo like @DeptNo
        //       ";
        //    daoERPSelect.SqlCommand.Parameters.Clear();
        //    daoERPSelect.SqlCommand.Parameters.AddWithValue("@DeptNo", string.Format("%{0}%", "AD"));
        //    //dao.SqlCommand.Parameters.AddWithValue("@DeptNo", string.Format("{0}", "AD-3500"));

        //    StringBuilder sb = new StringBuilder();
        //    System.Data.DataTable dtSQLListSetting = daoERPSelect.SqlSelect(sqlQuery, ref sb);

        //    if (sb.ToString() != "")
        //    {
        //        sbMsg = sb;
        //        daoERPSelect.SqlConn.Close();
        //        return isSuccess;
        //    }

        //    foreach (DataRow dr in dtSQLListSetting.Rows)
        //    {
        //        string DeptNo = dr["DeptNo"].ToString();
        //        string DeptName = dr["DeptName"].ToString();
        //        string DeptEngName = dr["DeptEngName"].ToString();
        //        string DeptMgr = dr["DeptMgr"].ToString();
        //        string MgrAgent = dr["MgrAgent"].ToString();
        //        string UpperDeptNo = dr["UpperDeptNo"].ToString();
        //        string UpperMgr = dr["UpperMgr"].ToString();
        //        string DeptEXP = dr["DeptEXP"].ToString();
        //        string DeptEXPBelogTo = dr["DeptEXPBelogTo"].ToString();
        //        string DeptNoDisable = dr["DeptNoDisable"].ToString();
        //        string WFUpperDeptNo = dr["WFUpperDeptNo"].ToString();
        //        string Fa0epDeptNo = dr["Fa0epDeptNo"].ToString();
        //        string HR01M_ID = dr["HR01M_ID"].ToString();
        //        DateTime CreateDate = DateTime.Parse(dr["CreateDate"].ToString());
        //        string CreateUser = dr["CreateUser"].ToString();
        //        DateTime LstEdtDate = DateTime.Parse(dr["LstEdtDate"].ToString());
        //        string LstEdtUser = dr["LstEdtUser"].ToString();

        //        string strInsertDeptSQL = @"
        //                delete from [CHPT_Eva_0413].[dbo].[Dept]

        //                INSERT INTO [CHPT_Eva_0413].[dbo].[Dept]
        //                ([DeptNo] ,[DeptName] ,[DeptEngName] ,[DeptMgr] ,[MgrAgent]
        //                ,[UpperDeptNo] ,[UpperMgr] ,[DeptEXP] ,[DeptEXPBelogTo] ,[DeptNoDisable]
        //                ,[WFUpperDeptNo] ,[Fa0epDeptNo] ,[HR01M_ID] ,[CreateDate] ,[CreateUser]
        //                ,[LstEdtDate] ,[LstEdtUser])
        //                VALUES (@DeptNo ,@DeptName ,@DeptEngName ,@DeptMgr ,@MgrAgent
        //                ,@UpperDeptNo ,@UpperMgr ,@DeptEXP ,@DeptEXPBelogTo ,@DeptNoDisable
        //                ,@WFUpperDeptNo ,@Fa0epDeptNo ,@HR01M_ID ,@CreateDate ,@CreateUser ,@LstEdtDate ,@LstEdtUser)
        //               ";

        //        dao.SqlCommand.Parameters.Clear();
        //        dao.SqlCommand.Parameters.AddWithValue("@DeptNo", DeptNo);
        //        dao.SqlCommand.Parameters.AddWithValue("@DeptName", DeptName);
        //        dao.SqlCommand.Parameters.AddWithValue("@DeptEngName", DeptEngName);
        //        dao.SqlCommand.Parameters.AddWithValue("@DeptMgr", DeptMgr);
        //        dao.SqlCommand.Parameters.AddWithValue("@MgrAgent", MgrAgent);
        //        dao.SqlCommand.Parameters.AddWithValue("@UpperDeptNo", UpperDeptNo);
        //        dao.SqlCommand.Parameters.AddWithValue("@UpperMgr", UpperMgr);
        //        dao.SqlCommand.Parameters.AddWithValue("@DeptEXP", DeptEXP);
        //        dao.SqlCommand.Parameters.AddWithValue("@DeptEXPBelogTo", DeptEXPBelogTo);
        //        dao.SqlCommand.Parameters.AddWithValue("@DeptNoDisable", DeptNoDisable);
        //        dao.SqlCommand.Parameters.AddWithValue("@WFUpperDeptNo", WFUpperDeptNo);
        //        dao.SqlCommand.Parameters.AddWithValue("@Fa0epDeptNo", Fa0epDeptNo);
        //        dao.SqlCommand.Parameters.AddWithValue("@HR01M_ID", HR01M_ID);
        //        dao.SqlCommand.Parameters.AddWithValue("@CreateDate", CreateDate);
        //        dao.SqlCommand.Parameters.AddWithValue("@CreateUser", CreateUser);
        //        dao.SqlCommand.Parameters.AddWithValue("@LstEdtDate", LstEdtDate);
        //        dao.SqlCommand.Parameters.AddWithValue("@LstEdtUser", LstEdtUser);

        //        bool bInsertDeptSQL = dao.SqlInsert(strInsertDeptSQL, ref sb);
        //        if (bInsertDeptSQL == false)
        //        {
        //            sbMsg = sb;
        //            daoERPSelect.SqlConn.Close();
        //            return isSuccess;
        //        }
        //    }

        //    daoERPSelect.SqlConn.Close();

        //    //dao.SqlInsert();
        //    //dao.SqlUpdate();
        //    //dao.SqlDelete();

        //    isSuccess = true;
        //    return isSuccess;
        //}

        #endregion delete code
    }
    }