﻿using System;
using System.Data;

/// <summary>
/// AutoUpdateDsProjectFinishedDate 的摘要描述
/// </summary>
public class AutoUpdateDsProjectFinishedDate
{
    private string ERPConnStr = string.Format(System.Configuration.ConfigurationManager.ConnectionStrings["ConnectionString"].ToString(), "CHPT");

    public AutoUpdateDsProjectFinishedDate()
    {
        //
        // TODO: 在這裡新增建構函式邏輯
        //
    }

    public bool UpdateFinishedDateByStep(ERP.DBDao Dao_trans, ref System.Text.StringBuilder sbMsg)
    {
        ERP.DBDao daoERPSelect = new ERP.DBDao(ERPConnStr);
        bool isSuccess = true;
        string sql = "";

        try
        {
            sql = @"SELECT PDY2M.ProjectNo, PDY2M.PDY2Mid, PDY2M.PlanFinishedDate
                        FROM PDY2M (NOLOCK)
                        INNER JOIN PDY3S1A (NOLOCK) ON PDY2M.PDY2Mid = PDY3S1A.PDY2Mid AND ISNULL(PDY3S1A.RealFinishedDate, '') = '' AND PDY3S1A.PlanFinishedDate <= CONVERT(NVARCHAR, DATEADD(DAY, -1, GETDATE()), 111)
                        WHERE PDProjectStatus = '1' AND ProjectNo LIKE '20%' AND ProjectNo >= '2018010001' --AND ProjectNo IN ('2018090194', '2018090301', '2018100252', '2018110269')
                        GROUP BY PDY2M.ProjectNo, PDY2M.PDY2Mid, PDY2M.PlanFinishedDate";
            DataTable dtProject = daoERPSelect.SqlSelect(sql);
            foreach (DataRow drProject in dtProject.Rows)
            {
                string strProjectNo = drProject["ProjectNo"].ToString();
                string strPDY2Mid = drProject["PDY2Mid"].ToString();
                string strOldPlanFinishedDate = drProject["PlanFinishedDate"].ToString();

                #region 更新未完成站點 預計完成日

                #region 取得欲延期關卡

                sql = @"SELECT TOP(1) PDY3S1A.ID, PDY3S1A.DesignStepNo, PDY3S1A.RealFinishedDate, PDY3S1A.StdDesignWorkTime
                            FROM PDY3S1A (NOLOCK)
                            INNER JOIN PDY1S1A (NOLOCK) ON PDY3S1A.DesignStepNo = PDY1S1A.DesignStepNo
                            WHERE PDY3S1A.PDY2Mid = @PDY2Mid AND ISNULL(PDY3S1A.RealFinishedDate, '') = '' AND PDY3S1A.PlanFinishedDate <= CONVERT(NVARCHAR, DATEADD(DAY, -1, GETDATE()), 111)
                            ORDER BY PDY3S1A.DesignStepNo";
                daoERPSelect.SqlCommand.Parameters.Clear();
                daoERPSelect.SqlCommand.Parameters.AddWithValue("@PDY2Mid", strPDY2Mid);
                string strDelayDesignStepNo = daoERPSelect.SqlSelectToString(sql, "DesignStepNo");

                #endregion 取得欲延期關卡

                sql = @"SELECT ID, PDY3S1A.PDY2Mid, ReceiveDate, PDY3S1A.DesignStepNo, PDY2M.ReceiveDate, StdDesignWorkTime, PlanDoDateTime, PDY3S1A.PlanFinishedDate
                                FROM PDY3S1A (NOLOCK)
                                INNER JOIN PDY2M (NOLOCK) ON PDY3S1A.PDY2Mid = PDY2M.PDY2Mid
                                WHERE PDY3S1A.PDY2Mid = @PDY2Mid AND DesignStepNo >= @DesignStepNo
                                ORDER BY PDY3S1A.DesignStepNo";
                daoERPSelect.SqlCommand.Parameters.Clear();
                daoERPSelect.SqlCommand.Parameters.AddWithValue("@PDY2Mid", drProject["PDY2Mid"].ToString());
                daoERPSelect.SqlCommand.Parameters.AddWithValue("@DesignStepNo", strDelayDesignStepNo);
                DataTable dt_PDY3S1A = daoERPSelect.SqlSelect(sql);
                if (dt_PDY3S1A.Rows.Count > 0)
                {
                    DateTime ReceiveDate = Convert.ToDateTime(dt_PDY3S1A.Rows[0]["ReceiveDate"].ToString());
                    DateTime PlanFinishedDate = new DateTime();

                    int idx = 0;
                    foreach (DataRow dr in dt_PDY3S1A.Rows)
                    {
                        string strID = dr["ID"].ToString();
                        string strDesignStepNo = dr["DesignStepNo"].ToString();
                        double addDays = Convert.ToDouble(dr["StdDesignWorkTime"].ToString());

                        #region 取得未完成站點預計完成日

                        if (idx == 0)
                        {
                            PlanFinishedDate = DateTime.Now;

                            #region 遇假日 需順延至平常日

                            if (PlanFinishedDate.DayOfWeek == DayOfWeek.Saturday)
                                PlanFinishedDate = PlanFinishedDate.AddDays(2);

                            if (PlanFinishedDate.DayOfWeek == DayOfWeek.Sunday)
                                PlanFinishedDate = PlanFinishedDate.AddDays(1);

                            #endregion 遇假日 需順延至平常日
                        }
                        else
                        {
                            string strPreID = dt_PDY3S1A.Rows[idx - 1]["ID"].ToString();
                            sql = @"SELECT StdDesignWorkTime, PlanFinishedDate FROM PDY3S1A (NOLOCK)
                                            WHERE ID = @ID";
                            daoERPSelect.SqlCommand.Parameters.Clear();
                            daoERPSelect.SqlCommand.Parameters.AddWithValue("@ID", strPreID);
                            string strPrePlanFinishedDate = daoERPSelect.SqlSelectToString(sql, "PlanFinishedDate");
                            DateTime PrePlanFinishedDate = Convert.ToDateTime(strPrePlanFinishedDate);

                            PlanFinishedDate = PrePlanFinishedDate;
                            for (int LoopI = 1; LoopI <= addDays; LoopI++)
                            {
                                PlanFinishedDate = PlanFinishedDate.AddDays(1);

                                #region 遇假日 需順延至平常日

                                if (PlanFinishedDate.DayOfWeek == DayOfWeek.Saturday)
                                    PlanFinishedDate = PlanFinishedDate.AddDays(2);

                                if (PlanFinishedDate.DayOfWeek == DayOfWeek.Sunday)
                                    PlanFinishedDate = PlanFinishedDate.AddDays(1);

                                #endregion 遇假日 需順延至平常日
                            }
                        }

                        #endregion 取得未完成站點預計完成日

                        #region 更新各站點預計完成日

                        sbMsg.Clear().Append(string.Format("案號【{0}】 站點【{1}】更新預定完成日【{2}】----【失敗】\\n", strProjectNo, strDesignStepNo, PlanFinishedDate.ToString("yyyy/MM/dd")));
                        sql = @"UPDATE PDY3S1A SET PlanFinishedDate = @Date WHERE ID = @ID";
                        Dao_trans.SqlCommand.Parameters.Clear();
                        Dao_trans.SqlCommand.Parameters.AddWithValue("@Date", PlanFinishedDate.ToString("yyyy/MM/dd"));
                        Dao_trans.SqlCommand.Parameters.AddWithValue("@ID", strID);
                        isSuccess = isSuccess && Dao_trans.SqlUpdate(sql, ref sbMsg);
                        idx++;

                        #endregion 更新各站點預計完成日
                    }
                }

                #endregion 更新未完成站點 預計完成日

                #region 更新PDY2M 預交日

                sql = "SELECT PlanFinishedDate FROM PDY3S1A (NOLOCK) WHERE PDY2Mid = @PDY2Mid AND DesignStepNo = 'E-004'";
                daoERPSelect.SqlCommand.Parameters.Clear();
                daoERPSelect.SqlCommand.Parameters.AddWithValue("@PDY2Mid", strPDY2Mid);
                string strNewFinishedDate = daoERPSelect.SqlSelectToString(sql, "PlanFinishedDate");

                sbMsg.Clear().Append(string.Format("案號【{0}】 更新預交日【{1}】----【失敗】\\n", strProjectNo, strNewFinishedDate));
                sql = @"UPDATE PDY2M SET PlanFinishedDate = @PlanFinishedDate WHERE PDY2Mid = @PDY2Mid";
                Dao_trans.SqlCommand.Parameters.Clear();
                Dao_trans.SqlCommand.Parameters.AddWithValue("@PlanFinishedDate", strNewFinishedDate);
                Dao_trans.SqlCommand.Parameters.AddWithValue("@PDY2Mid", strPDY2Mid);
                isSuccess = isSuccess && Dao_trans.SqlUpdate(sql, ref sbMsg);

                #endregion 更新PDY2M 預交日

                #region 新增 交期更改紀錄

                sbMsg.Clear().Append(string.Format("案號【{0}】 新增 交期更改紀錄----【失敗】\\n", strProjectNo));
                sql = @"INSERT INTO PDY4S2C (PDY2Mid, OldFinishedDate, NewFinishedDate, DesignStepNo, DelayDays, Contexts, CreateDate, CreateUser, LstEdtDate, LstEdtUser)
                             VALUES (@PDY2Mid, @OldFinishedDate, @NewFinishedDate, @DesignStepNo, @DelayDays, @Contexts, @NowDate, @User, @NowDate, @User)";
                Dao_trans.SqlCommand.Parameters.Clear();
                Dao_trans.SqlCommand.Parameters.AddWithValue("@PDY2Mid", strPDY2Mid);
                Dao_trans.SqlCommand.Parameters.AddWithValue("@OldFinishedDate", strOldPlanFinishedDate);
                Dao_trans.SqlCommand.Parameters.AddWithValue("@NewFinishedDate", strNewFinishedDate);
                Dao_trans.SqlCommand.Parameters.AddWithValue("@DesignStepNo", strDelayDesignStepNo);
                Dao_trans.SqlCommand.Parameters.AddWithValue("@DelayDays", "1");
                Dao_trans.SqlCommand.Parameters.AddWithValue("@Contexts", "系統排程自動延期");
                Dao_trans.SqlCommand.Parameters.AddWithValue("@NowDate", DateTime.Now);
                Dao_trans.SqlCommand.Parameters.AddWithValue("@User", "Admin");
                isSuccess = isSuccess && Dao_trans.SqlInsert(sql, ref sbMsg);

                #endregion 新增 交期更改紀錄
            }
        }
        catch (Exception ex)
        {
            isSuccess = false;
            sbMsg.Append(ex.Message);
        }
        finally
        {
            if (isSuccess)
                sbMsg.Clear();
        }

        return isSuccess;
    }
}