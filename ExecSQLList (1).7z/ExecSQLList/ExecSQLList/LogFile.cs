﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERP
{
    public class LogFile
    {
        string path;
        public LogFile(string fileName)
        {
            string directory = AppDomain.CurrentDomain.BaseDirectory+@"\Log\";
            //判斷檔案路徑是否存在，不存在則建立資料夾 
            if (!System.IO.Directory.Exists(directory))
            {
                System.IO.Directory.CreateDirectory(directory);//不存在就建立目錄 
            }

            string logFileName = string.Format("{0}.txt", fileName+"_"+System.DateTime.Today.ToString("yyyyMMdd"));
            path = string.Format(@"{0}{1}", directory, logFileName);
        }

        public string WriteLog(string logMsg)
        {
            System.Text.StringBuilder sbMsg = new StringBuilder();
            try
            {
                string txtContent = "";
                if (!System.IO.File.Exists(path))
                    System.IO.File.Create(path).Close();
                else
                {
                    System.IO.StreamReader sr = new System.IO.StreamReader(path, Encoding.UTF8);
                    txtContent = sr.ReadToEnd();
                    sr.Close();
                }

                System.IO.StreamWriter sw = new System.IO.StreamWriter(path);
                sw.WriteLine(string.Format("{0}{1}", txtContent, logMsg));
                sw.Close();
            }
            catch (Exception ex)
            {
                sbMsg.Append(ex.Message);
            }
            return sbMsg.ToString();
        }
    }
}
